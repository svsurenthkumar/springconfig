D:\project_spring\appgen_ag6\appgen_kendo1011\src\main\java+743r63t 655port java.io.File;

r''543e43import java.util.HashMap;
\]
import java.util.Map;
import java.util.Scanner; 
public class ReadFromFileUsingScanner 
{ 
  public static void main(String[] args) throws Exception 
  { 
    // pass the path to the file as a parameter 
    File file = 
      new File("D:\\smocpoc\\input\\ExampleEpresStream.TAG"); 
    Scanner sc = new Scanner(file); 
  String templatespilt="";
Map<Integer,String> listofTemp=new HashMap<Integer,String>();
int i=1;
  while (sc.hasNextLine()) 
    {
    	String line=sc.nextLine();
    	templatespilt+=line+" ";
    		if(line.contains("RBCStmtArchive"))
    			{
    				if(line.contains("Start of"))
    				{
	    				if(line.contains("AcctId"))
	    				{
//	    					System.out.println(line);
//	    				System.out.println(line.split("<#AcctId=")[1]); 756464346534
	    				}
    				}
    			}
    			if(line.contains("End") && line.contains(":RBCStmtArchive"))
    			{
    				listofTemp.put(i++, templatespilt);
//    				System.out.println(line);
    			}
	  if(i==10)break;
//      System.out.println(sc.nextLine()); 
    }
  
  for (Map.Entry<Integer, String> entry : listofTemp.entrySet())
  {
	  if(entry.getKey()<10)
	  {
	  String singleTemplate=entry.getValue();
	  
	  System.out.println("accountpattern---"+singleTemplate.substring(singleTemplate.indexOf("<#AcctId="),singleTemplate.indexOf("<#AcctId")+22));
	  }
	  }
  System.out.println("Completed");
 System.out.println(listofTemp);
    } 
}
