package com.demo.springmvc.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class DCFVariableHandling {

	public Map<String, String> collectVaribales(InputStream in,Map<String, String> globalVariableMap) {

		Map<String, String> variable = new HashMap<String, String>();
		BufferedReader bufferedReader = null;
		FileReader fileReader = null;
		String sCurrentLine = "";

		try {
			//fileReader = new FileReader(FILENAME);
			bufferedReader = new BufferedReader(new InputStreamReader(in));

			while ((sCurrentLine = bufferedReader.readLine()) != null) {
				
				sCurrentLine=StringUtils.stripToEmpty(sCurrentLine); 
				
				
				if (StringUtils.startsWithIgnoreCase(sCurrentLine, "\"")) {
					sCurrentLine=sCurrentLine.replace("\"", "");
				}
				
				if (StringUtils.startsWithIgnoreCase(sCurrentLine, "\'")) {
					sCurrentLine=sCurrentLine.replace("\'", "");
				}
				
				sCurrentLine=StringUtils.stripToEmpty(sCurrentLine);	
				
				
					
				if (sCurrentLine.startsWith(".*")) {
					continue;
				} else if (StringUtils.startsWithIgnoreCase(sCurrentLine,".'SE")) {
					getKeyValue(sCurrentLine.substring(sCurrentLine.indexOf(".'SE") + 5), variable,globalVariableMap);
					continue;
				} else if (StringUtils.startsWithIgnoreCase(sCurrentLine,".SE")) {
					getKeyValue(sCurrentLine.substring(sCurrentLine.indexOf(".SE") + 4), variable,globalVariableMap);
					continue;
				} else if (
					  (	StringUtils.containsIgnoreCase(sCurrentLine, ".TH") ||
						StringUtils.containsIgnoreCase(sCurrentLine, ".'TH")||
						StringUtils.containsIgnoreCase(sCurrentLine, ".EL") ||
						StringUtils.containsIgnoreCase(sCurrentLine, ".OR") || 
						StringUtils.containsIgnoreCase(sCurrentLine, ".IF") )
					  && StringUtils.containsIgnoreCase(sCurrentLine, ".SE")) {
					getKeyValue(sCurrentLine.substring(sCurrentLine.indexOf(".SE") + 4), variable,globalVariableMap);
					continue;
				} else if (
					 (  StringUtils.containsIgnoreCase(sCurrentLine, ".TH") ||
						StringUtils.containsIgnoreCase(sCurrentLine, ".'TH")||
						StringUtils.containsIgnoreCase(sCurrentLine, ".EL") ||
						StringUtils.containsIgnoreCase(sCurrentLine, ".OR") || 
						StringUtils.containsIgnoreCase(sCurrentLine, ".IF") )
					  && StringUtils.containsIgnoreCase( sCurrentLine,".'SE")) {
					
					getKeyValue(sCurrentLine.substring(sCurrentLine.indexOf(".'SE") + 5), variable,globalVariableMap);
					continue;
				} else if (StringUtils.containsIgnoreCase(sCurrentLine,".SE") || StringUtils.containsIgnoreCase(sCurrentLine,".'SE")) {
//					System.out.println("New Pattern:" + sCurrentLine);

				}

			}

		} catch (Exception e) {
			System.out.println("New Pattern: Exception " + sCurrentLine);
			e.printStackTrace();
		}
		return variable;

	}

	public static void getKeyValue(String lineContent, Map<String, String> keyValuePaire, Map<String, String> globalVariableMap) {
		String[] subStrings = lineContent.split(" ");
		int i = 0;
		String value = "";
		for (String s : subStrings) {
			if (i == 0) {
				i++;
				continue;
			} 
			if (!s.contains("=")) {
				value += s.trim().replaceAll("'", "") + " ";
			}
		}  
		if(value.contains("&")){  // if the splited word contains & then it will try to replace the Dynamic Variable with the Value
			String key=value.substring(value.indexOf("&"));
			if(globalVariableMap.containsKey(key)){ // if the variable is present in the map then it will replace the vale
				value  = globalVariableMap.get(key);  
			} 
		}
		
		keyValuePaire.put(subStrings[0], value);

	}

}
