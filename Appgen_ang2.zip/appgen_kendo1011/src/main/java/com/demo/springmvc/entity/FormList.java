package com.demo.springmvc.entity;

import java.util.Date;

public class FormList {
	
	private String formName;
	private String formDesc;
	private String aunr;
	private String sstr;
	private String sstbnr;
	private String sstbinr;
	private String sstbbz;
	private String sstbacd;
	private String sstbsnr;
	private String sstbsc;
	private String sstbmfkz;
	
	
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public String getFormDesc() {
		return formDesc;
	}
	public void setFormDesc(String formDesc) {
		this.formDesc = formDesc;
	}
	public String getAunr() {
		return aunr;
	}
	public void setAunr(String aunr) {
		this.aunr = aunr;
	}
	public String getSstr() {
		return sstr;
	}
	public void setSstr(String sstr) {
		this.sstr = sstr;
	}
	public String getSstbnr() {
		return sstbnr;
	}
	public void setSstbnr(String sstbnr) {
		this.sstbnr = sstbnr;
	}
	public String getSstbinr() {
		return sstbinr;
	}
	public void setSstbinr(String sstbinr) {
		this.sstbinr = sstbinr;
	}
	public String getSstbbz() {
		return sstbbz;
	}
	public void setSstbbz(String sstbbz) {
		this.sstbbz = sstbbz;
	}
	public String getSstbacd() {
		return sstbacd;
	}
	public void setSstbacd(String sstbacd) {
		this.sstbacd = sstbacd;
	}
	public String getSstbsnr() {
		return sstbsnr;
	}
	public void setSstbsnr(String sstbsnr) {
		this.sstbsnr = sstbsnr;
	}
	public String getSstbsc() {
		return sstbsc;
	}
	public void setSstbsc(String sstbsc) {
		this.sstbsc = sstbsc;
	}
	public String getSstbmfkz() {
		return sstbmfkz;
	}
	public void setSstbmfkz(String sstbmfkz) {
		this.sstbmfkz = sstbmfkz;
	}

}