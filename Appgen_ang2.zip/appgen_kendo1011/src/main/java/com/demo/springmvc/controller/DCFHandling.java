package com.demo.springmvc.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class DCFHandling { 
	/* To Set the  Template layout Information */
	public void setLayout(StringBuffer html){


		html.append("<html lang=\"de\"><head><style>.bodyalign{border: 20px;border-width: 12px;border-style: double;width: 800px;margin-left: 201px;padding-top: 20px;"
				+ "margin-top: 70px;padding-left: 20px;}</style><style> .tooltip { position: relative; display: inline-block;} ."
				+ "tooltip .tooltiptext { visibility: hidden; width: 120px; background-color: black; color: #fff; text-align: center; border-radius: 6px; padding: 5px 0; "
				+ "position: absolute; z-index: 1; bottom: 100%; left: 50%; margin-left: -60px; /* Fade in tooltip - takes 1 second to go from 0% to 100% opac: "
				+ "*/ opacity: 0; transition: opacity 1s; } .tooltip:hover .tooltiptext { visibility: visible; opacity: 1; } .linebreak { display: block; }"
				+ ".sub {position: relative;bottom: -0.5em; color: red; font-size: 0.8em;} .sup {position: relative;bottom: 0.5em; color: red; font-size: 0.8em;} </style>"
				+ "</head><body><div class=\"container bodyalign\">");
		
		return ;
	}

	/**
	 * 
	 * @param html    Used to Append the Converted Data 
	 * @param sCurrentLine Its the Current Line Data
	 * @param tpParm 
	 * @param tabVal 
	 * @param subflag
	 * @param fileVariableMap
	 * @param globalVariableMap
	 * @param table
	 * @param isBxAvailable
	 */
	// caret symbol "^
		public void processcaret (StringBuffer html, String sCurrentLine , ArrayList<Double> tpParm, 
				int tabVal,String sub_sup_script_Flag,Map<String,String> fileVariableMap, Map<String,String> globalVariableMap,boolean table, Boolean isBxAvailable)
		{
			
			
			String[] subStrings=sCurrentLine.split("\\^");

			boolean flag=false;
			
			boolean emptytdflag=false;
			
			if(tpParm.size() >0)
			{
				boolean tdflag=true; // its created because got an exception in the.ct Pattern to replace </td> content.
				
				
				if(table)
				{
					html.append("<table style=\"width:100%\"> ");// style=\"width:100%;\" 
					html.append("<tr>");
				}
				
				if(table){
					emptytdflag=true;
					html.append("<td style=\"width:0px;  text-align:left !important;vertical-align: text-top; \">");
				}

				if(subStrings.length >= 1 && StringUtils.isNotBlank(subStrings[0]))
				{	
					html.append(displayWord(subStrings[0],sub_sup_script_Flag,tabVal,fileVariableMap,globalVariableMap)); 
				}
				/*else if(subStrings.length == 1 && StringUtils.isNotBlank(subStrings[0]))
				{
					html.append(displayWord(subStrings[0],sub_sup_script_Flag,tabVal,fileVariableMap,globalVariableMap)); 
				}*/
				else
				{
					flag=true;
					html.append("&nbsp");
//					System.err.println("Error In Process ^ Function Logic:"+subStrings.length+":"+tpParm+"\t" + sCurrentLine);
				}
				
				if(table)
				{
					html.append("</td>");
				}
				int i=0,j=1;
				
				for (;j<subStrings.length && i<tpParm.size();j++, i++)
				{			
					double padding=tpParm.get(i);
				/*	if(i != 0)
					{
//						if(flag)System.out.println(tpParm.get(i)+" - "+tpParm.get(i-1) +" = "+ (tpParm.get(i) - tpParm.get(i-1)));
						padding = tpParm.get(i) - tpParm.get(i-1);
					}
				*/	
					if(isBxAvailable) 
					{//padding-left:"+padding+"px;  
						html.append("<td align=\"left\" style=\"text-align:left !important; vertical-align: text-top; \">"+ displayWord(subStrings[j],sub_sup_script_Flag,tabVal,fileVariableMap,globalVariableMap)
						             + "</td>");
					}
					else
					{ //padding-left:"+padding+"px;  
						html.append("<td align=\"left\" style=\" text-align:left !important;vertical-align: text-top; \">"+ displayWord(subStrings[j],sub_sup_script_Flag,tabVal,fileVariableMap,globalVariableMap) + "</td>");
					}	
					tdflag=false;
				}
				if(tdflag)
				{
					html.append("<td></td>");
				}
				if(table)
				{
					html.append("</tr></table>");
				}
				
			}
			
			
			if(flag)
			{
//				System.out.println("Output:\n"+html);
				flag=false;
			}
			
			return;
		}
		

		private  String insertSpace(String dynamicValue) {
			if (dynamicValue.contains(">")) {
				dynamicValue = dynamicValue.replace(">", "&nbsp");
			}
			if(StringUtils.isNotBlank(dynamicValue)) return dynamicValue;
			return "";
		}
		
		public void processNonDCFLine(StringBuffer html, String sCurrentLine, Double previousIndentStyle, 
				int indentStyleIncrementor,int centerAlignIncrementor ,String indentStyle ,
				String centerOrUnderlineStyle ,String centerSwitch,String fontStyle, 
				String foStyle,String breakStyle , String sub_sup_script_Flag,Map<String,String> globalVariableMap,Map<String,String> fileVariableMap){
			
			
			
			if(previousIndentStyle > 0 && indentStyleIncrementor > 0) {
				html.append("<div style=\" padding-left:"+ previousIndentStyle +"\">");
			} else if(StringUtils.isNotBlank(indentStyle)) {
				html.append(indentStyle);
			}
			
			
			if(centerAlignIncrementor > 0) {
				applyStartTg(centerSwitch, html);
			} else if(StringUtils.isNotBlank(centerSwitch) && centerSwitch.equalsIgnoreCase("off")) {
				// do nothing
			} else if(StringUtils.isNotBlank(centerOrUnderlineStyle)) {
				applyStartTg(centerOrUnderlineStyle, html);
			}
			
			
			if(StringUtils.isNotBlank( fontStyle)  || StringUtils.isNotBlank( foStyle)) {
				html.append("<div style=\"");
				if(StringUtils.isNotBlank(fontStyle)) 
					html.append(fontStyle);
				if(StringUtils.isNotBlank(foStyle))
					html.append(foStyle);
				
				html.append("\">");
			}
			
			
			if(StringUtils.isNotBlank(breakStyle)) {
				html.append(breakStyle);
			}
			
			
			html.append("<div>"); 
			dcfGeneratorRefactored.displayString( sCurrentLine, html,sub_sup_script_Flag,globalVariableMap,fileVariableMap);
			html.append("</div>");
			
			if(StringUtils.isNotBlank(breakStyle)) {
				html.append("</div>");
				breakStyle = null;
			}
			
			if(StringUtils.isNotBlank( fontStyle)  || StringUtils.isNotBlank( foStyle)) {
				html.append("</div>");
				fontStyle = null;
				foStyle = null;
			}
			
			
			
			
			
			if(StringUtils.isNotBlank(centerOrUnderlineStyle)) {
				html.append(applyEndTag(centerOrUnderlineStyle));
				if(null == centerSwitch || centerSwitch.equalsIgnoreCase("off")) {
					centerOrUnderlineStyle = null;
					if(StringUtils.isNotBlank(centerSwitch) && centerSwitch.equalsIgnoreCase("off")) {
						centerSwitch = null;
					}
				}
				centerAlignIncrementor--;
			} else if(centerAlignIncrementor > 0) {
				html.append(applyEndTag(centerSwitch));
				if(centerAlignIncrementor == 1) {
					centerSwitch = null;
				}
				centerAlignIncrementor--;
			}
			
			
			if(previousIndentStyle > 0 && indentStyleIncrementor > 0) {
				html.append("</div>");
				indentStyleIncrementor--;
			} else if(StringUtils.isNotBlank(indentStyle)) {
				html.append("</div>");
				indentStyle=null;
			}

			
			return;
				
		}
		private  void applyStartTg(String centerOrUnderlineStyle, StringBuffer html) {
			if(null != centerOrUnderlineStyle && centerOrUnderlineStyle.contains(".ce") ) {
				html.append("<center>");
			}else if(StringUtils.isNotBlank(centerOrUnderlineStyle) && centerOrUnderlineStyle.contains(".us")) {
				html.append("<div style=\"text-decoration:underline;\">");
			}
		}

		private  String applyEndTag(String centerOrUnderlineStyle) {
			String endTag = "";
			if(StringUtils.isNotBlank(centerOrUnderlineStyle) && centerOrUnderlineStyle.contains(".ce")) {
				endTag= "</center>";
			}else if(StringUtils.isNotBlank(centerOrUnderlineStyle) && centerOrUnderlineStyle.contains(".us")) {
				endTag="</div>";
			}
			centerOrUnderlineStyle = null;
			return endTag;
		}
		
		
		
		private  String displayWord(String dynamicValue,String sub_sup_script_Flag, int tabVal,Map<String,String> fileVariableMap, Map<String,String> globalVariableMap) {
			
			
			if(!(dynamicValue.contains("^")) && dynamicValue.contains("&")) 
			{ //padding-left:"+tabVal+"px
				dynamicValue = "<div style = \"\" > " + retriveDynamicVariable(globalVariableMap, fileVariableMap, dynamicValue)+ "</div>";

			}
			else if(dynamicValue.contains("&") && dynamicValue.contains("^")) 
			{
					if(!(dynamicValue.contains("^")) && dynamicValue.contains("&")) 
					{
						dynamicValue = "<span> "+ retriveDynamicVariable(globalVariableMap, fileVariableMap, dynamicValue)+ "</span>";
					}
					else if(!(dynamicValue.contains("&")) && dynamicValue.contains("^")) 
					{
						int count = StringUtils.countMatches(dynamicValue, "^");
						int indentSpacingVal = count*tabVal;
						dynamicValue = "<span style = \"padding-left:"+indentSpacingVal+"px\"> "
						                          + insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>";
					}
					else if(dynamicValue.contains("^") && dynamicValue.contains("&")) 
					{
						int count = StringUtils.countMatches(dynamicValue, "^");
						int indentSpacingVal = count*tabVal;
						dynamicValue = StringUtils.substringAfter(dynamicValue, "&");
						dynamicValue = "<span style = \"color:red;padding-left:"+indentSpacingVal+"px\"> " + insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>";
					}
					else 
					{					
						dynamicValue = "<div style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(dynamicValue) + "</div>";
					}
			}
			else if(!(dynamicValue.contains("&")) && dynamicValue.contains("^")) 
			{
					if(dynamicValue.contains("^")) 
					{
						int count = StringUtils.countMatches(dynamicValue, "^");
						int indentSpacingVal = count*tabVal;
						dynamicValue = "<span style = \"padding-left:"+indentSpacingVal+"px\"> "
						                     + insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>";
					} 
					else 
					{
						dynamicValue ="<div style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(dynamicValue) + "</div>";
					}
			}
			else 
			{
				dynamicValue = "<div style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(dynamicValue) + "</div>";
			}
			
			if(StringUtils.isNotBlank(sub_sup_script_Flag))
			{	
				if(dynamicValue.startsWith("<div"))
				{
					
				}
				else
				{
					
				}
			}
			
			return dynamicValue;
		}

		
		
		public String retriveDynamicVariable(Map<String,String> globalVariableMap,Map<String,String> fileVariableMap, String data)
		{
			String convertedData="";
			
			//Adding this Line for the Insert Space implementation in the Current String
			if(data.contains(">"))
			{
				data=data.replaceAll(">", "|*");
			} 
			boolean datasplited=false;
			String splitedString="";
			
	/* Below Block is created only for ignoring the Dynamic variable formating of .SE and .GO patter coming along with   .IF .EL .TH 
	 * Since we are getting the Space issue 
	 * Sample code 
	 * .IF &L'&G30BETRVN2 = 0 .SE BETRVN2 = ''
	 * .IF &L'&G01ZESSAZ = 0 .GO AZEND
	 * */   
			if( (StringUtils.startsWithIgnoreCase(data, ".IF") || StringUtils.startsWithIgnoreCase(data, ".EL"))&& 
				((StringUtils.countMatches(data, ".SE") >=1) || (StringUtils.countMatches(data, ".'SE") >=1) || (StringUtils.countMatches(data, ".GO") >=1))
			){
				
				
				if (StringUtils.countMatches(data, ".'SE") >=1){
					splitedString=data.substring(StringUtils.indexOfIgnoreCase(data, ".'SE"));
					data=data.substring(0,StringUtils.indexOfIgnoreCase(data, ".'SE"));		
					datasplited=true;
				}else if (StringUtils.countMatches(data, ".SE") >=1){ 
					splitedString=data.substring(StringUtils.indexOfIgnoreCase(data, ".SE"));
					data=data.substring(0,StringUtils.indexOfIgnoreCase(data, ".SE"));
					datasplited=true;
				}else if (StringUtils.countMatches(data, ".GO") >=1)  {
					splitedString=data.substring(StringUtils.indexOfIgnoreCase(data, ".GO"));
					data=data.substring(0,StringUtils.indexOfIgnoreCase(data, ".GO"));
					datasplited=true;
				}else{
					System.out.println("Issue In the retriveDynamicVariable logic");
				}
				
			}
			
			
			/*Issue Logic when its comes only the Dynamic Value with the Empty String*/
			if(StringUtils.contains(data, "&")){
				String[] spaceSplitsString=data.split("\\s+");
				for(String s: spaceSplitsString){
					
					if(s.contains("&")){ // if the splited word contains & then it will try to replace the Dynamic Variable with the Value
					
						if(StringUtils.countMatches(s, "&") ==1)
						{
							
							String key=StringUtils.stripToEmpty(s.substring(s.indexOf("&")));
							
							if(StringUtils.endsWith(key, ".")){
								key=key.substring(0, key.lastIndexOf("."));
							}	
							if(StringUtils.startsWith(key, "&")){
								key=key.substring(1);
							}
													
							if(globalVariableMap.containsKey(key)) // if the variable is present in the map then it will replace the vale
							{
								convertedData += " "+ globalVariableMap.get(key)+" "; 
							}
							else if(fileVariableMap.containsKey(key)) // if the variable is present in the map then it will replace the vale
							{
								convertedData += " "+ fileVariableMap.get(key)+" "; 
							}
							
							else{  // if the variable is not present in the map then it will wrap the text with the red fontcolor 
								convertedData += "&nbsp<span style = \"color:red;\"> "+s+"</span>&nbsp";
							}
						}
						else
						{ 
							String[] keys=s.split("\\&");
							for(String k:keys)
							{
								if(StringUtils.isNotBlank(k)){
									String key=k;
									if(StringUtils.endsWith(k, ".")){
										key=k.substring(0, k.lastIndexOf("."));
									}	
									if(StringUtils.startsWith(k, "&")){
										key=k.substring(1);
									}
									
									if(globalVariableMap.containsKey(key)) // if the variable is present in the map then it will replace the vale
									{
										convertedData += " "+globalVariableMap.get(key); 
									}
									else if(fileVariableMap.containsKey(key)) // if the variable is present in the map then it will replace the vale
									{
										convertedData += " "+ fileVariableMap.get(key)+" "; 
									}
									else{  // if the variable is not present in the map then it will wrap the text with the red fontcolor 
										convertedData += "&nbsp<span style = \"color:red;\"> &"+k+"</span>&nbsp";
									}
								}
							}
						}
						
					}else{//if the & key was not present in the String then it will send the value as it is.
						convertedData += " "+s;
					}
				}
			}

			if(datasplited){
				
				if(!StringUtils.isNotBlank(convertedData) && StringUtils.isNotBlank(data))
				{
					convertedData=data+" "+splitedString;
				}
				else
				{
					convertedData=convertedData+" "+splitedString;
				}
				
			}
				
			//Adding this Line for the Insert Space implementation in the Current String
			if(convertedData.contains("|*")){
				convertedData=convertedData.replaceAll("\\|\\*", "&nbsp");
			}
			 
			return convertedData;
		}

		public Map<String,String> getGlobalVariableMap(String filename){ 
			Map<String, String> variableMap = new HashMap<String, String>();
			BufferedReader bufferedReader = null;
			FileReader fileReader = null;
			String sCurrentLine = ""; 
			try {
				fileReader = new FileReader(filename);
				bufferedReader = new BufferedReader(fileReader);
				while ((sCurrentLine = bufferedReader.readLine()) != null) {
					String[] keyValue = sCurrentLine.split("\\|");
					if (keyValue.length == 2 && !variableMap.containsKey(keyValue[0])){
						variableMap.put(keyValue[0], keyValue[1]);
					} 
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}

		 
			return variableMap;
		}
		
		public String processIFBlockContent(Map<Integer,List<String>> ifMap ,Map<String,String> globalVariableMap,Map<String,String> fileVariableMap){
			String convertedIfBlock="";
			for (Integer key : ifMap.keySet()) {
				List<String> ifBlockLines=ifMap.get(key);
				/* 
				  <div style="background-color:gray;padding:20px;">
					 <h2>London</h2>
					  <p>London is the capital city of England. It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.</p>
					  <p>Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.</p>
					</div>  	  
				 */
				convertedIfBlock += "<div style=\"background-color:gray;padding:20px;\">";
				convertedIfBlock +="<h2>Rule"+key+"</h2>";
				for(String s: ifBlockLines){ 
					convertedIfBlock +=  "<p>"+retriveDynamicVariable(globalVariableMap, fileVariableMap, s)+"</p>";
				} 
				convertedIfBlock +="</div> <br/>"; 
			} 
			
			return convertedIfBlock;
		}

		
	
	
}
