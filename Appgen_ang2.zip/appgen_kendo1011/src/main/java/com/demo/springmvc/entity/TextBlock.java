package com.demo.springmvc.entity;

public class TextBlock {

	private String textBlockName;
	private String contentInfo;
	private String orderInfo;
	private String ordreInfoString;
	private double orderInfoNum;
	
	public double getOrderInfoNum() {
		return orderInfoNum;
	}
	public void setOrderInfoNum(double d) {
		this.orderInfoNum = d;
	}
	public String getTextBlockName() {
		return textBlockName;
	}
	public void setTextBlockName(String textBlockName) {
		this.textBlockName = textBlockName;
	}
	public String getContentInfo() {
		return contentInfo;
	}
	public void setContentInfo(String contentInfo) {
		this.contentInfo = contentInfo;
	}
	public String getOrderInfo() {
		return orderInfo;
	}
	public void setOrderInfo(String orderInfo) {
		this.orderInfo = orderInfo;
	}
}
