package com.demo.springmvc.controller;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

public class DCF2HTML {

	//private static final String FILENAME = "F:\\TCS\\DCF comments\\DCF\\io\\dcf4.txt";
	private static final String FILENAME ="D:\\project_spring\\src0109\\src\\main\\java\\com\\demo\\springmvc\\controller\\dcf.txt";
	private static 	Double spacingValue = 0.0;
	private static String shadeVal = null;
	private static int tabVal = 1;
	private static ArrayList<Double> tpStyleVal = null;
	/*public static void main(String[] args) throws IOException {
			//buildHTML();
	}
*/

	public  String  buildHTML(InputStream in) {
		// TODO Auto-generated method stub
		String fontStyle = null;
		String indentStyle = null;
		Double previousIndentStyle = 0.0;
		int indentStyleIncrementor = 0;
		String breakStyle = null;
		int centerAlignIncrementor = 0;
		String centerSwitch = null;
		Boolean isTableCreate = Boolean.FALSE;
	
		BufferedReader bufferedReader = null;
		FileReader fileReader = null;
		String dynamicValue = "CE0VSNR001";
		String returnValue="";
		
		try {
			//fileReader = new FileReader(in);
			bufferedReader = new BufferedReader(new InputStreamReader(in));

			String sCurrentLine;
			String centerOrUnderlineStyle = null;
			
			StringBuffer html = new StringBuffer();
			html.append("<html lang=\"en\"><head><style>.bodyalign{border: 20px;    background-color: white;border-width: 12px;border-style: double;width: 800px;margin-left: 201px;padding-top: 20px;"
					+ "margin-top: 70px;padding-left: 20px;}</style></head><body><div class=\"container bodyalign\">");
			
			while ((sCurrentLine = bufferedReader.readLine()) != null) {
				if (sCurrentLine.startsWith(".*")
						|| sCurrentLine.startsWith(".kp on") 
						    || sCurrentLine.startsWith(".kp off")
						    || sCurrentLine.startsWith(".oi")
						    || sCurrentLine.startsWith(".si")
						    || sCurrentLine.startsWith(".pa")
						    || sCurrentLine.startsWith(".if") || sCurrentLine.startsWith(".an") || sCurrentLine.startsWith(".el") || sCurrentLine.startsWith(".se") || sCurrentLine.startsWith(".th")
						    || sCurrentLine.startsWith(".IF") || sCurrentLine.startsWith(".AN") || sCurrentLine.startsWith(".EL") || sCurrentLine.startsWith(".SE") || sCurrentLine.startsWith(".TH")
						    || sCurrentLine.startsWith(".SU") || sCurrentLine.startsWith(".su") || sCurrentLine.startsWith("...")) {
					continue;
				} else if (null != tpStyleVal && tpStyleVal.size() > 0 && !sCurrentLine.startsWith(".")) {
					if(sCurrentLine.equalsIgnoreCase(".tp")) {
						html.append(" </table>");
						tpStyleVal = null;
						continue;
					} else {
						if(isTableCreate) {
							html.append("<table style=\"width:100%;\">");
							for( int i = 1 ; i < tpStyleVal.size(); i++ ) {
							     tpStyleVal.set(i, tpStyleVal.get(i)-tpStyleVal.get(i-1));
							}
							isTableCreate = Boolean.FALSE;
						}
						if(spacingValue >= 1) {
							html.append("<tr> <td style=\"padding-top:"+spacingValue+"px\"></td></tr>");
							spacingValue = 0.0;
						}
						String[] words = sCurrentLine.split("\\^");
						html.append("<tr> <td style=\"min-width:"+tpStyleVal.get(0)+"px\">"+ displayWord(words[0]) +"</td>");
						
						for(int i = 1; i < words.length; i++) {
							int copyvalue=i;
							copyvalue = copyvalue+1;
							if(copyvalue<=words.length)
							{
								if(copyvalue == words.length)
								{
							       html.append("<td>"+displayWord(words[copyvalue-1]) +"</td></tr>");
								}
								else
								{
									
									html.append("<td style=\"min-width:"+tpStyleVal.get(copyvalue-1)+"px\">"
								                       +displayWord(words[copyvalue-1]) +"</td>");
								}
							}
						}
						continue;
					}
				} else if (sCurrentLine.contains(".br")) {
					html.append("</br>" );
					continue;
				} else if (sCurrentLine.startsWith(".ct")) {
					sCurrentLine = sCurrentLine.replaceAll(".ct", "");
					String previousText = html.substring(html.lastIndexOf("<div "));
					html = html.delete(html.indexOf(previousText), html.length());
					int count = StringUtils.countMatches(previousText, "</div>");
					previousText = previousText.replaceAll("</div>", "");
					if(tpStyleVal != null) {
						previousText = previousText.replaceAll("</td>", "");
					}
					html.append(previousText + " ");
					displayString(dynamicValue,sCurrentLine, html);
					for (int i= 1; i <= count; count-- ) {
						html.append("</div>");
					}
					if(tpStyleVal != null) {
						html.append("</div>");
					}
					continue;
				}
				else if (sCurrentLine.contains(".sd"))
				{
					String[] words = sCurrentLine.split("\\s+");
					int shadePercentage = 0;
					 // TODO need to get the shade definition and 25 � grey percentage value � standard 
					for (int i= 0; i < words.length; i++) {
						if(words[i].equalsIgnoreCase("shade")) {
							shadePercentage = Integer.parseInt(words[i+1]);
							// TODO: hardcoded light grey
							shadeVal = "background-color:lightgrey;";
						}
					}
					continue;
				}
				else if (sCurrentLine.contains(".bf"))
				{
					String fontFamily = sCurrentLine.substring(4);
					// As of now hardcoded need to get the exact html font family
					  fontFamily = "sans-serif";
					  fontStyle = "<div id=\"CETPBTRF60\"" + " style=\"font-family:" + fontFamily + "\">" ; 
					continue ;
				} else if (sCurrentLine.startsWith(".in")) {
					String[] words = sCurrentLine.split("\\s+");
					if(null != words[1]) {	
						previousIndentStyle = indentStyleGen(previousIndentStyle, words); 
						if(!words[1].contains("+") && !words[1].contains("-")) {
							if(words[1].contains("mm")) { 
							   previousIndentStyle = Double.valueOf(words[1].substring(0, words[1].length() - 2))*3.77;
						    } else if (words[1].contains("i")) {
						    	previousIndentStyle = Double.valueOf(words[1].substring(0, words[1].length() - 1))*60;
						    } else {
						    	previousIndentStyle = Double.valueOf(words[1])*2;
						    }
						}	
					}
					if(words.length == 4) {
						if(words[3].contains("i")) {
							int indentCount = Integer.parseInt(words[3].replaceAll("i", ""));
							indentStyleIncrementor = (indentCount*60)/20;
						}
					}
					if(previousIndentStyle > 0 && indentStyleIncrementor == 0) {
						indentStyle = "<div style=\" padding-left:"+ previousIndentStyle +" \">";
					} 
					continue ;
				} else if (sCurrentLine.contains(".ti")) {
					String[] words = sCurrentLine.split("\\s+");
					if(null != words[2]) {	
						// Assuming 1 tab = 10 Px
						tabVal = Integer.parseInt(words[2])*10;
					}
					continue ;
				} else if (sCurrentLine.contains(".sp")) {
					breakStyle = breakElement(sCurrentLine, html);
					continue ;
				} else if (sCurrentLine.contains(".sk")) {
					html.append("</br>");
					continue ;
				}
				else if (sCurrentLine.contains(".da"))
				{
					da(sCurrentLine,html);
					continue;
				}
				else if (sCurrentLine.contains(".hr"))
				{
					if(sCurrentLine.contains("left")) {
						ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
						html.append("<hr style = \"margin-left:"+styleFinalVal.get(0)+"px\">");
					} else if(sCurrentLine.contains("right")) {
						ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
						html.append("<hr style = \"margin-left:"+styleFinalVal.get(0)+"px\">");
					} else {
						hrLeftAndRightStyle(sCurrentLine, html);
					}
					continue;
				}
				else if (sCurrentLine.contains(".ar"))
				{
					if(sCurrentLine.contains("on")) {
						continue;
					}
					if(sCurrentLine.contains("off")) {
						html.append("</div>");
						continue;
					}
					
				} else if (sCurrentLine.contains(".ce") || sCurrentLine.contains(".us")) {
					 String[] strCurrentLine = null;
					 strCurrentLine = 	 sCurrentLine.split(" ");
					 if(strCurrentLine.length == 1) {
						 centerOrUnderlineStyle = applyStyle(sCurrentLine);
					 } else if(null != strCurrentLine[1]  
							 && (strCurrentLine[1].length() == 1 || strCurrentLine[1].length() == 2 
							 || strCurrentLine[1].length() == 3)) {
						 if(strCurrentLine[1].equalsIgnoreCase("on")) {
							 applyStartTg(strCurrentLine[0], html);
							 centerSwitch = "on";
						 } else if(strCurrentLine[1].equalsIgnoreCase("off")) {
							 centerSwitch = "off";
						 }  else {
							 centerAlignIncrementor = Integer.parseInt(strCurrentLine[1]);
							 centerSwitch = strCurrentLine[0];
							 
						 }
					 } else if(null != strCurrentLine[1]  && strCurrentLine[1].length() > 3) {
						 if(null != fontStyle) {
								html.append(fontStyle);
						 }
						 if(null != breakStyle) {
								html.append(breakStyle);
						 }
						applyStartTg(strCurrentLine[0], html);
						html.append(sCurrentLine.substring(4));
						html.append(applyEndTag(strCurrentLine[0]));
						if(null != fontStyle) {
							html.append("</div>");
							fontStyle = null;
						}
						if(null != breakStyle) {
							html.append("</div>");
							breakStyle = null;
						}
					 } 
					continue;
				} else if (sCurrentLine.contains(".tp") && sCurrentLine.length() > 1) {
					tpStyleVal = retrievePaddingVal(sCurrentLine);
					System.out.println("tpStyleVal :::" + tpStyleVal.size());
					isTableCreate = Boolean.TRUE;
					continue;
				}  else {
					
					if(previousIndentStyle > 0 && indentStyleIncrementor > 0) {
						html.append("<div style=\" padding-left:"+ previousIndentStyle +"\">");
					} else if(null != indentStyle) {
						html.append(indentStyle);
					}
					if(centerAlignIncrementor > 0) {
						applyStartTg(centerSwitch, html);
					} else if(null != centerSwitch && centerSwitch.equalsIgnoreCase("off")) {
						// do nothing
					} else if(null != centerOrUnderlineStyle) {
						applyStartTg(centerOrUnderlineStyle, html);
					}
					if(null != fontStyle) {
						html.append(fontStyle);
					}
					if(null != breakStyle) {
						html.append(breakStyle);
					}
					html.append("<div>");
					displayString(dynamicValue, sCurrentLine, html);
					html.append("</div>");
					if(null != breakStyle) {
						System.out.println("breakstyle");
						html.append("</div>");
						breakStyle = null;
					}
					if(null != fontStyle) {
						System.out.println("fontstyle");
						html.append("</div>");
						fontStyle = null;
					}
					if(null != centerOrUnderlineStyle) {
						html.append(applyEndTag(centerOrUnderlineStyle));
						if(null == centerSwitch || centerSwitch.equalsIgnoreCase("off")) {
							centerOrUnderlineStyle = null;
							if(null != centerSwitch && centerSwitch.equalsIgnoreCase("off")) {
								centerSwitch = null;
							}
						}
						centerAlignIncrementor--;
					} else if(centerAlignIncrementor > 0) {
						html.append(applyEndTag(centerSwitch));
						if(centerAlignIncrementor == 1) {
							centerSwitch = null;
						}
						centerAlignIncrementor--;
					}
					
					if(previousIndentStyle > 0 && indentStyleIncrementor > 0) {
						html.append("</div>");
						indentStyleIncrementor--;
					} else if(null != indentStyle) {
						html.append("</div>");
						indentStyle=null;
					}
					
					continue;
				}
				
			}
			html.append("<span>bottom content</span></div></body></html>") ;
			
			returnValue=html.toString();
			// String FILENAMEOUTPUT ="D:\\project_spring\\src0109\\src\\main\\java\\com\\demo\\springmvc\\controller\\dcfGenerator.html";
			//BufferedWriter bwr = new BufferedWriter(new FileWriter(new File(FILENAMEOUTPUT)));
            //bwr.write(html.toString());
            //flush the stream
            //bwr.flush();
            //close the stream
            //bwr.close();
			System.out.println("Final html" + html);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
				if (fileReader != null)
					fileReader.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return returnValue;
	}


	private static Double indentStyleGen(Double previousIndentStyle, String[] words) {
		if(words[1].contains("+")) { 
			if(words[1].contains("mm"))
			       previousIndentStyle = previousIndentStyle + 
			            Double.valueOf(words[1].substring(1, words[1].length()-2))*2*3.77;
			if(words[1].contains("i"))
				   previousIndentStyle = previousIndentStyle + 
				            Double.valueOf(words[1].substring(1, words[1].length()-2))*2*96;
			if(!words[1].contains("mm") && !words[1].contains("i"))
				   previousIndentStyle = previousIndentStyle + 
				            Double.valueOf(words[1].substring(1, words[1].length()-2))*2;
		} else if(words[1].contains("-")) { 
			if(words[1].contains("mm"))
			       previousIndentStyle = previousIndentStyle - 
			            Double.valueOf(words[1].substring(1, words[1].length()-2))*2*3.77;
			if(words[1].contains("i"))
				   previousIndentStyle = previousIndentStyle - 
				            Double.valueOf(words[1].substring(1, words[1].length()-2))*2*96;
			if(!words[1].contains("mm") && !words[1].contains("i"))
				   previousIndentStyle = previousIndentStyle - 
				            Double.valueOf(words[1].substring(1, words[1].length()-2))*2;
		}
		return previousIndentStyle;
	}


	private static void hrLeftAndRightStyle(String sCurrentLine, StringBuffer html) {
		ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
		ArrayList<Double> oddList = new ArrayList<Double>();
		ArrayList<Double> evenList = new ArrayList<Double>();
		int i = 0;
		for (Double word:styleFinalVal)
		{
		    if (i % 2 != 0)
		    {
		    	oddList.add(word);
		    }
		    if (i % 2 == 0)
		    {
		    	evenList.add(word);
		    }
		    i++;
		}
		System.out.println("evenList"+evenList.size());
		System.out.println("oddList"+oddList.size());
		for (Double styleOddVal : oddList) {
			  for (Double styleEvenVal : evenList) {
				  	html.append("<hr style = \"margin-left:"+styleOddVal+"px;width:"+styleEvenVal+"px\">");
			  }
		}
	}


	private static void applyStartTg(String centerOrUnderlineStyle, StringBuffer html) {
		if(null != centerOrUnderlineStyle && centerOrUnderlineStyle.contains(".ce") ) {
			html.append("<center>");
		}else if(null != centerOrUnderlineStyle && centerOrUnderlineStyle.contains(".us")) {
			html.append("<div style=\"text-decoration:underline;\">");
		}
	}


	private static String applyEndTag(String centerOrUnderlineStyle) {
		String endTag = null;
		if(null != centerOrUnderlineStyle && centerOrUnderlineStyle.contains(".ce")) {
			endTag= "</center>";
		}else if(null != centerOrUnderlineStyle && centerOrUnderlineStyle.contains(".us")) {
			endTag="</div>";
		}
		centerOrUnderlineStyle = null;
		return endTag;
	}


	private static String applyStyle(String sCurrentLine) {
		String centerOrUnderlineStyle = null;
		if(sCurrentLine.contains(".ce")) {
			 centerOrUnderlineStyle = ".ce";
		 } else if(sCurrentLine.contains(".us")) {
			 centerOrUnderlineStyle = ".us";
		 }
		return centerOrUnderlineStyle;
	}


	private static void displayString(String dynamicValue, String sCurrentLine, StringBuffer html) {
		String[] words = sCurrentLine.split("\\s+");
		if(!(sCurrentLine.contains("^")) && sCurrentLine.contains("&")) {
			for(int i=0; i < words.length ; i++) {
				if(words[i].contains("&")) {
					dynamicValue = StringUtils.substringAfter(words[i], "&");
					html.append("<span style = \"color:red;padding-left:"+tabVal +"px\"> "+ insertSpace(dynamicValue)+ "</span>");
				} else {
					html.append("<span style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(words[i]) + "</span>");
				}
			}
		} else if(sCurrentLine.contains("&") && sCurrentLine.contains("^")) {
			for(int i=0; i < words.length ; i++) {
				if(!(words[i].contains("^")) && words[i].contains("&")) {
					System.out.println(" 7:::"+words[i]);
					dynamicValue = StringUtils.substringAfter(words[i], "&");
					html.append("<span style = \"color:red;padding-left:"+tabVal +"px\"> "+insertSpace(dynamicValue)+ "</span>");
				} else if(!(words[i].contains("&")) && words[i].contains("^")) {
					System.out.println(" ^:::"+words[i].replaceAll("\\^", ""));
					int count = StringUtils.countMatches(words[i], "^");
					int indentSpacingVal = count*tabVal;
					html.append("<span style = \"padding-left:"+indentSpacingVal+"px\"> "+ insertSpace(words[i].replaceAll("\\^", ""))+ "</span>");
				} else if(words[i].contains("^") && words[i].contains("&")) {
					System.out.println(" &::^ ::"+words[i]);
					int count = StringUtils.countMatches(words[i], "^");
					int indentSpacingVal = count*tabVal;
					dynamicValue = StringUtils.substringAfter(words[i], "&");
					html.append("<span style = \"color:red;padding-left:"+indentSpacingVal+"px\" >"+ insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>");
				} else {
					html.append("<span style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(words[i]) + "</span>");
				}
			}
		} else if(!(sCurrentLine.contains("&")) && sCurrentLine.contains("^")) {
			for(int i=0; i < words.length ; i++) {
				if(words[i].contains("^")) {
					int count = StringUtils.countMatches(words[i], "^");
					int indentSpacingVal = count*tabVal;
					html.append("<span style = \"padding-left:"+indentSpacingVal+"px\" >"+insertSpace(words[i].replaceAll("\\^", " "))+ "</span>");
				} else {
					html.append("<span style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(words[i]) + "</span>");
				}
			}
		} else {
			if(tpStyleVal != null ) {
				html.append("<span style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(sCurrentLine) + "</span>");
			} else {
				html.append("<div style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(sCurrentLine) + "</div>");
			}
		}
	}
	
	private static String displayWord(String dynamicValue) {
		if(!(dynamicValue.contains("^")) && dynamicValue.contains("&")) {
					dynamicValue = "<div style = \"color:red;padding-left:"+tabVal+"px\"> " 
		                              + insertSpace(StringUtils.substringAfter(dynamicValue, "&"))+ "</div>";
		} else if(dynamicValue.contains("&") && dynamicValue.contains("^")) {
				if(!(dynamicValue.contains("^")) && dynamicValue.contains("&")) {
					dynamicValue = "<span style = \"color:red\"> "+ insertSpace(StringUtils.substringAfter(dynamicValue, "&"))
					                         + "</span>";
				} else if(!(dynamicValue.contains("&")) && dynamicValue.contains("^")) {
					int count = StringUtils.countMatches(dynamicValue, "^");
					int indentSpacingVal = count*tabVal;
					dynamicValue = "<span style = \"padding-left:"+indentSpacingVal+"px\"> "
					                          + insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>";
				} else if(dynamicValue.contains("^") && dynamicValue.contains("&")) {
					int count = StringUtils.countMatches(dynamicValue, "^");
					int indentSpacingVal = count*tabVal;
					dynamicValue = StringUtils.substringAfter(dynamicValue, "&");
					dynamicValue = "<span style = \"color:red;padding-left:"+indentSpacingVal+"px\"> "
					                           + insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>";
				} else {
					dynamicValue = "<div style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(dynamicValue) + "</div>";
				}
			}
		 else if(!(dynamicValue.contains("&")) && dynamicValue.contains("^")) {
				if(dynamicValue.contains("^")) {
					int count = StringUtils.countMatches(dynamicValue, "^");
					int indentSpacingVal = count*tabVal;
					dynamicValue = "<span style = \"padding-left:"+indentSpacingVal+"px\"> "
					                     + insertSpace(dynamicValue.replaceAll("\\^", " "))+ "</span>";
				} else {
					dynamicValue ="<div style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(dynamicValue) + "</div>";
				}
		} else {
			dynamicValue = "<div style = \"padding-left:"+tabVal+"px\"> "+ insertSpace(dynamicValue) + "</div>";
		}
		return dynamicValue;
	}


	private static String insertSpace(String dynamicValue) {
		if (dynamicValue.contains(">")) {
			dynamicValue = dynamicValue.replace(">", "&nbsp");
		}
		return dynamicValue;
	}


	private static String breakElement(String sCurrentLine, StringBuffer html) {
		String spacingVal;
		String breakStyle = null;
		if(sCurrentLine.contains(",")) {
			sCurrentLine = sCurrentLine.replace(",", ".");
		}
		
		if(sCurrentLine.length() > 3) {
		    spacingVal = sCurrentLine.substring(4);
			if(spacingVal.contains("mm")) {
				String breakVal = StringUtils.substringBefore(spacingVal, "mm");
				double intVal = Double.parseDouble(breakVal);
				double intmmVal = 3.77;
				spacingValue =  intVal*intmmVal;
				breakStyle = "<div style=\"padding-top:" +spacingValue+ "px\">";
			} else if(spacingVal.contains("i")) {
				String breakVal = StringUtils.substringBefore(spacingVal, "i");
				double intVal = Integer.parseInt(breakVal);
				double intmmVal = 96;
				spacingValue =  intVal*intmmVal;
				breakStyle = "<div style=\"padding-top:" +spacingValue+ "px\">";
			} else if (spacingVal.length() > 0) {
				Double spaceVal = Double.parseDouble(spacingVal);
				for (int index=1; index <= spaceVal ; index++) {
					html.append("</br>"); 
				}
				spacingValue = 10.0;
			} 
		}else  {
			spacingValue = 10.0;
			html.append("</br>"); 
		}
		
		return breakStyle;
	}
	

	private static void da(String sCurrentLine, StringBuffer html)
	{
		ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
		String[] words = sCurrentLine.split("\\s+");
		String rotateStyle = null;
		String fontStyle = null;
		for (int i = 0; i < words.length; i++) {
		    if(words[i].equalsIgnoreCase("rotate")){
		    	rotateStyle = "transform:rotate("+words[i+1]+"deg);";
		    }
		    if(words[i].equalsIgnoreCase("font")){
		    	// TODO : Hardcoded the font value
				fontStyle = "font-family:sans-serif;" ; 
		    }
		}
		html.append("<div style=\"padding-left:"+styleFinalVal.get(0)+"px;height: "
		                     +styleFinalVal.get(1)+"px;width: "+styleFinalVal.get(2)+"px;");
		if(null != rotateStyle) {
			html.append(rotateStyle);
			rotateStyle= null;
		}
		if(null != shadeVal) {
			html.append(shadeVal);
			shadeVal = null;
		}
		if(null != fontStyle) {
			html.append(fontStyle);
			fontStyle = null;
		}
		html.append("\">"); 
	}
    

	private static ArrayList<Double> retrievePaddingVal(String sCurrentLine) {
		String[] words = sCurrentLine.split("\\s+");
		ArrayList<String> styleVal = new ArrayList<String>();
		ArrayList<Double> finalStyleVal = new ArrayList<Double>();
		
		for (int i = 0; i < words.length; i++) {
			
		    if(words[i].contains("mm") || words[i].contains("i")) {
			   styleVal.add(words[i]);
		    }
		    if(words[i].equalsIgnoreCase("width") || words[i].equalsIgnoreCase("right")){
		    	styleVal.remove(words[i]);
			}
		}
		for(String strStyleVal : styleVal) {
			if(strStyleVal.contains("mm")) {
				strStyleVal = strStyleVal.substring(0, strStyleVal.length() - 2);
			
				if(strStyleVal.contains(",")) {
					strStyleVal = strStyleVal.replace(",", ".");
				}
				finalStyleVal.add(Double.valueOf(strStyleVal)*3.77);
		    } else if(strStyleVal.contains("i")) {
		    	strStyleVal = strStyleVal.substring(0, strStyleVal.length() - 1);
			
				if(strStyleVal.contains(",")) {
					strStyleVal = strStyleVal.replace(",", ".");
				}
					finalStyleVal.add(Double.valueOf(strStyleVal)*60);
		    }	
		}
		return finalStyleVal;
	}

}
