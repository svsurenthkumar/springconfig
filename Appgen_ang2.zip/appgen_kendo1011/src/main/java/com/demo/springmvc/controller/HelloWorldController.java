package com.demo.springmvc.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.ServletContext;

import org.apache.commons.cli.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tcs.insurance.tools.appgen.driver.AppGenDriver;

@Controller
public class HelloWorldController {
/*
	@Autowired
	MockServletContext  context;*/
		

@Autowired
ServletContext context;  


@Autowired
private ApplicationContext appContext;




@RequestMapping(value = "/jsongen", method = RequestMethod.GET)
public String BatchMain(Model model) throws IOException {		
	//model.addAttribute("lstUser", lstUser);
	
	String parentjson ="";
	String childjson ="";
	BufferedReader br = new BufferedReader(new FileReader("D:\\Appgen\\configHari\\config\\config\\lsa\\lsa.json"));
	System.out.println("11"+br);
	try {
	    StringBuilder sb = new StringBuilder();
	    String line = br.readLine();

	    while (line != null) {
	        sb.append(line);
	        sb.append(System.lineSeparator());
	        line = br.readLine();
	    }
	    parentjson = sb.toString();
	} finally {
	    br.close();
	}
	
	BufferedReader br1 = new BufferedReader(new FileReader("D:\\Appgen\\configHari\\config\\config\\lsa\\customerinformation.json"));
	try {
	    StringBuilder sb1 = new StringBuilder();
	    String line1 = br1.readLine();

	    while (line1 != null) {
	        sb1.append(line1);
	        sb1.append(System.lineSeparator());
	        line1 = br1.readLine();
	    }
	    childjson = sb1.toString();
	} finally {
	    br1.close();
	}
	
	System.out.println("parentJson"+parentjson);
	System.out.println("childJson"+childjson);
	model.addAttribute("parentJson", parentjson);
	model.addAttribute("childJson", childjson);
	
	return "batchscreen";
}





@RequestMapping(value = "/parentjsongen", method = RequestMethod.POST)
public @ResponseBody String ParentJson(Model model,@RequestParam(value = "config", required = false) String config,
		@RequestParam(value = "jsonvalue", required = false) String jsonvalue) throws ParseException, IOException {		
	
	
	System.out.println(jsonvalue);
	
	String text = jsonvalue;
	config=config+"\\lsa.json";
	String filename=config.replace("\\", "\\\\");
    BufferedWriter output = null;
    try {
        File file = new File(filename);
        output = new BufferedWriter(new FileWriter(file));
        output.write(text);
    } catch ( IOException e ) {
        e.printStackTrace();
    } finally {
      if ( output != null ) {
        output.close();
      }
    }
	
	return "batchscreen";
}





@RequestMapping(value = "/createsinglepage", method = RequestMethod.POST)
public @ResponseBody String createsinglepage(Model model,
		@RequestParam(value = "config", required = false) String config,
		@RequestParam(value = "pagename", required = false) String pagename
		) throws ParseException, IOException {		
	
	//System.out.println(config.replace("\\", "\\\\"));
	//appgen.initalsetup(config.replace("\\", "\\\\"), ref.replace("\\", "\\\\"), output.replace("\\", "\\\\"));
	
	System.out.println("pagename"+pagename);
	System.out.println("config"+config);
	
	String writer=config+"\\"+pagename+".json";
	String filename=writer.replace("\\", "\\\\");
	
	String defaultvalue="{'name': "+"'"+pagename+"',";
	defaultvalue+="'fieldsUsed': ['customer','headerInfo'],'firstLevel': 'Screen','secondLevel': 'Screen','tempFields': [],'actions': [],'screenElements': [  ],'buttons': []}";
	  BufferedWriter output = null;
	try {
        File file = new File(filename);
        	if (!file.exists()) {
                file.createNewFile();
            } 
            output = new BufferedWriter(new FileWriter(file));
            defaultvalue = defaultvalue.replaceAll("'", "\"");
            output.write(defaultvalue);
            output.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
	/*
	String text = jsonvalue;
	String writer=config+"\\customerinformation.json";
	String filename=writer.replace("\\", "\\\\");
    BufferedWriter output = null;
    try {
        File file = new File(filename);
        output = new BufferedWriter(new FileWriter(file));
        output.write(text);
    } catch ( IOException e ) {
        e.printStackTrace();
    } finally {
      if ( output != null ) {
        output.close();
      }
    }
    
    
   System.out.println(config.replace("\\", "\\\\"));
    AppGenDriver  appgen=new AppGenDriver();
    appgen.initalsetup(config.replace("\\", "\\\\"), ref.replace("\\", "\\\\"), outputconfig.replace("\\", "\\\\"));
	*/
	return "batchscreen";
}


@RequestMapping(value = "/retrievejson", method = RequestMethod.POST)
public @ResponseBody String Retrievejson(Model model,
		@RequestParam(value = "config", required = false) String config,
		@RequestParam(value = "pagename", required = false) String pagename
		) throws ParseException, IOException {		
	String childjson ="";
	String childjsonpath=config+"\\"+pagename+".json";
	BufferedReader br1 = new BufferedReader(new FileReader(childjsonpath));
	try {
	    StringBuilder sb1 = new StringBuilder();
	    String line1 = br1.readLine();

	    while (line1 != null) {
	        sb1.append(line1);
	        sb1.append(System.lineSeparator());
	        line1 = br1.readLine();
	    }
	    childjson = sb1.toString();
	} finally {
	    br1.close();
	}
	
	//model.addAttribute("childJson", childjson);
	
	return childjson;
}

@RequestMapping(value = "/childjsongen", method = RequestMethod.POST)
public @ResponseBody String childJson(Model model,
		@RequestParam(value = "config", required = false) String config,
		@RequestParam(value = "lib", required = false) String ref,
		@RequestParam(value = "output", required = false) String outputconfig,
		@RequestParam(value = "jsonvalue", required = false) String jsonvalue,
		@RequestParam(value = "pagename", required = false) String pagename
		
		) throws ParseException, IOException {		
	
	//System.out.println(config.replace("\\", "\\\\"));
	//appgen.initalsetup(config.replace("\\", "\\\\"), ref.replace("\\", "\\\\"), output.replace("\\", "\\\\"));
	
	System.out.println(jsonvalue);
	
	
	String text = jsonvalue;
	String writer=config+"\\"+pagename+".json";
	String filename=writer.replace("\\", "\\\\");
	
	System.out.println("filename"+filename);
    BufferedWriter output = null;
    try {
        File file = new File(filename);
        output = new BufferedWriter(new FileWriter(file));
        output.write(text);
    } catch ( IOException e ) {
        e.printStackTrace();
    } finally {
      if ( output != null ) {
        output.close();
      }
    }
    
    
   System.out.println(config.replace("\\", "\\\\"));
    AppGenDriver  appgen=new AppGenDriver();
    appgen.initalsetup(config.replace("\\", "\\\\"), ref.replace("\\", "\\\\"), outputconfig.replace("\\", "\\\\"));
	
	return "batchscreen";
}

	/*@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String HelloWorld(Model model) throws FileNotFoundException, IOException, URISyntaxException {		
		//model.addAttribute("lstUser", lstUser);t
		model.addAttribute("message", "Welcome to Spring MVC");
		System.out.println("called");
		
		
		return "hello";
	}
	
	@RequestMapping(value = "/forwardtree", method = RequestMethod.GET)
	public String D4ex(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		model.addAttribute("message", "Welcome to Spring MVC");
		return "d4ex";
	}
	
	
	@RequestMapping(value = "/backwardtree", method = RequestMethod.GET)
	public String BackwardTree(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		model.addAttribute("message", "Welcome to Spring MVC");
		return "backwardTree";
	}
	
	
	@RequestMapping(value = "/screen2", method = RequestMethod.GET)
	public String Screen2(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		return "screen2";
	}
	
	@RequestMapping(value = "/screen3", method = RequestMethod.GET)
	public String Screen3(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		return "screen3";
	}
	
	
	@RequestMapping(value = "/batchscreen", method = RequestMethod.GET)
	public String BatchMain(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		return "batchscreen";
	}
	@RequestMapping(value = "/mulitiupload", method = RequestMethod.GET)
	public String MulitUPload(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		return "screen4";
	}
	
	@RequestMapping(value = "/pdfanalysis", method = RequestMethod.GET)
	public String Pdfanalysis(Model model) {		
		//model.addAttribute("lstUser", lstUser);
		return "screen5";
	}
	
	
	 @RequestMapping("/save-product")
	    public String uploadResources( HttpServletRequest servletRequest,
	                                 @ModelAttribute Product product,
	                                 Model model)
	    {
	        //Get the uploaded files and store them
	        List<MultipartFile> files = product.getImages();
	        List<String> fileNames = new ArrayList<String>();
	        if (null != files && files.size() > 0)
	        {
	            for (MultipartFile multipartFile : files) {
	 
	                String fileName = multipartFile.getOriginalFilename();
	                fileNames.add(fileName);
	 
	                File imageFile = new File(servletRequest.getServletContext().getRealPath("/image"), fileName);
	                try
	                {
	                    multipartFile.transferTo(imageFile);
	                } catch (IOException e)
	                {
	                    e.printStackTrace();
	                }
	                
	                for(String filecase:fileNames)
	      		  {
	      			  System.out.println(filecase);
	      		  }
	            }
	        }
	 
	        // Here, you can save the product details in database
	         
	        model.addAttribute("product", product);
	        return "viewProductDetail";
	    }
	 
	@RequestMapping(value = "/mutlipfileupload", method = RequestMethod.POST)
	public String multiUpload(Model model, @ModelAttribute Product product) throws IOException {		
		System.out.println("testseteste");
		  List<MultipartFile> files = product.getImages();	
		  
			System.out.println("sizeeee"+files.size());
		  List<String> fileNames = new ArrayList<String>();
		  Hashtable<String,String> mapfiles=new Hashtable<String,String>();
		  if (null != files && files.size() > 0)
	        {
			  
			  System.out.println("testsete startt");
	            for (MultipartFile multipartFile : files) {
	                String fileName = multipartFile.getOriginalFilename();
	                String shortname=fileName;
	                 shortname = shortname.split("\\.")[0];
	               // mapfiles.put(fileName, value)
	                System.out.println("fileNameeeee::::::"+fileName);
	                fileNames.add(shortname+".html");
	                
	                InputStream is = multipartFile.getInputStream();
	        		InputStream second = multipartFile.getInputStream();
	     		   
	        		 Map<String,String> variableMap=new HashMap<String,String>();
	        		 dcfGeneratorRefactored ds=new dcfGeneratorRefactored();
	     		   String fileHtml=ds.buidHTML(is,fileName,variableMap,second);
	     		   mapfiles.put(fileName, fileHtml);
	     		   
//	     		   System.out.println("output:::"+fileHtml);
	     			
	     			
	            }
	        }
		  System.out.println("totalvalue"+mapfiles);
		  
		  Gson gson = new Gson();
	        String txtToHtml = gson.toJson(mapfiles);
	        
	        String fileslist = gson.toJson(fileNames);
	        
		  for(String filecase:fileNames)
		  {
			  System.out.println(filecase);
		  }
		  
		  
		
			model.addAttribute("txtToHtml", txtToHtml);
			model.addAttribute("fileslist", fileslist);
			//model.addAttribute("lstUser", count);
			//System.out.println("files:::::"+fileslist);
		  System.out.println("end");
		  
		return "screen4";
	}
	
	
	@RequestMapping(value = "/batchcall", method = RequestMethod.POST)
	public @ResponseBody String BatchScreen(Model model,@RequestParam(value = "source", required = false) String source,
			@RequestParam(value = "destination", required = false) String destination) {	
		System.out.println("source::"+source+"Destination"+destination);
		dcfGeneratorRefactored ds=new dcfGeneratorRefactored();
		String count=ds.batchRun(source,destination);
		List<String> fileslist=new ArrayList<String>();
		File dir = new File(destination);
		String[] files = dir.list();
		for (String aFile : files) 
		   {
			fileslist.add(aFile);
		   }
		//model.addAttribute("files", fileslist);
		//model.addAttribute("lstUser", count);
		//System.out.println("files:::::"+fileslist);
		 Gson gson = new Gson();
	        String trxdetails = gson.toJson(fileslist);
		return trxdetails;
	}
	
	@RequestMapping(value = "/htmlConverter", method = RequestMethod.POST)
	public @ResponseBody String HtmlConverter(Model model,@RequestParam(value = "htmlcontent", required = false) String htmlcontent) throws IOException, URISyntaxException {		
		//model.addAttribute("lstUser", lstUser);
			
		
		Resource resource =appContext.getResource("classpath:dcf.txt");
		InputStream is = resource.getInputStream();
		InputStream second = resource.getInputStream();
			
		URL resourceUrl=resource.getURL();
		 //File file = new File("D:\\project_spring\\src0109\\src\\main\\java\\com\\demo\\springmvc\\controller\\dcf.txt");
		 File file = new File(resourceUrl.getFile());
	      // creates a FileWriter Object
	      FileWriter writer = new FileWriter(file); 
	      // Writes the content to the file
	      writer.write(htmlcontent); 
	      writer.flush();
	      writer.close();
	      dcfGeneratorRefactored crea =new dcfGeneratorRefactored();
		//DCF2HTML creation=new DCF2HTML();
	      Map<String,String> variableMap=new HashMap<String,String>();
		return crea.buidHTML(is,"",variableMap,second);
	}

	@RequestMapping(value = "/processExcel", method = RequestMethod.POST)
	public String processExcel(Model model, @RequestParam("excelfile") MultipartFile files) {		
		try {
			List<UserInfo> lstUser = new ArrayList<UserInfo>();
			int i = 0;
			// Creates a workbook object from the uploaded excelfile
			HSSFWorkbook workbook = new HSSFWorkbook(files.getInputStream());
			// Creates a worksheet object representing the first sheet
			HSSFSheet worksheet = workbook.getSheetAt(0);
			// Reads the data in excel file until last row is encountered
			while (i <= worksheet.getLastRowNum()) {
				// Creates an object for the UserInfo Model
				UserInfo user = new UserInfo();
				// Creates an object representing a single row in excel
				HSSFRow row = worksheet.getRow(i++);
				// Sets the Read data to the model class
				user.setId((int) row.getCell(0).getNumericCellValue());
				user.setUsername(row.getCell(1).getStringCellValue());
//				user.setInputDate(row.getCell(2).getDateCellValue());
				// persist data into database in here
				lstUser.add(user);
			}			
			workbook.close();
			model.addAttribute("lstUser", lstUser);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "hello";	
	}
	
	@RequestMapping(value = "/hello", method = RequestMethod.POST)
	public String processExcel2007(Model model, @RequestParam("filestest") MultipartFile excelfile) {		
		try {
			System.out.println("******************File Upload Start*****************");
			List<UserInfo> lstUser = new ArrayList<UserInfo>();
			List<FormList> formList = new ArrayList<FormList>();
			List<TextBlock> textBlockNumList = new ArrayList<TextBlock>();
			List<TextBlock> textBlockATKList = new ArrayList<TextBlock>();
			List<TextBlock> textBlockLTZNumList = new ArrayList<TextBlock>();
			int i = 0;	
			// Creates a workbook object from the uploaded excelfile
			XSSFWorkbook workbook = new XSSFWorkbook(excelfile.getInputStream());
			// Creates a worksheet object representing the first sheet
			XSSFSheet worksheet = workbook.getSheetAt(0);
			// Reads the data in excel file until last row is encountered
			while (i <= worksheet.getLastRowNum()) {
				UserInfo user = new UserInfo();
				// Creates an object representing a single row in excel
				XSSFRow row = worksheet.getRow(i++);
				if(i>1)
				{
				// Creates an object for the UserInfo Model
				
				// Sets the Read data to the model class
				user.setId((int) row.getCell(0).getNumericCellValue());
				user.setUsername(row.getCell(1).getStringCellValue());
//				user.setInputDate(row.getCell(2).getDateCellValue());
				// persist data into database in here
				lstUser.add(user);
				System.out.println("Sheet1");
				}
			}		
			XSSFSheet worksheet1 = workbook.getSheetAt(1);
			int ii=0;
			//sheet two
			while (ii <= worksheet1.getLastRowNum()) {
				// Creates an object for the UserInfo Model
				FormList formListvalue = new FormList();
				// Creates an object representing a single row in excel
				XSSFRow row1 = worksheet1.getRow(ii++);
				if(ii>1)
				{
				// Sets the Read data to the model class
				formListvalue.setFormName(row1.getCell(0).getStringCellValue());
				formListvalue.setFormDesc(row1.getCell(1).getStringCellValue());
				
				String s2=String.valueOf(row1.getCell(2).getNumericCellValue());
				String s2dot = s2.split("\\.")[0];
				formListvalue.setAunr(s2dot);
				formListvalue.setSstbinr(row1.getCell(5).getStringCellValue());
				formListvalue.setSstbbz(row1.getCell(6).getStringCellValue());
				String s1=String.valueOf(row1.getCell(8).getNumericCellValue());
				String extensionRemoved = s1.split("\\.")[0];
				formListvalue.setSstbsnr(extensionRemoved);
				
//				user.setInputDate(row.getCell(2).getDateCellValue());
				// persist data into database in here
				formList.add(formListvalue);
				}
				//System.out.println("Sheet2");
			}
			int iii=0;
			XSSFSheet worksheet2 = workbook.getSheetAt(2);
			//sheet three
			while (iii <= worksheet2.getLastRowNum()) {
				// Creates an object for the UserInfo Model
				TextBlock formListvalue = new TextBlock();
				// Creates an object representing a single row in excel
				XSSFRow row2 = worksheet2.getRow(iii++);
				if(iii>1)
				{
				// Sets the Read data to the model class
				formListvalue.setTextBlockName(row2.getCell(0).getStringCellValue());
					if(row2.getCell(1).getCellType() == XSSFCell.CELL_TYPE_STRING)
					{
						formListvalue.setOrderInfoNum(Integer.parseInt(row2.getCell(1).getStringCellValue()));
					}
					else
					{
					formListvalue.setOrderInfoNum(row2.getCell(1).getNumericCellValue());
					}
				//System.out.println(row2.getCell(2).getStringCellValue());
				
				if( row2.getCell(2)==null)
				{
				formListvalue.setContentInfo("");
				}
				else
				{
//					System.out.println(row2.getCell(2).getStringCellValue());
					formListvalue.setContentInfo(row2.getCell(2).getStringCellValue());
				}
//				user.setInputDate(row.getCell(2).getDateCellValue());
				// persist data into database in here
				textBlockNumList.add(formListvalue);
				}
				//System.out.println("Sheet3");
			}
			XSSFSheet worksheet3 = workbook.getSheetAt(3);
			//sheet four
			while (i <= worksheet3.getLastRowNum()) {
				// Creates an object for the UserInfo Model
				TextBlock formListvalue = new TextBlock();
				// Creates an object representing a single row in excel
				XSSFRow row3 = worksheet3.getRow(i++);
				// Sets the Read data to the model class
				formListvalue.setTextBlockName(row3.getCell(0).getStringCellValue());
				formListvalue.setOrderInfo(row3.getCell(1).getStringCellValue());
				if( row3.getCell(2)==null)
				{
				formListvalue.setContentInfo("");
				}
				else
				{
//					System.out.println(row2.getCell(2).getStringCellValue());
					formListvalue.setContentInfo(row3.getCell(2).getStringCellValue());
				}
				
//				user.setInputDate(row.getCell(2).getDateCellValue());
				// persist data into database in here
				textBlockATKList.add(formListvalue);
				System.out.println("Sheet4");
			}
			
			XSSFSheet worksheet4 = workbook.getSheetAt(4);
			//sheet five
			while (i <= worksheet4.getLastRowNum()) {
				// Creates an object for the UserInfo Model
				TextBlock formListvalue = new TextBlock();
				// Creates an object representing a single row in excel
				XSSFRow row4 = worksheet4.getRow(i++);
				// Sets the Read data to the model class
				formListvalue.setTextBlockName(row4.getCell(0).getStringCellValue());
				formListvalue.setOrderInfo(row4.getCell(1).getStringCellValue());
				if( row4.getCell(2)==null)
				{
				formListvalue.setContentInfo("");
				}
				else
				{
//					System.out.println(row2.getCell(2).getStringCellValue());
					formListvalue.setContentInfo(row4.getCell(2).getStringCellValue());
				}
				
//				user.setInputDate(row.getCell(2).getDateCellValue());
				// persist data into database in here
				textBlockLTZNumList.add(formListvalue);
				System.out.println("Sheet5");
			}
			
			workbook.close();
			ObjectMapper<List<UserInfo>> obj=new ObjectMapper<List<UserInfo>>();
			objectset = obj.writeValueAsString(lstUser);

			 Gson gson = new Gson();
		        String trxdetails = gson.toJson(lstUser);
		        String formListdetails = gson.toJson(formList);
		        
		        String textBlockNum = gson.toJson(textBlockNumList);
		        String textBlockATK = gson.toJson(textBlockATKList);
		        String textBlockLTZNum = gson.toJson(textBlockLTZNumList);
		        
		      // System.out.println(formListdetails);
		        
Gson gson = new Gson();
TypeToken<List<UserInfo>> token = new TypeToken<List<UserInfo>>() {};
List<UserInfo> commentsList = gson.fromJson(lstUser, token.getType());​

			model.addAttribute("lstUser", trxdetails);
			model.addAttribute("formListdetails", formListdetails);
			model.addAttribute("textBlockNum", textBlockNum);
			//System.out.println("textBlockNum:::"+textBlockNum);
			model.addAttribute("textBlockATK", textBlockATK);
			model.addAttribute("textBlockLTZNum", textBlockLTZNum);
			
			//System.out.println(textBlockLTZNum);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("******************File Upload End*****************");
		return "hello";
	}*/

}