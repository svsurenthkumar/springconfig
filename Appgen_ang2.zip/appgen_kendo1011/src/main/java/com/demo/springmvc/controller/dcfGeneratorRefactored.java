package com.demo.springmvc.controller;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

public class dcfGeneratorRefactored {
	
	private static  int completedIncrementor = 0;
	private static  int notCompletedIncrementor = 0;
	private static 	Double spacingValue = 0.0;
	private static String shadeVal = null;
	private static int tabVal = 1;
	private static ArrayList<Double> tpStyleVal = null;
	private static String outdir  = "D:\\Workspace\\DCFtoHTML\\Dcf\\DCF Source\\SampleOutput\\";


	/*public static void main(String[] args) throws IOException {
		
		String dirPath = "D:\\Workspace\\DCFtoHTML\\Dcf\\DCF Source\\SampleInput\\"; 
		String reportFile = "D:\\Workspace\\DCFtoHTML\\Dcf\\DCF Source\\OUTPUT\\report.csv";
		String variablefilename = "D:\\project_spring\\variablestext.txt";
		File dir = new File(dirPath);
		String[] files = dir.list();
		StringBuffer report = new StringBuffer();
		report.append("FileName,Completed Line,Not Completed Line,Total Line,% of Completed, TimeStamp");
		report.append("\n");
		String output="";
		DCFHandling   dcfHandling = new  DCFHandling();
		Map<String,String> globalVariableMap=dcfHandling.getGlobalVariableMap(variablefilename);
		
		if (files.length == 0) {
		   System.out.println("The directory is empty");
		} else {
		   for (String aFile : files) {
			   String fileshortname=aFile.split("\\.")[0];
		       //buidHTML(dirPath+"\\"+aFile,fileshortname,globalVariableMap);
		       
		       output= fileshortname+","+completedIncrementor+","+notCompletedIncrementor 
		                 +","+(notCompletedIncrementor+completedIncrementor)+", ,"+ new Date();
		       report.append(output);
		       completedIncrementor = 0;
		   	   notCompletedIncrementor = 0;
		       report.append("\n");
		   }
		}
		
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File(reportFile)));
		bufferedWriter.write(report.toString()); 
		 //flush the stream
		bufferedWriter.flush();
        //close the stream
		bufferedWriter.close();
		
	}*/

	
	
	public String batchRun(String source,String destination)
	{
		
		String dirPath = source;
		String variablefilename = "D:\\variablestext.txt";
		File dir = new File(dirPath);
		String[] files = dir.list();
		DCFHandling   dcfHandling = new  DCFHandling();
		Map<String,String> globalVariableMap=dcfHandling.getGlobalVariableMap(variablefilename);
		int processedFileCount=0;
		try {
			if (files.length == 0) 
			{
			   System.out.println("The directory is empty");
			} 
			else 
			{
			   for (String aFile : files) 
			   {
				   String fileshortname=aFile.split("\\.")[0];
				   FileInputStream fstream;
				   fstream = new FileInputStream(dirPath+"\\"+aFile);
				   
				   DataInputStream in = new DataInputStream(fstream);
				   FileInputStream fstream1 = new FileInputStream(dirPath+"\\"+aFile);
				   DataInputStream second = new DataInputStream(fstream1);
				   
				   String fileHtml=buidHTML(in,fileshortname,globalVariableMap,second);
				   
				   
				   BufferedWriter bwr = new BufferedWriter(new FileWriter(new File(destination+fileshortname+".html")));
				   bwr.write(fileHtml);
				   bwr.flush();
				   bwr.close();
				   processedFileCount++;
		             
			   }		  
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return "No Of Files Processed "+processedFileCount;
		
	}
	

		public String buidHTML(InputStream in,String fileshortname,Map<String,String> variableMaps,InputStream second) {
		  	String variablefilename = "D:\\variablestext.txt";
		  	DCFHandling   dcfHandling = new  DCFHandling(); 
			Map<String,String> globalVariableMap=dcfHandling.getGlobalVariableMap(variablefilename);
			//System.out.println(globalVariableMap); 
			int patternfixedcount = 0;
			String reportout="";
			String fontStyle = null;
			String indentStyle = null;
			String foStyle = null;
			Double previousIndentStyle = 0.0;
			int indentStyleIncrementor = 0;
			String breakStyle = null;
			int centerAlignIncrementor = 0;
			String centerSwitch = "dummy";
			String returnvalue="";
			BufferedReader bufferedReader = null;
			FileReader fileReader = null;
			boolean isBxAvailable = Boolean.FALSE;
		
		
		DCFVariableHandling dcfVariableHandling= new DCFVariableHandling();
		
		String sub_sup_script_Flag="";
		String sCurrentLine = null;
		Map<String,String> fileVariableMap = dcfVariableHandling.collectVaribales(in, globalVariableMap);
		int linenumber=0;
		
		/**
		 * Variables for the IF Block Extraction
		 */
		Map<Integer,List<String>> ifMap = new HashMap <Integer,List<String>>();
		Integer ruleIntegator=0;
		boolean ifFlag=false;
		
		
		/**
		 * Variables Created for the .td table , .ta  Data Patterns
		 */
		String tableName="";
		String tableDataName="";
		Map<String,List<String>> tableDefMap= new HashMap<String,List<String>>();
		Map<String,List<String>> tableDataMap= new HashMap<String,List<String>>();
		Map<String,Double> tableWidthMap=new HashMap<String,Double>();
		boolean tableData=false;
		
		/**
		 * Variable created for the non DCF Process Data 
		 */
		
		String staticLineData="";
		boolean staticData= false;
		
		
		String processcaret ="";
		boolean caretflag=false;
		
		
		try {
			String centerOrUnderlineStyle = null; 
			StringBuffer html = new StringBuffer();
			dcfHandling.setLayout(html);

			ArrayList<Double> tpParm = new ArrayList<Double>(); 
			//FileInputStream fstream = new FileInputStream(FILENAME);
			//DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(second , Charset.forName("windows-1252")));
		      
			while ((sCurrentLine = br.readLine()) != null) {
				
				sCurrentLine=StringUtils.stripToEmpty(sCurrentLine);				
				linenumber++;			
				

				if (StringUtils.startsWithIgnoreCase(sCurrentLine, "\"")) {
					sCurrentLine=sCurrentLine.replace("\"", "");
				}
				
				if (StringUtils.startsWithIgnoreCase(sCurrentLine, "\'")) {
					sCurrentLine=sCurrentLine.replace("\'", "");
				}
				
				sCurrentLine=StringUtils.stripToEmpty(sCurrentLine);	
				
				
				if (sCurrentLine.startsWith(".*") || sCurrentLine.startsWith("\".*")) 
				{
					completedIncrementor++;
					continue;
				}
				
				else if	(  StringUtils.startsWithIgnoreCase(sCurrentLine, ".'SE ") 
					|| StringUtils.startsWithIgnoreCase(sCurrentLine, ".SE ")) 
				{
			    	completedIncrementor++;
					continue;
				}
				
				if(sCurrentLine.startsWith("...")) 
				{
			    	 String divid=sCurrentLine.split("\\...")[1];
//			    	 html.append("<div id=\""+divid+"\" style=\"color:blue;\" class=\"tooltip linebreak\" > "+divid+"  <span class=\"tooltiptext\">Start:"+divid+"</span> </div>");
			    	 completedIncrementor++;
					 continue;
			    }
				
				
		
				/**
				 * BausteineA16 As per Shriram Request changed data { ==> ä and } ==> ü 
				 */
				
				if(StringUtils.equalsIgnoreCase(fileshortname,"BausteineA16"))
				{
					if(  StringUtils.contains(sCurrentLine,"{") )
					{
						sCurrentLine =sCurrentLine.replaceAll("\\{", "ä");
						
					}
					if (StringUtils.contains(sCurrentLine,"}") )
					{
						sCurrentLine =sCurrentLine.replaceAll("\\}", "ü");
					}
				}
				
				

				/**
				 * Static Line Process Block Start 
				 */
				
				
				if  (StringUtils.contains(sCurrentLine, "^") && 
					(!StringUtils.startsWithIgnoreCase(sCurrentLine, ".ct")) && 
					(!StringUtils.startsWithIgnoreCase(sCurrentLine, ".")) && !tableData){
					processcaret +=" "+sCurrentLine;
					caretflag=true;
					continue;
				}
				
				if((!StringUtils.startsWithIgnoreCase(sCurrentLine, ".")) && (!StringUtils.startsWithIgnoreCase(sCurrentLine, "^"))&& !tableData){
					staticLineData += " "+sCurrentLine;
					staticData=true;
					if(caretflag) processcaret +=" "+sCurrentLine;
					
					continue;
				}
				
				
				if(caretflag){
					dcfHandling.processcaret(html,processcaret,tpParm, tabVal,sub_sup_script_Flag,fileVariableMap,globalVariableMap,true, isBxAvailable);
					caretflag=false;
					processcaret="";
					if(staticData) {
						staticData =false;
						staticLineData="";
					} 
				}
				
				
				
				if(staticData){
					//processNonDCFLine with out and start a .
					dcfHandling.processNonDCFLine(html, staticLineData, previousIndentStyle, indentStyleIncrementor,centerAlignIncrementor ,
							indentStyle ,centerOrUnderlineStyle , centerSwitch, fontStyle, foStyle,breakStyle,sub_sup_script_Flag,globalVariableMap,fileVariableMap);
					staticData=false;
					staticLineData="";
					completedIncrementor++;	 
				}

				/**
				 * Static Line Process Block End 
				 */
				
				
				
				/**
				 * If Extraction Block Start 
				 * 
				 */
				
				if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".IF ")){
					if(!ifFlag)ruleIntegator=ruleIntegator +1;
					ifFlag=true;
				}
				
				
				if  ( StringUtils.startsWithIgnoreCase(sCurrentLine, ".IF ") || StringUtils.startsWithIgnoreCase(sCurrentLine, ".EL ")
				   || StringUtils.startsWithIgnoreCase(sCurrentLine, ".TH ") || StringUtils.startsWithIgnoreCase(sCurrentLine, ".OR ")
				   || StringUtils.startsWithIgnoreCase(sCurrentLine, ".AN "))
				{
					
					List<String> ifList= new ArrayList<String>();
					if(ifMap.containsKey(ruleIntegator)){
						ifList=ifMap.get(ruleIntegator);
					}else{
						html.append("<div id=\"Rule"+ruleIntegator+"\" ><a href=\"#Rule"+ruleIntegator+"\"> Rule"+ruleIntegator+" </a> </div>");
					}
					ifList.add(sCurrentLine);
					ifMap.put(ruleIntegator, ifList);
					continue;
				}else{ 
					ifFlag=false;
				}
				
				/**
				 * If Extraction Block End 
				 * 
				 */

				sCurrentLine=StringUtils.stripToEmpty(sCurrentLine);	
				
				/**
				 * Table Definition Block  Extraction Block Start 
				 * 
				 */
				
				/**
				 * All the Line Starts with .td will go into this below Block
				 * We are Capturing all the line content in the Map Except the .td Cell content
				 *   tableDefMap == > Map < TableName, List< Table Definition Line> >				 *  
				 */
				
				if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".td ")) 
				{	
					if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".td table"))
					{
						String tabledefdata=StringUtils.stripToEmpty(sCurrentLine.substring(10));
						String[] tableDefSplits=tabledefdata.split("\\s+");
						tableName=tableDefSplits[0];  
						if(tableDefMap.containsKey(tableName)){
//							System.err.println("Same Table Defined twise in "+fileshortname+" TableName :"+tableName+"\t"+linenumber+"\n"+tableDefMap.get(tableName));
						}
						
						int i=0;
						for(String s:tableDefSplits){
							System.out.println(s);
							if(StringUtils.equalsIgnoreCase(s, "width")){
								String width=tableDefSplits[i+1].replaceAll("[a-zA-Z]", "").trim();
								double widthValue=Double.valueOf(width)*3.77;
								tableWidthMap.put(tableName, widthValue);
								break;
							}
							i++;
						}
						
						continue;
					}
					else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".td row") && StringUtils.isNotBlank(tableName))
					{
						
						List<String> tableRowDef = new ArrayList<String>();
						if(tableDefMap.containsKey(tableName))
						{
							tableRowDef =tableDefMap.get(tableName);
						}
						String tableRowData=StringUtils.stripToEmpty(sCurrentLine.substring(8));
						tableRowDef.add(tableRowData);
						tableDefMap.put(tableName, tableRowDef);
						continue;
					}
					else  if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".td cell") && StringUtils.isNotBlank(tableName))
					{
						//do nothing
						continue;
					}else{
						System.err.println("Error in the table Definiation Condition Sample Code :"+sCurrentLine+"\t"+fileshortname+"\t"+linenumber);
						continue;
					}
				}

				/**
				 * Table Definition Block  Extraction Block End 
				 * 
				 */
				
				
				

				/**
				 * Table Data Block Processing Block Start 
				 * 
				 */
				
				/**
				 * All the Line Starts with .ta table will go into this below Block
				 * We are just Using this Block to switch on the Table Data flag to ON/OFF
				 * While Switch OFF the table Data Flag we are calling the Table Data Processing function with the arguments of 
				 * TableData Map and TableDef Map and TableName to process it.   
				 */
				if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".ta table")) 
				{	
					if( StringUtils.containsIgnoreCase(sCurrentLine, " on")) 
					{					
						tableData=true;
						String tabledefdata=StringUtils.stripToEmpty(sCurrentLine.substring(10));
						tableDataName=tabledefdata.split("\\s+")[0];
						continue;
					}
					else if(StringUtils.containsIgnoreCase(sCurrentLine, " off"))
					{
						String tableWidth="100%";
						if(tableWidthMap.containsKey(tableName)) tableWidth=tableWidthMap.get(tableName)+"px";
						String tableString=new DCFTableProcessing().processTableDataContent(tableDefMap, tableDataMap,tableDataName, tableWidth);
						html.append(tableString);
						tableData=false;
						tableDataName="";
						continue;
					}
				}
				
				
				/**
				 * The Blow Block will execute only when the Table Data flag is ON with the tableDataName
				 * This Block will add all the table Data  content into the Map
				 *  tableDataMap ==> Map<tabledataName,List<Tabledata Lines> >
				 *  This is the Map we used to process the content.
				 */
				
				if(tableData && StringUtils.isNotBlank(tableDataName))
				{
					List<String> tableDataList=new ArrayList<String>();				
					if(tableDataMap.containsKey(tableDataName))
					{
						tableDataList=tableDataMap.get(tableDataName);
					}
					tableDataList.add(sCurrentLine);
					tableDataMap.put(tableDataName, tableDataList);
					continue;
				}

				/**
				 * Table Data Block Processing Block End 
				 * 
				 */

				
				
				
				/**
				 * Pattern Processing Block Starts
				 * 
				 */
				
				if(sCurrentLine.startsWith("...")) 
				{
			    	 String divid=sCurrentLine.split("\\...")[1];
//			    	 html.append("<div id=\""+divid+"\" style=\"color:blue;\" class=\"tooltip linebreak\" > "+divid+"  <span class=\"tooltiptext\">Start:"+divid+"</span> </div>");
			    	 completedIncrementor++;
					 continue;
			    }
				else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".KP ON") 
					|| StringUtils.startsWithIgnoreCase(sCurrentLine, ".KP OFF")) 
				{
					completedIncrementor++;
					continue;
				}
			    /*else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".IF ") 
			    	||StringUtils.startsWithIgnoreCase(sCurrentLine, ".EL ")) {
					html.append("<div style=\"color:blue;\" class='tooltip linebreak'> "+dcfHandling.retriveDynamicVariable(globalVariableMap,fileVariableMap, sCurrentLine)+"<span class=\"tooltiptext\">"+sCurrentLine+"</span></div>");
					completedIncrementor++;
					continue;
			    }
				else if( StringUtils.startsWithIgnoreCase(sCurrentLine, ".AN ")
					||  StringUtils.startsWithIgnoreCase(sCurrentLine, ".OR ")) 
				{
					html.append("<div style=\"color:Grey;\" class='tooltip linebreak'>"+dcfHandling.retriveDynamicVariable(globalVariableMap,fileVariableMap, sCurrentLine)+"<span class=\"tooltiptext\">"+sCurrentLine+"</span></div>");
					completedIncrementor++;
					continue;
			    }*/
			    else if (  	StringUtils.startsWithIgnoreCase(sCurrentLine, ".sb OFF") 
			    		|| 	StringUtils.startsWithIgnoreCase(sCurrentLine, ".sb 0") 
			    		||	StringUtils.equalsIgnoreCase(sCurrentLine, ".sb") ) 
				{
			    	 sub_sup_script_Flag="";
			    	 completedIncrementor++;
			    	 continue;
			    	 
				}
			    else if (StringUtils.startsWithIgnoreCase(sCurrentLine,".sb ") ) 
				{
						if (StringUtils.containsIgnoreCase(sCurrentLine, "+") )
						{
							sub_sup_script_Flag = "sup";
						}else if (StringUtils.containsIgnoreCase(sCurrentLine, "-") )
						{
							sub_sup_script_Flag = "sub";
						}else{
							sub_sup_script_Flag = "sup";
						}
						completedIncrementor++;
						continue;
				}

				else if (StringUtils.containsIgnoreCase(sCurrentLine, ".TP ")) 
				{
					tpParm = new ArrayList<Double>();							
					tpParm = retrievePaddingVal(sCurrentLine);
					completedIncrementor++;
					continue ;
				}
			    else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".IM ")) 
			    { 
			    	/*
			    	html.append("<div style=\"color:blue;\" class='tooltip linebreak'> "
					+sCurrentLine +"<span class=\"tooltiptext\"> Imbed function - "
					+sCurrentLine+" is called. Once excuted next line is processed.</span></div>");*/
						
					completedIncrementor++;
					continue;
			    }
			    else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".GO ")) {
			    	String goDivId=sCurrentLine.split("\\s+")[1];
//					html.append("<div style=\"color:green;\" class='linebreak' > <a href=\"#"+goDivId+"\"> GOTO :: "+goDivId+" </a></div>");
					completedIncrementor++;
					continue;
			    } 
			    else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".BR")) 
			    {
					html.append("</br>" );
					completedIncrementor++;
					continue;
				}
			    else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".CT ")) 
			    { 
					//Checking previously the HTML has ended with Table
					if(html.substring(html.length()-20).contains("</table>"))
					{  
						 String previousText = html.substring(0,html.lastIndexOf("</td>"));
						 String nextText = html.substring(html.lastIndexOf("</td>"));	
						 html= new StringBuffer();	
						 sCurrentLine = sCurrentLine.replace(".CT", "");
						 sCurrentLine = sCurrentLine.replace(".ct", "");
						 if(StringUtils.isNotBlank(previousText))html.append(previousText);
						 //its for the below sample code 
						 //.CT data1^data2 
						 if(StringUtils.countMatches(sCurrentLine, "^") >= 1){
							 sCurrentLine=StringUtils.trimToEmpty(sCurrentLine);							 
							 dcfHandling.processcaret(html,sCurrentLine,tpParm, tabVal,sub_sup_script_Flag,fileVariableMap,globalVariableMap,false, isBxAvailable);  
						 }else{
							 displayString( sCurrentLine, html,sub_sup_script_Flag,globalVariableMap,fileVariableMap);
						 } 
						 if(StringUtils.isNotBlank(nextText))html.append(nextText);
					}
					//Checking previously the HTML has ended with DIV
					else 
					{
						String previousText = html.substring(0,html.lastIndexOf("<div"));
						String nextText = html.substring(html.lastIndexOf("<div"));
						String subnextText="";
						if(nextText.indexOf("</div>") !=-1){
							subnextText=nextText.substring(0,nextText.indexOf("</div>"));
						}
						html= new StringBuffer();
						html.append(previousText);
						html.append(nextText);
						sCurrentLine = sCurrentLine.replace(".CT", "");
						sCurrentLine = sCurrentLine.replace(".ct", "");
						displayString( sCurrentLine, html,sub_sup_script_Flag,globalVariableMap,fileVariableMap);
						html.append(subnextText);
					} 
					completedIncrementor++;
					continue;
				}
				
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".SD "))
				{
					String[] words = sCurrentLine.split("\\s+");
					int shadePercentage = 0;
					 // TODO need to get the shade definition and 25 ? grey percentage value ? standard 
					for (int i= 0; i < words.length; i++) {
						if(words[i].equalsIgnoreCase("shade")) {
							  if( words[i+1].matches(".*\\d+.*")){ // Checking the String Contains only Number  
								  shadePercentage = Integer.parseInt(words[i+1]);
							  }
							// TODO: hardcoded light grey
							shadeVal = "background-color:lightgrey;";
						}
					}
					completedIncrementor++;
					continue;
				}
				
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".BF "))
				{
					String fontFamily = sCurrentLine.substring(4);
					// As of now hardcoded need to get the exact html font family
					  fontFamily = "sans-serif;";
					  fontStyle = "font-family: "+ fontFamily;
//					  fontStyle = "<div id=\"CETPBTRF60\"" + " style=\"font-family:" + fontFamily + "\">" ; 
					completedIncrementor++;
					continue ;
				}
				
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".IN ")) 
				{
					String[] words = sCurrentLine.split("\\s+");
					if(words.length >=2 && StringUtils.isNotBlank(words[1])) {	
						String strStyleVal="";
						strStyleVal= words[1].replaceAll("[a-zA-Z]", "").trim();
						if(strStyleVal.indexOf("\\.")== strStyleVal.length()-1) strStyleVal= strStyleVal.replaceAll("\\.", "");
						
						previousIndentStyle = indentStyleGen(previousIndentStyle, words); 
						
						if(!words[1].contains("+") && !words[1].contains("-") && strStyleVal.matches("(\\.\\d+)|\\d+(\\.\\d+)*")) {
							if(StringUtils.containsIgnoreCase(words[1],"mm")) { 
							   previousIndentStyle = Double.valueOf(strStyleVal)*3.77;
						    } else if (StringUtils.containsIgnoreCase(words[1],"i")) {
						    	previousIndentStyle = Double.valueOf(strStyleVal)*60;
						    } else {
						    	previousIndentStyle = Double.valueOf(strStyleVal)*2;
						    }
						}	
						
					}
					if(words.length == 4) {
						if(StringUtils.containsIgnoreCase(words[3],"i")) {
							int indentCount = Integer.parseInt(words[3].replaceAll("i", ""));
							indentStyleIncrementor = (indentCount*60)/20;
						}
					}
					if(previousIndentStyle > 0 && indentStyleIncrementor == 0) {
						indentStyle = "<div style=\" padding-left:"+ previousIndentStyle +" px\">";
					} 
					completedIncrementor++;
					continue ;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".TI ")) 
				{
					String[] words = sCurrentLine.split("\\s+");
					if(StringUtils.isNotBlank(words[2]) && words[2].matches("[0-9]*")) {	
						// Assuming 1 tab = 10 Px
						tabVal = Integer.parseInt(words[2])*10;
					}
					completedIncrementor++;
					continue ;
				} 
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".SP")) 
				{
					breakStyle = breakElement(sCurrentLine, html);
					completedIncrementor++;
					continue ;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".SK")) 
				{
//					System.out.println("sCurrentLine"+sCurrentLine);
					html.append("</br>");
					completedIncrementor++;
					continue ;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".DA "))
				{
					da(sCurrentLine,html);
					completedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".HR "))
				{
					
					if(sCurrentLine.contains("left")) {
						ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
						if(styleFinalVal.size() >=1)
						html.append("<hr style = \"margin-left:"+styleFinalVal.get(0)+"px\">");
					} else if(sCurrentLine.contains("right")) {						
						ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
						if(styleFinalVal.size() >=1)
						html.append("<hr style = \"margin-left:"+styleFinalVal.get(0)+"px\">");
					} else {
						hrLeftAndRightStyle(sCurrentLine, html);
					}
					completedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".AR "))
				{
					completedIncrementor++;
					if(StringUtils.containsIgnoreCase(sCurrentLine,"on")) {
						continue;
					}
					else if(StringUtils.containsIgnoreCase(sCurrentLine,"off")) 
					{	
						html.append("</div>");
						continue;
					}
					else
					{
						System.err.println("Error In AR logic : "+fileshortname+"\t"+sCurrentLine );
					}
					
				} 
				
				else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".CE ") 
					 || StringUtils.startsWithIgnoreCase(sCurrentLine, ".US ") )
				{
					
					 completedIncrementor++;
					 String[] strCurrentLine = null;
					 strCurrentLine = 	 sCurrentLine.split(" ");
					 
					 if(strCurrentLine.length == 1) {
						 centerOrUnderlineStyle = applyStyle(sCurrentLine);
						 
					 } else if(StringUtils.isNotBlank(strCurrentLine[1])  && 
							  (StringUtils.containsIgnoreCase(sCurrentLine, " on") 
							|| StringUtils.containsIgnoreCase(sCurrentLine, " off") 
							|| strCurrentLine[1].matches("[0-9]*") ) ) {
						 
						 if(strCurrentLine[1].equalsIgnoreCase("on")) {
							 if(!centerSwitch.equalsIgnoreCase("on"))
								 applyStartTg(strCurrentLine[0], html);
							 centerSwitch = "on";
						 } else if(strCurrentLine[1].equalsIgnoreCase("off")) { 
							 centerSwitch = "off";
							 html.append(applyEndTag(strCurrentLine[0]));
						 }  else  if( strCurrentLine[1].matches("[0-9]*")){ // Checking the String Contains only Number for the No Of line Input
							 centerAlignIncrementor = Integer.parseInt(strCurrentLine[1]);
							 centerSwitch = strCurrentLine[0];
						 }
					 } else if(StringUtils.isNotBlank(strCurrentLine[1])) {
						 
						 StringBuffer buffer=new StringBuffer();
						 if(StringUtils.isNotBlank(fontStyle)) {
							 buffer.append("<div style=\""+fontStyle+"\">");
						 }
						 if(StringUtils.isNotBlank(breakStyle)) {
							 buffer.append(breakStyle);
						 }
						applyStartTg(strCurrentLine[0], buffer);
						if(StringUtils.isNotBlank(sCurrentLine.substring(4))) {
							buffer.append(sCurrentLine.substring(4));
						}
						buffer.append(applyEndTag(strCurrentLine[0]));
						if(StringUtils.isNotBlank(fontStyle)) {
							buffer.append("</div>");
							fontStyle = null;
						}
						if(StringUtils.isNotBlank(breakStyle)) {
							buffer.append("</div>");
							breakStyle = null;
						}
//						System.out.println( sCurrentLine+" \n "+buffer+"\n"+centerOrUnderlineStyle+"\t"+strCurrentLine[0]);
						
						html.append(buffer);
						
						
					 }else{
						 System.err.println("Error in CE and US");
					 }
					 
					continue;
				}
				
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".FO ") ) 
				{
							String[] words = sCurrentLine.split("\\s+");
							if(words.length == 2) {
								if(words[1].equalsIgnoreCase("left")) {
									foStyle = "text-align: left;";
								} else if(words[1].equalsIgnoreCase("right")) {
									foStyle = "text-align: right;";
								} else if(words[1].equalsIgnoreCase("center")) {
									foStyle = "text-align: center;";
								} else if(words[1].equalsIgnoreCase("on")) {
									html.append("<div style=\" text-align: justify;\">");
								} else if(words[1].equalsIgnoreCase("off")) {
									html.append("</div>");
								}
							}
							completedIncrementor++;
							continue;
				}

				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, "^") || 
						( !sCurrentLine.startsWith(".") && StringUtils.contains(sCurrentLine,"^"))
						) 
				{
					dcfHandling.processcaret(html,sCurrentLine,tpParm, tabVal,sub_sup_script_Flag,fileVariableMap,globalVariableMap,true, isBxAvailable); 
					continue ;
				} 
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".BX") ) 
				{
					if(sCurrentLine.equalsIgnoreCase(".BX ") || sCurrentLine.equalsIgnoreCase(".BX OFF")) 
						isBxAvailable = Boolean.FALSE;
					else
						isBxAvailable = Boolean.TRUE;
					completedIncrementor++;
					continue;
				}
				
				//<p><b>This text is bold</b></p> 
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine,".fett ") && sCurrentLine.length() > 5) 
				{ 
					html.append("<div class=\"linebreak\"> <p><b>" 	+sCurrentLine.substring(5).trim() +"</b></p></div>"); 
					completedIncrementor++;
					continue;
				}
				else if (!sCurrentLine.startsWith("."))
				{
					//processNonDCFLine with out and start a .
					dcfHandling.processNonDCFLine(html, sCurrentLine, previousIndentStyle, indentStyleIncrementor,centerAlignIncrementor ,
							indentStyle ,centerOrUnderlineStyle , centerSwitch, fontStyle, foStyle,breakStyle,sub_sup_script_Flag,globalVariableMap,fileVariableMap);
					completedIncrementor++;
					continue;
				}
				
				else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".DV ") ) 
			    {
			    	 notCompletedPatter(html, sCurrentLine, ".DV");
			    	 notCompletedIncrementor++;
					continue;
			    }

			    else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".MG ")) 
			    {
			    	notCompletedPatter(html, sCurrentLine, ".MG");
			    	notCompletedIncrementor++;
					continue;
			    }
			    else if(StringUtils.startsWithIgnoreCase(sCurrentLine, ".SU ")
			    	|| StringUtils.startsWithIgnoreCase(sCurrentLine, ".PA "))
			    {
			    	  notCompletedPatter(html, sCurrentLine, ".SU or .PA");
			    	  notCompletedIncrementor++;
					 continue;
			    }
			    /*else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".SB "))
				{
					notCompletedPatter(html, sCurrentLine, ".SB"); 					
				    notCompletedIncrementor++;
					continue;
				}*/
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".CD "))
				{
					notCompletedPatter(html, sCurrentLine, ".CD"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".CL ") )
				{
					notCompletedPatter(html, sCurrentLine, ".CL"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".BC ") )
				{
					notCompletedPatter(html, sCurrentLine, ".BC"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".HW ") )
				{
					notCompletedPatter(html, sCurrentLine, ".HW"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".HV ") )
				{
					notCompletedPatter(html, sCurrentLine, ".HV"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".VR ") )
				{
					notCompletedPatter(html, sCurrentLine, ".VR"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".IR ") )
				{
					notCompletedPatter(html, sCurrentLine, ".IR"); 
					notCompletedIncrementor++;
					continue;
				}
				else if (StringUtils.startsWithIgnoreCase(sCurrentLine, ".LS ") ) 
				{
					notCompletedPatter(html, sCurrentLine, ".LS"); 
					notCompletedIncrementor++;
					continue;
				}

				else { 
					notCompletedPatter(html, sCurrentLine, sCurrentLine); 
//					System.err.println(sCurrentLine +"\tFileName:"+fileshortname+"\t LineNumber:"+linenumber);
					notCompletedIncrementor++;
					continue;
				}	
			}
			

			String ifblockContent= dcfHandling.processIFBlockContent(ifMap, globalVariableMap, fileVariableMap);
			if(StringUtils.isNotBlank(ifblockContent)){
				html.append(ifblockContent);
			}
			
			
			html.append("</div></body></html>") ;  
			returnvalue=html.toString();
			//BufferedWriter bwr = new BufferedWriter(new FileWriter(new File(outdir+fileshortname+".html")));
            //bwr.write(html.toString());
            //flush the stream
            //bwr.flush();
            //close the stream
           // bwr.close();
		} catch (IOException e) {
			System.out.println(sCurrentLine+" "+fileshortname +"\t"+linenumber);
			e.printStackTrace();
		}catch (Exception e) {
			System.out.println(sCurrentLine+" "+fileshortname +"\t"+linenumber);
			e.printStackTrace();
		} finally {
			try {
				if (bufferedReader != null)
					bufferedReader.close();
				if (fileReader != null)
					fileReader.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return returnvalue;
	}


	private static Double indentStyleGen(Double previousIndentStyle, String[] words) {
		String strStyleVal="";
		strStyleVal= words[1].replaceAll("[a-zA-Z]", "").trim();
		if(strStyleVal.indexOf("\\.")== strStyleVal.length()-1)
			strStyleVal= strStyleVal.replaceAll("\\.", "");
		
		
		if(words[1].contains("+")) {
			 
			
			if(StringUtils.isNotBlank(strStyleVal)) {
				if(StringUtils.containsIgnoreCase(words[1], "mm"))
				       previousIndentStyle = previousIndentStyle +Double.valueOf(strStyleVal)*2*3.77;
				else if(StringUtils.containsIgnoreCase(words[1], "i"))
						previousIndentStyle = previousIndentStyle + Double.valueOf(strStyleVal)*2*96;
				else if(!StringUtils.containsIgnoreCase(words[1], "mm") && !StringUtils.containsIgnoreCase(words[1], "i"))
					   previousIndentStyle = previousIndentStyle + Double.valueOf(strStyleVal)*2;
			}
		
		} else if(words[1].contains("-")) { 
			
			
			if(StringUtils.containsIgnoreCase(words[1], "mm"))
			       previousIndentStyle = previousIndentStyle - 
			            Double.valueOf(strStyleVal)*2*3.77;
			if(StringUtils.containsIgnoreCase(words[1], "i"))
				   previousIndentStyle = previousIndentStyle - 
				            Double.valueOf(strStyleVal)*2*96;
			if(!StringUtils.containsIgnoreCase(words[1], "mm") && !StringUtils.containsIgnoreCase(words[1], "i"))
				   previousIndentStyle = previousIndentStyle - 
				            Double.valueOf(strStyleVal)*2;
		}
		return previousIndentStyle;
	}


	private static void hrLeftAndRightStyle(String sCurrentLine, StringBuffer html) {
		ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
		ArrayList<Double> oddList = new ArrayList<Double>();
		ArrayList<Double> evenList = new ArrayList<Double>();
		int i = 0;
		for (Double word:styleFinalVal)
		{
		    if (i % 2 != 0)
		    {
		    	oddList.add(word);
		    }
		    if (i % 2 == 0)
		    {
		    	evenList.add(word);
		    }
		    i++;
		}
		for (Double styleOddVal : oddList) {
			  for (Double styleEvenVal : evenList) {
				  	html.append("<hr style = \"margin-left:"+styleOddVal+"px;width:"+styleEvenVal+"px\">");
			  }
		}
	}


	private static void applyStartTg(String centerOrUnderlineStyle, StringBuffer html) {
		if(StringUtils.isNotBlank(centerOrUnderlineStyle) && StringUtils.containsIgnoreCase(centerOrUnderlineStyle,".ce") ) {
			html.append("<center>");
		}else if(StringUtils.isNotBlank(centerOrUnderlineStyle) && StringUtils.containsIgnoreCase(centerOrUnderlineStyle, ".us")) {
			html.append("<div style=\"text-decoration:underline;\">");
		}
	}


	private static String applyEndTag(String centerOrUnderlineStyle) {
		String endTag = "";
		if(StringUtils.isNotBlank(centerOrUnderlineStyle) && StringUtils.containsIgnoreCase(centerOrUnderlineStyle,".ce")) {
			endTag= "</center>";
		}else if(null != centerOrUnderlineStyle && centerOrUnderlineStyle.contains(".us")) {
			endTag="</div>";
		}
		centerOrUnderlineStyle = null;
		return endTag;
	}


	private static String applyStyle(String sCurrentLine) {
		String centerOrUnderlineStyle = null;
		if(StringUtils.containsIgnoreCase(sCurrentLine, ".CE")) {
			 centerOrUnderlineStyle = ".ce";
		 } else if(StringUtils.containsIgnoreCase(sCurrentLine, ".US")) {
			 centerOrUnderlineStyle = ".us";
		 }
		return centerOrUnderlineStyle;
	}


	public static void displayString( String sCurrentLine, StringBuffer html,String sub_sup_script_Flag,Map<String,String> globalVariableMap,Map<String,String> fileVariableMap) {
		DCFHandling dcfHandling =new DCFHandling();
		String dynamicValue = "CE0VSNR001";
		String[] words = sCurrentLine.split("\\s+");
		String spandiv="<span ";
		
		if((!sCurrentLine.contains("^")) && sCurrentLine.contains("&")) {
			String convertedString="";
				for(String word: words){					
					if(word.contains("&")) { 	
						convertedString +="<span style = \"color:red;\"> "+ dcfHandling.retriveDynamicVariable(globalVariableMap, fileVariableMap, word)+ "</span>";
					}else{
						convertedString +=" "+word;
					}
				}
				if(StringUtils.isNotBlank(convertedString)){
					html.append(convertedString);
				}

		} 
		else if((!sCurrentLine.contains("&")) && sCurrentLine.contains("^")) {
			// this will be true only when the condition (!false && true)  so we can remove the else block in the for loop  		
			
			for(int i=0; i < words.length ; i++) {
				if(words[i].contains("^")) {
					int count = StringUtils.countMatches(words[i], "^");
					int indentSpacingVal = count*tabVal;
					html.append("<span style = \"padding-left:"+indentSpacingVal+"px\" >"+insertSpace(words[i].replaceAll("\\^", " "))+ "</span>");
				} else {
					html.append("<span style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(words[i]) + "</span>");
				}
			}
		}
		else if(sCurrentLine.contains("&") && sCurrentLine.contains("^")) {
			// this will work when we have the & and ^ charater present 
			
			for(int i=0; i < words.length ; i++) {
				if(!(words[i].contains("^")) && words[i].contains("&")) {
					dynamicValue = StringUtils.substringAfter(words[i], "&");
					html.append("<span style = \"color:red;padding-left:"+tabVal +"px\"> "+insertSpace(dynamicValue)+ "</span>");
				} else if(!(words[i].contains("&")) && words[i].contains("^")) {
					int count = StringUtils.countMatches(words[i], "^");
					int indentSpacingVal = count*tabVal;
					html.append("<span style = \"padding-left:"+indentSpacingVal+"px\"> "+ insertSpace(words[i].replaceAll("\\^", ""))+ "</span>");
				} else if(words[i].contains("^") && words[i].contains("&")) {
					int count = StringUtils.countMatches(words[i], "^");
					int indentSpacingVal = count*tabVal;
					dynamicValue = StringUtils.substringAfter(words[i], "&");
					html.append("<span style = \"color:red;padding-left:"+indentSpacingVal+"px\" >"+ insertSpace(dynamicValue.replaceAll("\\^", ""))+ "</span>");
				} else {
					html.append("<span style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(words[i]) + "</span>");
				}
			}
		}  else {
			if(tpStyleVal != null ) {
				html.append("<span style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(sCurrentLine) + "</span>");
			} else {
				spandiv ="<div ";
				html.append("<div style = \"padding-left:"+tabVal+"px\" >"+ insertSpace(sCurrentLine) + "</div>");
			}
		}
		
		if(StringUtils.isNotBlank(sub_sup_script_Flag)){
			 String previousText = html.substring(0,html.lastIndexOf(spandiv)+spandiv.length());
			 String nextText = html.substring(html.lastIndexOf(spandiv)+spandiv.length());	
			 html= new StringBuffer();						 
			 if(StringUtils.isNotBlank(previousText))html.append(previousText);
			 html.append("class =\""+sub_sup_script_Flag+"\"");
			 if(StringUtils.isNotBlank(nextText))html.append(nextText);
		}
		
	}
	


	private static String insertSpace(String dynamicValue) {
		if (dynamicValue.contains(">")) {
			dynamicValue = dynamicValue.replace(">", "&nbsp");
		}
		return dynamicValue+" ";
	}


	private static String breakElement(String sCurrentLine, StringBuffer html) {
		String spacingVal;
		String breakStyle = null;
		if(sCurrentLine.contains(",")) {
			sCurrentLine = sCurrentLine.replace(",", ".");
		}
		
		if(sCurrentLine.trim().length() > 3) {
		    spacingVal = sCurrentLine.substring(4).trim();
			if(StringUtils.containsIgnoreCase(spacingVal, "mm") ) {
				String breakVal =  StringUtils.substring(spacingVal, 0, StringUtils.indexOfIgnoreCase(spacingVal,"mm"));
				if(breakVal.contains("[0-9]+")){//.contains("[0-9]+")
				double intVal = Double.parseDouble(breakVal);
				double intmmVal = 3.77;
				spacingValue =  intVal*intmmVal;
				breakStyle = "<div style=\"padding-top:" +spacingValue+ "px\">";
				}
			} else if(StringUtils.containsIgnoreCase(spacingVal, "i")) {
			
				String breakVal = StringUtils.substring(spacingVal, 0, StringUtils.indexOfIgnoreCase(spacingVal,"i"));
				double intVal = Double.parseDouble(breakVal);
				double intmmVal = 96;
				spacingValue =  intVal*intmmVal;
				breakStyle = "<div style=\"padding-top:" +spacingValue+ "px\">";
			} else if (spacingVal.length() > 0) {
				if(StringUtils.isNotBlank(spacingVal) && spacingVal.contains("[0-9]+") ) {
					spacingVal= spacingVal.replaceAll("\"", "").toString();
					Double spaceVal = Double.parseDouble(spacingVal);
					
					for (int index=1; index <= spaceVal ; index++) {
						html.append("</br>"); 
					}
					spacingValue = 10.0;
				}
			} 
		}else  {
			spacingValue = 10.0;
			html.append("</br>"); 
		}
		
		return breakStyle;
	}
	

	private static void da(String sCurrentLine, StringBuffer html)
	{
		ArrayList<Double> styleFinalVal = retrievePaddingVal(sCurrentLine);
		String[] words = sCurrentLine.split("\\s+");
		String rotateStyle = null;
		String fontStyle = null;
		for (int i = 0; i < words.length; i++) {
		    if(words[i].equalsIgnoreCase("rotate")){
		    	rotateStyle = "transform:rotate("+words[i+1]+"deg);";
		    } else if(words[i].equalsIgnoreCase("font")){
		    	// TODO : Hardcoded the font value
				fontStyle = "font-family:sans-serif;" ; 
		    }
		}
		
		if(styleFinalVal.size()>=3){
			html.append("<div style=\"padding-left:"+styleFinalVal.get(0)+"px;");
		}else if(styleFinalVal.size()>=2){
			html.append("<div style=\"");
		}else if(styleFinalVal.size() >=1){
			html.append("<div style=\"padding-left:"+styleFinalVal.get(0)+"px;");
	    }
			
		
		if(null != rotateStyle) {
//			html.append(rotateStyle);
			rotateStyle= null;
		}
		if(StringUtils.isNotBlank(shadeVal) && styleFinalVal.size() >=1 ) {
			html.append(shadeVal);
			shadeVal = null;
		}
		if(null != fontStyle) {
			html.append(fontStyle);
			fontStyle = null;
		}
		
		if(styleFinalVal.size() >=1) html.append("\">"); 
	}
    

	private static ArrayList<Double> retrievePaddingVal(String sCurrentLine) {
				/*int dotcount=StringUtils.countMatches(sCurrentLine, ".");
				if(dotcount >=2){
					sCurrentLine=sCurrentLine.split("\\.")[1];
				}*/
				String[] words = sCurrentLine.split("\\s+");
				ArrayList<String> styleVal = new ArrayList<String>();
				ArrayList<Double> finalStyleVal = new ArrayList<Double>();
				for (int i = 0; i < words.length; i++) {
					//data.matches("^[0-9].*")
				    if(words[i].matches("^[0-9].*")) {		    	
					   styleVal.add(words[i]);
				    }
				}
				
				for(String strStyleVal : styleVal) {
					if(StringUtils.containsIgnoreCase(strStyleVal, "mm") || StringUtils.containsIgnoreCase(strStyleVal,"m") ) {
						strStyleVal= strStyleVal.replaceAll("[a-zA-Z]", "").replaceAll(",", ".").replace("\"", "").replace(";", "");
						finalStyleVal.add(Double.valueOf(strStyleVal)*3.77);
				    } else if(StringUtils.containsIgnoreCase(strStyleVal,"i")) {
						strStyleVal= strStyleVal.replaceAll("[a-zA-Z]", "").replaceAll(",", ".").replace("\"", "");
						if(StringUtils.isNotBlank(strStyleVal))
							finalStyleVal.add(Double.valueOf(strStyleVal)*60);
				    }	
				}
				return finalStyleVal;
	}
	


	public static void notCompletedPatter(StringBuffer html,String sCurrentLine,String pattern){		
//		html.append("<div style=\"color:gray;\" class=\"tooltip linebreak\">"+pattern+" <span class=\"tooltiptext\">"+sCurrentLine+"</span></div>");
	}


}
