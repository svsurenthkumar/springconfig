package com.demo.springmvc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
import org.apache.commons.lang3.StringUtils;

public class DCFTableProcessing {

	
	public String processTableDataContent(Map<String,List<String>> tableDefMap, Map<String,List<String>> tableDataMap,String tableName,String tableWidth){
		
		List<String> tableDataList=tableDataMap.get(tableName);
		Map<String,List<String>> tableRowMap = new HashMap<String,List<String>>();
		String tableRowName="";
		String convertedtableString= "";
		String rowtdString= "";
		List<String> rowLineList= new ArrayList<String>();
		List<String> tableRowNamelist= new ArrayList<String>();
		for(String tableDataLine:tableDataList)
		{
			if(StringUtils.startsWithIgnoreCase(tableDataLine, ".ta row") )
			{
				if(StringUtils.containsIgnoreCase(tableDataLine, " on"))
				{
					String tablelinedatas=StringUtils.stripToEmpty(tableDataLine.substring(8));
					tableRowName=tablelinedatas.split("\\s+")[0];					
					rowLineList= new ArrayList<String>();
					continue;
				}
				else if(StringUtils.containsIgnoreCase(tableDataLine, " off") )
				{
					if(StringUtils.isNotBlank(rowtdString ))
					{
						rowLineList.add(rowtdString);
						rowtdString ="";
					}
					tableRowMap.put(tableRowName, rowLineList);	
					tableRowNamelist.add(tableRowName);
					tableRowName="";					
					rowLineList= new ArrayList<String>();
					continue;				
				}
				else
				{
					System.err.println(" ta row without ON/OFF Data "+tableDataLine);
				}
			}
			else if(StringUtils.startsWithIgnoreCase(tableDataLine, ".ta cell") )
			{
				if(StringUtils.containsIgnoreCase(tableDataLine, " on"))
				{
					if(StringUtils.isNotBlank(rowtdString)){
//						System.out.println(rowtdString +"\t"+tableRowName+"\t"+tableDataLine);
						rowLineList.add(rowtdString);
					}
					
					rowtdString= "";
					continue;
				}
				else if(StringUtils.containsIgnoreCase(tableDataLine, " off") )
				{
					/*rowLineList= new ArrayList<String>();
					if(tableRowMap.containsKey(tableRowName))
					{
						rowLineList =tableRowMap.get(tableRowName);
					}*/
					rowLineList.add(rowtdString);
					rowtdString= "";
					continue;				
				}
				else
				{
				
			 		System.err.println(" ta Cell without ON/OFF Data "+tableDataLine);
				}
			}
			
			else
			{
				
				if( StringUtils.startsWith(tableDataLine, "^") || 
					!StringUtils.startsWith(tableDataLine, ".") || 
					StringUtils.startsWith(tableDataLine, ".x")
				)
				{
					/*if(StringUtils.isNotBlank(rowtdString)){
						rowtdString+="|*";
					}*/
					rowtdString +=" "+ tableDataLine;
				}
				continue;				
			}
		}
		
		if( StringUtils.isNotBlank(tableRowName) && (StringUtils.isNotBlank(rowtdString)) || rowLineList.size() >0 ){
			
			if(StringUtils.isNotBlank(rowtdString ))
			{
				rowLineList.add(rowtdString);
				rowtdString ="";
			}
			tableRowMap.put(tableRowName, rowLineList);					
			tableRowNamelist.add(tableRowName);
			tableRowName="";
	
		}
		
		
		for ( String rowName:tableRowNamelist) 
		{
			List<String> rowList=tableRowMap.get(rowName);
			convertedtableString+="<tr>";			
			for(String tddata:rowList){
				convertedtableString +="<td>"+tddata.replaceAll("\\^", " ")+"</td>";
			}
			convertedtableString+="</tr>";			
		}
		
		
		convertedtableString="<table border=\"1\" style=\"width:"+tableWidth+"\">"+convertedtableString+"</table>";
		
		
		return convertedtableString;
	}
	
}
