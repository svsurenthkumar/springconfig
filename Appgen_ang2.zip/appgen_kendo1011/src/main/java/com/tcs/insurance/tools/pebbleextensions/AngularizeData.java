package com.tcs.insurance.tools.pebbleextensions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Filter;

public class AngularizeData implements Filter{

    	List<String> argumentNames = new ArrayList<String>();
    	
    	public AngularizeData(){
    	    argumentNames.add("filter");
    	}
	@Override
	public List<String> getArgumentNames() {
		return argumentNames;
	}

	@Override
	public Object apply(Object input, Map<String, Object> args) {
		String inputString = (String)input;
		String filterPipe = "";
		String filter = (String) args.get("filter");
		if(filter != null && filter.length() > 0 )
		    filterPipe = " | "+ filter.trim();
		return new StringBuffer("{{").append(inputString).append(filterPipe).append("}}").toString();
	}

}
