package com.tcs.insurance.tools.appgen.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;

import com.google.gson.Gson;
import com.google.gson.internal.LinkedTreeMap;
import com.tcs.insurance.tools.appgen.exception.AppGenException;

public class JsonUtility {
	public static LinkedTreeMap<String, Object> readJsonFile(String fileName) throws IOException{
		Gson gson = new Gson();
		InputStream inputStream = JsonUtility.class.getClassLoader().getResourceAsStream(fileName);
		if(inputStream == null) {
			throw new AppGenException(fileName + " not found");
		}
		String inputString = IOUtils.toString(inputStream, Charset.defaultCharset());
		@SuppressWarnings("unchecked")
		LinkedTreeMap<String, Object> returnMap = gson.fromJson(inputString, LinkedTreeMap.class);
		return returnMap;
	}
	
	public static LinkedTreeMap<String, Object> readJsonFile(File file) throws IOException{
		Gson gson = new Gson();
		InputStream inputStream = new FileInputStream(file);
		String inputString = IOUtils.toString(inputStream, Charset.defaultCharset());
		@SuppressWarnings("unchecked")
		LinkedTreeMap<String, Object> returnMap = gson.fromJson(inputString, LinkedTreeMap.class);
		return returnMap;
	}
}
