package com.tcs.insurance.tools.pebbleextensions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Function;

public class UniqueRestSteps implements Function{

	@Override
	public List<String> getArgumentNames() {
		List<String> args = new ArrayList<String>();
		args.add("actions");
		return args;
	}

	@Override
	public Object execute(Map<String, Object> args) {
		List<Map<String, Object>> actions = (List<Map<String, Object>>) args.get("actions");
		Map<String, Map<String, Object>> uniqueRestSteps = new HashMap<String, Map<String,Object>>();
		for(Map<String, Object> action : actions){
			List<Map<String, Object>> steps = (List<Map<String, Object>>) action.get("steps");
			for(Map<String, Object> step : steps){
				if("rest".equals(step.get("type"))){
					uniqueRestSteps.put(new StringBuffer((String)step.get("method")).append((String)step.get("url")).toString(), step);
				}
			}
		}
		List<Map<String, Object>> uniqueRestStepList = new ArrayList<>(uniqueRestSteps.values());
		return uniqueRestStepList;
	}

}
