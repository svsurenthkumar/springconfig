package com.tcs.insurance.tools.pebbleextensions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Extension;
import com.mitchellbosecke.pebble.extension.Filter;
import com.mitchellbosecke.pebble.extension.Function;
import com.mitchellbosecke.pebble.extension.NodeVisitorFactory;
import com.mitchellbosecke.pebble.extension.Test;
import com.mitchellbosecke.pebble.operator.BinaryOperator;
import com.mitchellbosecke.pebble.operator.UnaryOperator;
import com.mitchellbosecke.pebble.tokenParser.TokenParser;

public class AppGenExtension implements Extension{

	@Override
	public Map<String, Filter> getFilters() {
		Map<String, Filter> filterMap = new HashMap<String, Filter>();
		filterMap.put("commaSeperated", new CommaSeperatedList());
		filterMap.put("angularize", new AngularizeData());
		return filterMap;
	}

	@Override
	public Map<String, Test> getTests() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Function> getFunctions() {
		Map<String, Function> functionMap = new HashMap<String, Function>();
		functionMap.put("isInList", new IsInListFunction());
		functionMap.put("methodName", new RestMethod());
		functionMap.put("uniqueRestSteps", new UniqueRestSteps());
		functionMap.put("combineFields", new CombineFields());
		return functionMap;
	}

	@Override
	public List<TokenParser> getTokenParsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BinaryOperator> getBinaryOperators() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UnaryOperator> getUnaryOperators() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> getGlobalVariables() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NodeVisitorFactory> getNodeVisitors() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
