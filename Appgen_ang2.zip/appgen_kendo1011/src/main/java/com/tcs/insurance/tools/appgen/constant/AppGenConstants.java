package com.tcs.insurance.tools.appgen.constant;

public final class AppGenConstants {
	public static final String WEBAPP_FOLDER_PATH = "src/main/webapp";
	public static final String RESOURCES_FOLDER_PATH = WEBAPP_FOLDER_PATH + "/resources";
	public static final String APP_FOLDER_PATH = RESOURCES_FOLDER_PATH + "/app";
	public static final String COMMON_FOLDER_PATH = APP_FOLDER_PATH + "/common";

	//angular 4 file constants
	public static final String NG_COMMAND = "%USERPROFILE%\\AppData\\Roaming\\npm\\ng";
	public static final String GENERATE ="generate";
	public static final String PROJECT_CREATION_COMMAND = "new";
	public static final String COMPONENT_COMMAND = "component";
	public static final String SERVICE_COMMAND = "service";
	
	public static final String CUSTOM_SERVICE_NAME = "customization";
}