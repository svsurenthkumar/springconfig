package com.tcs.insurance.tools.pebbleextensions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Function;

public class CombineFields implements Function {

	@Override
	public List<String> getArgumentNames() {
		List<String> args = new ArrayList<String>();
		args.add("fieldsUsed");
		args.add("tempFields");
		args.add("onLoadMethods");
		return args;
	}

	@Override
	public Object execute(Map<String, Object> args) {
		List<String> fieldsUsed = (List<String>) args.get("fieldsUsed");
		List<Map<String, String>> tempFields = (List<Map<String, String>>) args
				.get("tempFields");
		List<String> methods = (List<String>) args
			.get("onLoadMethods");

		List<String> fields = new ArrayList<>();
		if (fieldsUsed != null) {
			fields.addAll(fieldsUsed);
		}
		if (tempFields != null) {
			for (Map<String, String> field : tempFields) {
				fields.add((String) field.get("name"));
			}
		}
		
		if (methods != null) {
		    fields.addAll(methods);
		}
		return fields;
	}

}
