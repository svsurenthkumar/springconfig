package com.tcs.insurance.tools.appgen;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.error.PebbleException;
import com.tcs.insurance.tools.appgen.constant.AppGenConstants;
import com.tcs.insurance.tools.appgen.utility.FileUtility;
import com.tcs.insurance.tools.appgen.utility.JsonUtility;
import com.tcs.insurance.tools.appgen.utility.PebbleUtility;

public class ApplicationHandler {
	private ApplicationHandler() {

	}

	public static void generateApplication(String input, String lib,
			String application, String output) throws IOException,
			PebbleException {
		Map<String, Object> applicationMap = readApplication(input, application);
		File projDir = createDirectories(application, output);
		copyLib(lib, projDir);
		createPomFile(applicationMap, projDir);
		createWebXml(applicationMap, projDir);
		createIndexHtmlFile(applicationMap, projDir);
		createAngularAppJsFiles(applicationMap, projDir);
		createDataServiceJsFile(applicationMap, projDir);
		createHelperJsFile(applicationMap, projDir);
		createLogServiceJsFile(applicationMap, projDir);
		createIdleServiceJsFile(applicationMap, projDir);
		createHttpInterceptorJsFile(applicationMap, projDir);
		createExceptionHandlerJsFile(applicationMap, projDir);
		createCommonFiles(applicationMap, projDir);
		generateScreens(applicationMap, projDir, input);
	}

	private static Map<String, Object> readApplication(String input,
			String application) throws IOException {
		String filePath = new StringBuilder(input).append('/')
				.append(application).append(".json").toString();
		File appFile = new File(filePath);
		Map<String, Object> applicationMap = JsonUtility.readJsonFile(appFile);
		return applicationMap;
	}

	private static File createDirectories(String application,
			String outputFolder) throws IOException {
		File projDir = new File(outputFolder, application);

		if (!projDir.exists()) {
			projDir.mkdirs();
		}

		Map<String, Object> directoryMap = JsonUtility
				.readJsonFile("application-directory-structure.json");
		@SuppressWarnings("unchecked")
		List<String> directories = (List<String>) directoryMap
				.get("directories");
		for (String directory : directories) {
			File dir = new File(projDir, directory);
			if (!dir.exists()) {
				dir.mkdirs();
			}
		}

		return projDir;
	}

	private static void copyLib(String libPath, File projDir)
			throws IOException {
		File libFolder = new File(libPath);
		File targetLibDir = new File(projDir,
				AppGenConstants.RESOURCES_FOLDER_PATH);
		FileUtility.copyFilesNotMatchingRecursively(libFolder, targetLibDir);
	}

	private static void createPomFile(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String pomFilePath = projDir.getAbsolutePath().concat("/pom.xml");
		PebbleUtility.generate("pebble/pom.xml.peb", pomFilePath,
				applicationMap);
	}

	private static void createWebXml(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String webXmlPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.WEBAPP_FOLDER_PATH)
				.concat("/WEB-INF/web.xml");
		PebbleUtility
				.generate("pebble/web.xml.peb", webXmlPath, applicationMap);
	}

	private static void createIndexHtmlFile(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String indexPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.WEBAPP_FOLDER_PATH)
				.concat("/index.html");
		PebbleUtility.generate("pebble/index.html.peb", indexPath,
				applicationMap);
	}

	private static void createAngularAppJsFiles(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat(appName).concat(".module.js");
		PebbleUtility.generate("pebble/app.js.peb", appJsPath, applicationMap);
	}

	private static void createDataServiceJsFile(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat(appName).concat(".datasvc.js");
		PebbleUtility.generate("pebble/datasvc.js.peb", appJsPath,
				applicationMap);
	}
	private static void createHelperJsFile(
		Map<String, Object> applicationMap, File projDir)
		throws PebbleException, IOException {
	String appName = (String) applicationMap.get("name");
	String appJsPath = projDir.getAbsolutePath().concat("/")
			.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
			.concat(appName).concat(".helper.js");
	PebbleUtility.generate("pebble/helper.js.peb", appJsPath,
			applicationMap);
}

	private static void createLogServiceJsFile(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {/*

		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat("logService.js");

		PebbleUtility.generate("pebble/logService.js.peb", appJsPath,
				applicationMap);*/
	}
	private static void createIdleServiceJsFile(
		Map<String, Object> applicationMap, File projDir)
		throws PebbleException, IOException {

	String appName = (String) applicationMap.get("name");
	String appJsPath = projDir.getAbsolutePath().concat("/")
			.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
			.concat("idleService.js");

	PebbleUtility.generate("pebble/idleService.js.peb", appJsPath,
			applicationMap);
}
	private static void createHttpInterceptorJsFile(
		Map<String, Object> applicationMap, File projDir)
		throws PebbleException, IOException {

	String appName = (String) applicationMap.get("name");
	String appJsPath = projDir.getAbsolutePath().concat("/")
			.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
			.concat("httpInterceptor.js");

	PebbleUtility.generate("pebble/httpInterceptor.js.peb", appJsPath,
			applicationMap);
}

	private static void createExceptionHandlerJsFile(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {

		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat("exceptionConfig.js");

		PebbleUtility.generate("pebble/exceptionConfig.js.peb", appJsPath,
				applicationMap);
	}

	private static void createCommonFiles(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		File commonDir = new File(projDir, AppGenConstants.COMMON_FOLDER_PATH);
		if (!commonDir.exists()) {
			commonDir.mkdirs();
		}
		String headerJsPath = commonDir.getAbsolutePath().concat("/")
				.concat("header.controller.js");
		PebbleUtility.generate("pebble/header.controller.js.peb", headerJsPath,
				applicationMap);
		String menuJsPath = commonDir.getAbsolutePath().concat("/")
				.concat("menu.controller.js");
		PebbleUtility.generate("pebble/menu.controller.js.peb", menuJsPath,
				applicationMap);
		String progressJsPath = commonDir.getAbsolutePath().concat("/")
			.concat("progressbar.controller.js");
	PebbleUtility.generate("pebble/progressbar.controller.js.peb", progressJsPath,
			applicationMap);
	String progressHelperJsPath = commonDir.getAbsolutePath().concat("/")
		.concat("progressbar.helper.js");
PebbleUtility.generate("pebble/progressbar.helper.js.peb", progressHelperJsPath,
		applicationMap);
String progressConstantJsPath = commonDir.getAbsolutePath().concat("/")
.concat("progressbar.constant.js");
PebbleUtility.generate("pebble/progressbar.constant.js.peb", progressConstantJsPath,
applicationMap);

String errorControllerPath = commonDir.getAbsolutePath().concat("/")
.concat("errorController.js");
PebbleUtility.generate("pebble/errorController.js.peb", errorControllerPath,
applicationMap);

String menuServiceJsPath = commonDir.getAbsolutePath().concat("/")
			.concat("menu.service.js");
	PebbleUtility.generate("pebble/menu.service.js.peb", menuServiceJsPath,
			applicationMap);
	
	String menuFormServiceJsPath = commonDir.getAbsolutePath().concat("/")
			.concat("cnacFormService.js");
	PebbleUtility.generate("pebble/menuFormService.js.peb", menuFormServiceJsPath,
			applicationMap);
	}

	private static void generateScreens(Map<String, Object> applicationMap,
			File projDir, String inputPath) throws IOException, PebbleException {
		List<String> screens = (List<String>) applicationMap.get("screens");
		for (String screen : screens) {
			generateScreen((String) applicationMap.get("name"), screen,
					projDir, inputPath);
		}
	}

	private static void generateScreen(String application, String screen,
			File projDir, String inputPath) throws IOException, PebbleException {
		File appDir = new File(projDir, AppGenConstants.APP_FOLDER_PATH);
		File screenDir = new File(appDir, screen);
		if (!screenDir.exists()) {
			screenDir.mkdirs();
		}
		File customDir = new File(appDir,"cnacustomization");
		if (!customDir.exists()) {
		    customDir.mkdirs();
		}
		Map<String, Object> screenMap = readScreen(inputPath, screen);
		screenMap.put("application", application);
		generateHtml(screenMap, screenDir);
		generateCtrlJs(screenMap, screenDir);
		generateServiceJs(screenMap, screenDir);
		generateCustomJs(screenMap, customDir);
	}

	private static Map<String, Object> readScreen(String input, String screen)
			throws IOException {
		String filePath = new StringBuilder(input).append('/').append(screen)
				.append(".json").toString();
		File screenFile = new File(filePath);
		Map<String, Object> screenMap = JsonUtility.readJsonFile(screenFile);
		return screenMap;
	}

	private static void generateHtml(Map<String, Object> screenMap, File dir)
			throws PebbleException, IOException {
		String screenName = (String) screenMap.get("name");
		String htmlPath = dir.getAbsolutePath().concat("/").concat(screenName)
				.concat(".html");
		PebbleUtility.generate("pebble/view.html.peb", htmlPath, screenMap);
	}

	private static void generateCtrlJs(Map<String, Object> screenMap, File dir)
			throws PebbleException, IOException {
		String screenName = (String) screenMap.get("name");
		String ctrlJsPath = dir.getAbsolutePath().concat("/")
				.concat(screenName).concat(".controller.js");
		PebbleUtility.generate("pebble/ctrl.js.peb", ctrlJsPath, screenMap);
	}

	private static void generateServiceJs(Map<String, Object> screenMap,
			File dir) throws PebbleException, IOException {
		String screenName = (String) screenMap.get("name");
		String serviceJsPath = dir.getAbsolutePath().concat("/")
				.concat(screenName).concat(".service.js");
		PebbleUtility.generate("pebble/svc.js.peb", serviceJsPath, screenMap);
	}
	
	private static void generateCustomJs(Map<String, Object> screenMap, File dir)
		throws PebbleException, IOException {
	String screenName = (String) screenMap.get("name");
	String ctrlJsPath = dir.getAbsolutePath().concat("/")
			.concat(screenName).concat(".custom.js");
	PebbleUtility.generate("pebble/custom.js.peb", ctrlJsPath, screenMap);
}
}
