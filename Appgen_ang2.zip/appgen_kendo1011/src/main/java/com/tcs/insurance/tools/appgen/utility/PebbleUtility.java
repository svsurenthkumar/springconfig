package com.tcs.insurance.tools.appgen.utility;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.apache.commons.io.FileUtils;

import com.mitchellbosecke.pebble.PebbleEngine;
import com.mitchellbosecke.pebble.error.PebbleException;
import com.mitchellbosecke.pebble.template.PebbleTemplate;
import com.tcs.insurance.tools.pebbleextensions.AppGenExtension;

public class PebbleUtility {
	private static void generateFile(String templateFilePath, String outputFilePath, Map<String, Object> context)
			throws PebbleException, IOException {
		PebbleEngine engine = new PebbleEngine.Builder().extension(new AppGenExtension()).build();
		PebbleTemplate template = engine.getTemplate(templateFilePath);
		Writer writer = new FileWriter(outputFilePath);
		template.evaluate(writer, context);
		writer.close();
	}

	public static void generate(String templateFilePath, String outputFilePath, Map<String, Object> context)
			throws PebbleException, IOException {
		String generateFilePath = outputFilePath.concat("_gen");
		generateFile(templateFilePath, generateFilePath, context);
		File outputFile = new File(outputFilePath);
		File generatedFile = new File(generateFilePath);
		if (outputFile.exists()) {
		 
			if (!outputFile.toString().contains("cnacustomization")) {
			  
				if (FileUtils.contentEquals(outputFile, generatedFile)) {
					FileUtils.deleteQuietly(generatedFile);
				} else {
					if (outputFile.exists()) {
						FileUtils.deleteQuietly(outputFile);
					}
					FileUtils.moveFile(generatedFile, outputFile);
				}
			}
			else{
			    if (outputFile.exists()){
			    FileUtils.deleteQuietly(generatedFile);
			    }
			    else{
				FileUtils.moveFile(generatedFile, outputFile);
			    }
			}
			
		} else {		    
		    FileUtils.moveFile(new File(generateFilePath), outputFile);
		}

	}
}
