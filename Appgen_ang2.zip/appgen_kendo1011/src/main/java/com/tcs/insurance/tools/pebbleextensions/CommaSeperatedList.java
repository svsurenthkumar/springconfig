package com.tcs.insurance.tools.pebbleextensions;

import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Filter;

public class CommaSeperatedList implements Filter {

	@Override
	public List<String> getArgumentNames() {
		return null;
	}

	@Override
	public Object apply(Object input, Map<String, Object> args) {
		List<String> inputList = (List<String>) input;
		StringBuffer output = new StringBuffer();
		if (inputList != null) {
			for (int index = 0; index < inputList.size(); index++) {
				output.append(inputList.get(index));
				if (index != inputList.size() - 1) {
					output.append(',');
				}
			}
		}
		return output.toString();
	}

}
