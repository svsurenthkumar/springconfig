package com.tcs.insurance.tools.appgen.utility;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Scanner;

import org.apache.commons.io.FileUtils;

public class FileUtility {
	public static void copyFilesNotMatchingRecursively(File sourceDir, File targetDir) throws IOException{
		if(!targetDir.exists()){
			targetDir.mkdirs();
		}
		String[] sourceFiles = sourceDir.list();
		for(String sourceFileName : sourceFiles) {
			File sourceFile = new File(sourceDir, sourceFileName);
			if(sourceFile.isFile()){
				File targetFile = new File(targetDir, sourceFileName);
				if(targetFile.exists()){
					if(!FileUtils.contentEquals(sourceFile, targetFile)){
						FileUtils.copyFile(sourceFile, targetFile);
					}
				}
				else {
					FileUtils.copyFile(sourceFile, targetFile);
				}
			}
			else if(sourceFile.isDirectory()){
				File targetSubDir = new File(targetDir, sourceFileName);
				copyFilesNotMatchingRecursively(sourceFile, targetSubDir);
			}
		}
	}
	
	public static boolean search(String filePath, String searchText) throws IOException {
		File inputFile = new File(filePath);
		String fileContents = FileUtils.readFileToString(inputFile, Charset.defaultCharset());
		return fileContents.contains(searchText);
	}
}
