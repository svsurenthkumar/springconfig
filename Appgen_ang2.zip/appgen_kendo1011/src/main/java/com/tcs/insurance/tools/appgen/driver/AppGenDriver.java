package com.tcs.insurance.tools.appgen.driver;

import java.io.IOException;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import com.mitchellbosecke.pebble.error.PebbleException;
import com.tcs.insurance.tools.appgen.ApplicationAngular4Handler;
import com.tcs.insurance.tools.appgen.ApplicationHandler;

public class AppGenDriver {
	public AppGenDriver() {}
	
	public static void main(String[] args) throws ParseException, IOException, PebbleException{
		//initalsetup("","","");
		CommandLine cmd;
		CommandLineParser parser = new DefaultParser();	
		Options options = buildOptions();
//		cmd = parser.parse(options, args);
		String output="D:\\appgenang4\\config\\output";
		String ref="D:\\appgenang4\\ref";
		String config="D:\\appgenang4\\config\\lsa";
		String application="lsa";
		buildAng4(output,ref,config,application);
		System.out.println("Successfully Generated");
	}
	
	private static void buildAng4(String output,String ref,String config,String application) throws IOException, PebbleException {
		ApplicationAngular4Handler.createProjectStructure(application,
				output);
		ApplicationAngular4Handler.generateApplication(config,ref,application,output);
	}

	public void initalsetup(String config, String ref, String output) throws ParseException {
		Options options = buildOptions();
		try {
			ApplicationHandler.generateApplication(config, ref, "lsa", output);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (PebbleException e) {
			e.printStackTrace();
		}
	}
	
	private static Options buildOptions() {
		Options options = new Options();

		Option configOption = new Option("config", "Application and Screen configuration Folder");
		configOption.setArgs(1);
		configOption.setArgName("configFolder");
		configOption.setRequired(true);
		options.addOption(configOption);
		
		Option refOption = new Option("ref", "Reference Folder(From which all the standard files are copied)");
		refOption.setArgs(1);
		refOption.setArgName("refFolder");
		refOption.setRequired(true);
		options.addOption(refOption);
		
		Option appOption = new Option("application", "Application");
		appOption.setArgs(1);
		appOption.setArgName("application");
		appOption.setRequired(true);
		options.addOption(appOption);
		
		/*Option screenOption = new Option("screen", "Screen");
		screenOption.setArgs(1);
		screenOption.setArgName("screen");
		screenOption.setRequired(false);
		options.addOption(screenOption);
		*/
		Option angularOption = new Option("angular", "Angular");
		angularOption.setArgs(1);
		angularOption.setArgName("angular");
		angularOption.setRequired(true);
		options.addOption(angularOption);

		Option outputOption = new Option("output", "Output Folder");
		outputOption.setArgs(1);
		outputOption.setArgName("outputFolder");
		outputOption.setRequired(true);
		options.addOption(outputOption);
		return options;
	}
}
