package com.tcs.insurance.tools.appgen.exception;

public class AppGenException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AppGenException(String message) {
		// TODO Auto-generated constructor stub
		
		super(message);
	}

}
