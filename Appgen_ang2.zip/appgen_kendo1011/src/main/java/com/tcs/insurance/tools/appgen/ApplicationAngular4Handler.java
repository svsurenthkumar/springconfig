package com.tcs.insurance.tools.appgen;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.error.PebbleException;
import com.tcs.insurance.tools.appgen.constant.AppGenConstants;
import com.tcs.insurance.tools.appgen.utility.FileUtility;
import com.tcs.insurance.tools.appgen.utility.JsonUtility;
import com.tcs.insurance.tools.appgen.utility.PebbleUtility;

public class ApplicationAngular4Handler {
	private ApplicationAngular4Handler() {

	}
	public static void createProjectStructure(String projectName, String path)
	{
		
		String commands = "cd /d " + path + " && " +"ng"+" "+AppGenConstants.PROJECT_CREATION_COMMAND + " " + projectName +  " --skip-install" + " --routing --style=CSS";
		 
//		String commands = "cd /d " + path + " && " + AppGenConstants.NG_COMMAND + " " + AppGenConstants.PROJECT_CREATION_COMMAND + " " + projectName +  " --skip-install" + " --routing";
		
	
//		"cd /d " + "D:\\appgenang4\\testag7 " + " && " + AppGenConstants.NG_COMMAND + " "+"%USERPROFILE%\\AppData\\Roaming\\npm\\ng";
		System.out.println(commands);
		 
		callCMD(commands);			

		/*Process p;
		try {
			p = Runtime.getRuntime().exec(new String[]{"cmd","/c", command});
			int code = p.waitFor();
			System.out.println("Exit code :" + code);
			
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
	}
	
	public static void generateStructure(String name, String path, String type)
	{
		String commands = "cd /d " + path + " && " +"ng" + " " +AppGenConstants.GENERATE + " " + type + " " + name ;
		 
//		String commands = "cd /d " + path + " && " + AppGenConstants.NG_COMMAND + " " + AppGenConstants.GENERATE + " " + type + " " + name ;
		
		if(type.equalsIgnoreCase(AppGenConstants.SERVICE_COMMAND))
		{
//			commands = commands + " --module=app.module"; 
			commands = commands; 
		}
		System.out.println(commands);
		  
		callCMD(commands);			

	}
	
	public static void callCMD(String commands)
	{
		Process p;
		try {
			p = Runtime.getRuntime().exec(new String[]{"cmd","/c", commands});
			int code = p.waitFor();
			System.out.println("Exit code :" + code);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void generateApplication(String input, String lib,
			String application, String output) throws IOException,
			PebbleException {
		//"config", "ref" , "application", "output";
		/*-application portal
		-config "D:\Appgen\input\config\portal" 
		-output "D:\Appgen\input\generated"
		-ref "D:\Appgen\input\ref" 
		-angular "2"*/
		Map<String, Object> applicationMap = readApplication(input, application);
		String projDirPath = output + "/" + application;
		File projDir = new File(projDirPath);
		copyAsset(lib +"/lib/css", projDir +  "/src/assets/css");
		copyAsset(lib +"/lib/fonts", projDir +  "/src/assets/fonts");
		copyAsset(lib +"/lib/image", projDir +  "/src/assets/image");
		
		
		//createIndexHtmlFile(applicationMap, projDir);
		createAngularAppJsFiles(applicationMap,projDir);
		createDataServiceJsFile(applicationMap,projDirPath, projDir);
		/*createHelperJsFile(applicationMap, projDir);
		createLogServiceJsFile(applicationMap, projDir);
		createIdleServiceJsFile(applicationMap, projDir);
		createHttpInterceptorJsFile(applicationMap, projDir);
		createExceptionHandlerJsFile(applicationMap, projDir);
		createCommonFiles(applicationMap, projDir);*/
		createLayoutFiles(applicationMap, projDir);
		generateScreens(applicationMap, projDirPath, input);
	}

	private static Map<String, Object> readApplication(String input,
			String application) throws IOException {
		String filePath = new StringBuilder(input).append('/')
				.append(application).append(".json").toString();
		File appFile = new File(filePath);
		Map<String, Object> applicationMap = JsonUtility.readJsonFile(appFile);
		return applicationMap;
	}

	private static File createDirectories(String application,
			String outputFolder) throws IOException {
		File projDir = new File(outputFolder, application);

		if (!projDir.exists()) {
			projDir.mkdirs();
		}

		Map<String, Object> directoryMap = JsonUtility
				.readJsonFile("application-directory-structure.json");
		@SuppressWarnings("unchecked")
		List<String> directories = (List<String>) directoryMap
				.get("directories");
		for (String directory : directories) {
			File dir = new File(projDir, directory);
			if (!dir.exists()) {
				dir.mkdirs();
			}
		}

		return projDir;
	}

	private static void copyAsset(String path, String assetProjDir)
			throws IOException {
		
		
		File assetFolder = new File(path);
		File targetDir = new File(assetProjDir);
		FileUtility.copyFilesNotMatchingRecursively(assetFolder, targetDir);
		
		/*//Copy fonts
		File libFontsFolder = new File(libPath + "/fonts");
		FileUtility.copyFilesNotMatchingRecursively(libFontsFolder, targetDir);
		
		//Copy image
		File libImageFolder = new File(libPath + "/image");
		FileUtility.copyFilesNotMatchingRecursively(libImageFolder, targetDir);
		
		//Copy node_modules
		File targetNodeDir = new File(projDir);
		FileUtility.copyFilesNotMatchingRecursively(new File(libPath), targetNodeDir);*/
	}
	

	private static void createPomFile(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String pomFilePath = projDir.getAbsolutePath().concat("/pom.xml");
		PebbleUtility.generate("pebble2.0/pom.xml.peb", pomFilePath,
				applicationMap);
	}

	private static void createWebXml(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String webXmlPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.WEBAPP_FOLDER_PATH)
				.concat("/WEB-INF/web.xml");
		PebbleUtility
				.generate("pebble2.0/web.xml.peb", webXmlPath, applicationMap);
	}

	private static void createIndexHtmlFile(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String indexPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.WEBAPP_FOLDER_PATH)
				.concat("/index.html");
		PebbleUtility.generate("pebble2.0/index.html.peb", indexPath,
				applicationMap);
	}

	private static void createAngularAppJsFiles(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				//.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat("src/app").concat("/")
				.concat("app-routing.module.ts");
		PebbleUtility.generate("pebble2.0/appRoutingModule.ts.peb", appJsPath, applicationMap);
	}
//	PebbleUtility.generate("pebble2.0/appRoutingModule.ts.peb", appJsPath, applicationMap);

	private static void createDataServiceJsFile(
			Map<String, Object> applicationMap, String projDirPath, File projDir)
			throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		String fileName = "-data";
		generateStructure("./common/"+appName + fileName,projDirPath + "/src/app",AppGenConstants.SERVICE_COMMAND);
		

		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat("src/app/common").concat("/")
				.concat(appName).concat(fileName).concat(".service.ts");
		
		PebbleUtility.generate("pebble2.0/datasvc.ts.peb", appJsPath,
				applicationMap);
	}
	private static void createHelperJsFile(
		Map<String, Object> applicationMap, File projDir)
		throws PebbleException, IOException {
	String appName = (String) applicationMap.get("name");
	String appJsPath = projDir.getAbsolutePath().concat("/")
			.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
			.concat(appName).concat(".helper.js");
	PebbleUtility.generate("pebble2.0/helper.js.peb", appJsPath,
			applicationMap);
}

	private static void createLogServiceJsFile(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {

		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat("logService.ts");

		PebbleUtility.generate("pebble2.0/logService.ts.peb", appJsPath,
				applicationMap);
	}
	private static void createIdleServiceJsFile(
		Map<String, Object> applicationMap, File projDir)
		throws PebbleException, IOException {

	String appName = (String) applicationMap.get("name");
	String appJsPath = projDir.getAbsolutePath().concat("/")
			.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
			.concat("idleService.ts");

	PebbleUtility.generate("pebble2.0/idleService.ts.peb", appJsPath,
			applicationMap);
}
	private static void createHttpInterceptorJsFile(
		Map<String, Object> applicationMap, File projDir)
		throws PebbleException, IOException {

	String appName = (String) applicationMap.get("name");
	String appJsPath = projDir.getAbsolutePath().concat("/")
			.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
			.concat("httpInterceptor.js");

	PebbleUtility.generate("pebble/httpInterceptor.js.peb", appJsPath,
			applicationMap);
}

	private static void createExceptionHandlerJsFile(
			Map<String, Object> applicationMap, File projDir)
			throws PebbleException, IOException {

		String appName = (String) applicationMap.get("name");
		String appJsPath = projDir.getAbsolutePath().concat("/")
				.concat(AppGenConstants.APP_FOLDER_PATH).concat("/")
				.concat("exceptionConfig.ts");

		PebbleUtility.generate("pebble2.0/exceptionConfig.ts.peb", appJsPath,
				applicationMap);
	}

	private static void createLayoutFiles(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		applicationMap.put("header", "heading");
		File layoutDir = new File(projDir, "/src/app/layout");
		if (!layoutDir.exists()) {
			layoutDir.mkdirs();
		}
		
	    List<Map<String,Object>> layoutList = (List<Map<String,Object>>) applicationMap.get("layout");
	    if(layoutList!=null)
	    {
		for(Map<String, Object>  layout : layoutList){    		
		   String layoutName = layout.get("name").toString();
		   generateStructure(layoutName,projDir + "/src/app/layout",AppGenConstants.COMPONENT_COMMAND);
			
			String htmlPath = layoutDir.getAbsolutePath().concat("/").concat(layoutName).concat("/").concat(layoutName)
					.concat(".component.html");
			applicationMap.put("currentLayout", layout);
			PebbleUtility.generate("pebble2.0/layout.ts.peb", htmlPath,
					applicationMap);	
		 }
		
		if(layoutList.size()>0){
			applicationMap.remove("currentLayout");
			applicationMap.put("app", "app");
			String appHtmlPath = projDir.getAbsolutePath()
					.concat("/src/app/app.component.html");
			PebbleUtility.generate("pebble2.0/layout.ts.peb", appHtmlPath,
					applicationMap);
		}
	    }
	}
	
	private static void createCommonFiles(Map<String, Object> applicationMap,
			File projDir) throws PebbleException, IOException {
		String appName = (String) applicationMap.get("name");
		File commonDir = new File(projDir, AppGenConstants.COMMON_FOLDER_PATH);
		if (!commonDir.exists()) {
			commonDir.mkdirs();
		}
		String headerJsPath = commonDir.getAbsolutePath().concat("/")
				.concat("header.controller.ts");
		PebbleUtility.generate("pebble2.0/header.controller.ts.peb", headerJsPath,
				applicationMap);
		String menuJsPath = commonDir.getAbsolutePath().concat("/")
				.concat("menu.controller.ts");
		PebbleUtility.generate("pebble2.0/menu.controller.ts.peb", menuJsPath,
				applicationMap);
		String progressJsPath = commonDir.getAbsolutePath().concat("/")
			.concat("progressbar.controller.ts");
	PebbleUtility.generate("pebble2.0/progressbar.controller.ts.peb", progressJsPath,
			applicationMap);
	String progressHelperJsPath = commonDir.getAbsolutePath().concat("/")
		.concat("progressbar.helper.ts");
PebbleUtility.generate("pebble2.0/progressbar.helper.ts.peb", progressHelperJsPath,
		applicationMap);
String progressConstantJsPath = commonDir.getAbsolutePath().concat("/")
.concat("progressbar.constant.ts");
PebbleUtility.generate("pebble2.0/progressbar.constant.ts.peb", progressConstantJsPath,
applicationMap);

String errorControllerPath = commonDir.getAbsolutePath().concat("/")
.concat("errorController.ts");
PebbleUtility.generate("pebble2.0/errorController.ts.peb", errorControllerPath,
applicationMap);

String menuServiceJsPath = commonDir.getAbsolutePath().concat("/")
			.concat("menu.service.ts");
	PebbleUtility.generate("pebble2.0/menu.service.ts.peb", menuServiceJsPath,
			applicationMap);
	
	String menuFormServiceJsPath = commonDir.getAbsolutePath().concat("/")
			.concat("cnacFormService.js");
	PebbleUtility.generate("pebble2.0/menuFormService.ts.peb", menuFormServiceJsPath,
			applicationMap);
	}

	private static void generateScreens(Map<String, Object> applicationMap,
			String projDir, String inputPath) throws IOException, PebbleException {
		List<String> screens = (List<String>) applicationMap.get("screens");
		for (String screen : screens) {
			// to create a componenent 
			generateStructure(screen,projDir + "/src/app/",AppGenConstants.COMPONENT_COMMAND);
			generateScreen((String) applicationMap.get("name"), screen,
					new File(projDir + "/src/app/"), inputPath);
		}
	}

	private static void generateScreen(String application, String screen,
			File projDir, String inputPath) throws IOException, PebbleException {
		//File appDir = new File(projDir);
		File screenDir = new File(projDir, screen);
		if (!screenDir.exists()) {
			screenDir.mkdirs();
		}
		File customDir = new File(projDir,application + AppGenConstants.CUSTOM_SERVICE_NAME);
		if (!customDir.exists()) {
		    customDir.mkdirs();
		}
		Map<String, Object> screenMap = readScreen(inputPath, screen);
		screenMap.put("application", application);
		generateHtml(screenMap, screenDir);
		generateCtrlJs(screenMap, screenDir);
		generateServiceJs(screenMap, projDir);
		generateCustomJs(screenMap, projDir,application);
	}

	private static Map<String, Object> readScreen(String input, String screen)
			throws IOException {
		String filePath = new StringBuilder(input).append('/').append(screen)
				.append(".json").toString();
		File screenFile = new File(filePath);
		Map<String, Object> screenMap = JsonUtility.readJsonFile(screenFile);
		return screenMap;
	}

	private static void generateHtml(Map<String, Object> screenMap, File dir)
			throws PebbleException, IOException {
		String screenName = (String) screenMap.get("name");
		String htmlPath = dir.getAbsolutePath().concat("/").concat(screenName)
				.concat(".component.html");
		//changes above line
		PebbleUtility.generate("pebble2.0/view.html.peb", htmlPath, screenMap);
	}

	private static void generateCtrlJs(Map<String, Object> screenMap, File dir)
			throws PebbleException, IOException {
		String screenName = (String) screenMap.get("name");
		String ctrlJsPath = dir.getAbsolutePath().concat("/")
				.concat(screenName).concat(".component.ts");
		PebbleUtility.generate("pebble2.0/ctrl.ts.peb", ctrlJsPath, screenMap);
	}

	private static void generateServiceJs(Map<String, Object> screenMap,
			File dir) throws PebbleException, IOException {
		String screenName = (String) screenMap.get("name");
		/*cd /d D:\Appgen\input\generated\portal\src\app\customerinformation
		&& %USERPROFILE%\AppData\Roaming\npm\ng generate service customerinformation
		*/
		
		String serviceJsPath = dir.getAbsolutePath().concat("/").concat(screenName).concat("/")
				.concat(screenName).concat(".service.ts");
		
		generateStructure("./" + screenName + "/" + screenName ,dir.getAbsolutePath() ,AppGenConstants.SERVICE_COMMAND);
		
		PebbleUtility.generate("pebble2.0/svc.ts.peb", serviceJsPath, screenMap);
	}
	
	private static void generateCustomJs(Map<String, Object> screenMap, File dir, String application)
		throws PebbleException, IOException {
	String screenName = (String) screenMap.get("name");
	String ctrlJsPath = dir.getAbsolutePath().concat("/").concat(application)
			.concat(AppGenConstants.CUSTOM_SERVICE_NAME)
			.concat("/")
			.concat(screenName).concat("-custom.service.ts");
	
	generateStructure("./" + application + AppGenConstants.CUSTOM_SERVICE_NAME + "/" + screenName+"-custom" ,dir.getAbsolutePath()  ,AppGenConstants.SERVICE_COMMAND);
	
	PebbleUtility.generate("pebble2.0/custom.ts.peb", ctrlJsPath, screenMap);
}
}
