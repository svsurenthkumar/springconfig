package com.tcs.insurance.tools.pebbleextensions;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Function;

public class RestMethod implements Function {

	@Override
	public List<String> getArgumentNames() {
		List<String> args = new ArrayList<String>();
		args.add("url");
		return args;
	}

	@Override
	public Object execute(Map<String, Object> args) {
		String url = (String) args.get("url");
		StringBuffer method = new StringBuffer();
		String tokens[] = url.split("/");
		if (tokens[0].equals("http")) {
			if (tokens.length > 4) {
			    	int index = tokens[tokens.length - 1].indexOf(".");
			    	if (index!=-1){
				method.append(tokens[tokens.length - 1].substring(0,index));
			    	}
			    	else{
			    	method.append(tokens[tokens.length - 1]);
			    	}
				
				method.append(tokens[tokens.length - 2].substring(0, 1)
						.toUpperCase() + tokens[tokens.length - 2].substring(1));
			} else {
				method.append(tokens[tokens.length - 1]);
			}
		} else {
			if (tokens.length > 2) {
			    int lastIndex = tokens[tokens.length - 1].indexOf(".");
			    if(lastIndex!=-1){
			   
				method.append(tokens[tokens.length - 1].substring(0,lastIndex));
			    }
			    else{
				method.append(tokens[tokens.length - 1]);
			    }
				
				if (tokens[tokens.length - 2].indexOf("-") != -1) {

					int index = tokens[tokens.length - 2].indexOf("-");

					method.append(tokens[tokens.length - 2].substring(0, 1)
							.toUpperCase()
							+ tokens[tokens.length - 2].substring(1, index)
							+ tokens[tokens.length - 2].substring(index + 1));
				} else {

					method.append(tokens[tokens.length - 2].substring(0, 1)
							.toUpperCase()
							+ tokens[tokens.length - 2].substring(1));
				}
			} else {
				method.append(tokens[tokens.length - 1]);
			}
		}
		return method.toString();
	}

}
