package com.tcs.insurance.tools.pebbleextensions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.mitchellbosecke.pebble.extension.Function;

public class IsInListFunction implements Function{

	@Override
	public List<String> getArgumentNames() {
		List<String> args = new ArrayList<String>();
		args.add("text");
		args.add("list");
		return args;
	}

	@Override
	public Object execute(Map<String, Object> args) {
		String text = (String) args.get("text");
		List<String> list = (List<String>)args.get("list");
		if(text == null || list == null) {
			return false;
		}
		else {
			for(String item: list){
				if(text.equals(item)) return true;
			}
		}
		return false;
	}

}
