/*
import j2html.TagCreator;
import j2html.attributes.Attr;
import j2html.tags.ContainerTag;

import static j2html.TagCreator.*;
public class sample {
    
    static String renderTest() {
        boolean USER_SHOULD_LOG_IN = true;
        boolean USER_SHOULD_SIGN_UP = false;
        return document().render() +
            html().with(
                head().with(
                    title().withText("Test")
                ),
                body().with(
                    header().with(
                        h1().with(
                            text("Test Header "),
                            a("with link").withHref("http://example.com"),
                            text(".")
                        )
                    ),
                    main().with(
                        h2("Test Form"),
                        div().with(
                            input().withType("email").withName("email").withPlaceholder("Email"),
                            input().withType("password").withName("password").withPlaceholder("Password")
                        ).condWith(USER_SHOULD_LOG_IN, button().withType("submit").withText("Login")
                        ).condWith(USER_SHOULD_SIGN_UP, button().withType("submit").withText("Signup"))
                    ),
                    footer().attr(Attr.CLASS, "footer").condAttr(1 == 1, Attr.ID, "id").withText("Test Footer"),
                    script().withSrc("/testScript.js")
                )
            ).render();
    }
    
    
    
    class Employee {
        final int id;
        final String name;
        final String title;

        Employee(int id, String name, String title) {
            this.id = id;
            this.name = name;
            this.title = title;
        }
    }
    
    
}

*/