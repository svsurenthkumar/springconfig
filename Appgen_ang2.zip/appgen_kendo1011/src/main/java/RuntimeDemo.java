
public class RuntimeDemo {

   public static void main(String[] args) {
      try {

    	  
    	  Process p;
  			p = Runtime.getRuntime().exec(new String[]{"cmd","/c", "cd /d  D:\\appgenang4\\config\\output && ng new lsa --skip-install --routing --style=CSS"});
  			int code = p.waitFor();
  			System.out.println("Exit code :" + code);
         // print a message
         System.out.println("Executing notepad.exe");

         // create a process and execute notepad.exe
//         Process process = Runtime.getRuntime().exec("cd /d  D:\\appgenang4\\config\\output && ng new lsa --skip-install --routing --style=CSS");

         // print another message
         System.out.println("Notepad should now open.");

      } catch (Exception ex) {
         ex.printStackTrace();
      }
   }
}
