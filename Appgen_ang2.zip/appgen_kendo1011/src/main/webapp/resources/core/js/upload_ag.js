var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $filter,$timeout) {
	$scope.carname = "Volvo";

//1st table
	$scope.searchForming = JSON.parse($("#listuser").html());
	$scope.sort = {
		sortingOrder : 'id',
		reverse : false
	};
	$scope.gap = 10;
	$scope.filteredItems = [];
	$scope.groupedItems = [];
	$scope.itemsPerPage = 10;
	$scope.pagedItems = [];
	$scope.currentPage = 0;

	var searchMatch = function(haystack, needle) {
		if (!needle) {
			return true;
		}
		return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== 0;
	};

	// init the filtered items
	$scope.search = function() {
		$scope.filteredItems = $filter('filter')($scope.searchForming, function(row) {
			for (var attr in row) {
				if (searchMatch(row[attr], $scope.query))
					return true;
			}
			return false;
		});
		// take care of the sorting order
		if ($scope.sort.sortingOrder !== '') {
			$scope.filteredItems = $filter('orderBy')($scope.filteredItems, $scope.sort.sortingOrder, $scope.sort.reverse);
		}
		$scope.currentPage = 0;
		// now group by pages
		$scope.groupToPages();
	};


	$scope.groupToPages = function() {
		$scope.pagedItems = [];

		for (var i = 0; i < $scope.filteredItems.length; i++) {
			if (i % $scope.itemsPerPage === 0) {
				$scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [ $scope.filteredItems[i] ];
			} else {
				$scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
			}
		}
	};

	$scope.range = function(size, start, end) {
		var ret = [];
//		console.log(size, start, end);

		if (size < end) {
			end = size;
			if (size > 10) {
				start = size - $scope.gap;
			} else if (size <= 10) {
				start = Math.floor(size / $scope.gap);
			}

		}
		for (var i = start; i < end; i++) {
			ret.push(i);
		}
//		console.log(ret);
		return ret;
	};


	$scope.prevPage = function() {
		if ($scope.currentPage > 0) {
			$scope.currentPage--;
		}
	};

	$scope.nextPage = function() {
		if ($scope.currentPage < $scope.pagedItems.length - 1) {
			$scope.currentPage++;
		}
	};

	$scope.setPage = function() {
		$scope.currentPage = this.n;
	};

	$scope.firstPage = function() {
		$scope.currentPage = 0;
	};

	$scope.lastPage = function(size) {
		$scope.currentPage = $scope.pagedItems.length - 1;
	};
	// functions have been describe process the data for display
	$scope.search();

//table 2
	
	$scope.formListdetails = JSON.parse($("#formListdetails").html());
	var formct=_.uniqBy($scope.formListdetails, 'formName');
	$scope.formcount=formct.length;
	localStorage.setItem("formdetails",$("#formListdetails").html());
	//localStorage.setItem("textBlockNum",$("#textBlockNum").html());
	var db = openDatabase ('Formsave', '1.0', 'test DB', 10*1024*1024);
	db.transaction(function (tx) {
		
		tx.executeSql ('DROP TABLE IF EXISTS content');
		tx.executeSql ('CREATE TABLE content (contentname,contentvalue)');
	tx.executeSql('DELETE FROM content');
		var contentname="'"+"textBlockNum"+"'";
		var stringconcat='Insert into content values('+contentname+",'"+$("#textBlockNum").html()+"'"+')';
		tx.executeSql(stringconcat);
		
	});
	

	$scope.sorts = {
			sortingOrder : 'id',
			reverse : false
		};
		$scope.gap = 10;
		$scope.filteredItemss = [];
		$scope.groupedItemss = [];
		$scope.itemsPerPage1 = 10;
		$scope.pagedItemss = [];
		$scope.currentPages = 0;

		var searchMatch = function(haystack, needle) {
			if (!needle) {
				return true;
			}
			return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== 0;
		};

		// init the filtered items
		$scope.searchs = function() {
			$scope.filteredItemss = $filter('filter')($scope.formListdetails, function(row) {
				for (var attr in row) {
					if (searchMatch(row[attr], $scope.query))
						return true;
				}
				return false;
			});
			// take care of the sorting order
			if ($scope.sorts.sortingOrder !== '') {
				$scope.filteredItemss = $filter('orderBy')($scope.filteredItemss, $scope.sorts.sortingOrder, $scope.sorts.reverse);
			}
			$scope.currentPages = 0;
			// now group by pages
			$scope.groupToPages();
		};


		$scope.groupToPages = function() {
			$scope.pagedItemss = [];

			for (var i = 0; i < $scope.filteredItemss.length; i++) {
				if (i % $scope.itemsPerPage1 === 0) {
					$scope.pagedItemss[Math.floor(i / $scope.itemsPerPage1)] = [ $scope.filteredItemss[i] ];
				} else {
					$scope.pagedItemss[Math.floor(i / $scope.itemsPerPage1)].push($scope.filteredItemss[i]);
				}
			}
		};

		$scope.ranges = function(size, start, end) {
			var ret = [];
			//console.log(size, start, end);

			if (size < end) {
				end = size;
				if (size > 10) {
					start = size - $scope.gap;
				} else if (size <= 10) {
					start = Math.floor(size / $scope.gap);
				}

			}
			for (var i = start; i < end; i++) {
				ret.push(i);
			}
			//console.log(ret);
			return ret;
		};


		$scope.prevPages = function() {
			if ($scope.currentPages > 0) {
				$scope.currentPages--;
			}
		};

		$scope.nextPages = function() {
			if ($scope.currentPages < $scope.pagedItemss.length - 1) {
				$scope.currentPages++;
			}
		};

		$scope.setPages = function() {
			$scope.currentPages = this.n;
		};

		$scope.firstPages = function() {
			$scope.currentPages = 0;
		};

		$scope.lastPages = function(size) {
			$scope.currentPages = $scope.pagedItemss.length - 1;
		};
		// functions have been describe process the data for display
		//	$scope.search();
		$scope.searchs();

		
		$("#displaycontent").show();

});