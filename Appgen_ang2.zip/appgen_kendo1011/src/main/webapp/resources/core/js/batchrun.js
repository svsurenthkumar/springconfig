   // var json = {"Array": [1, 2, 3], "Boolean": true, "Null": null, "Number": 123, "Object": {"a": "b", "c": "d"}, "String": "Hello World"};

   
    /*
    var parentjson={
    	"name" : "lsa",
    	"title" : "Life Science",
    	"fields" : [
    		{
    			"name" : "customer",
    			"type" : "object"
    		},
    		{
    			"name" : "headerInfo",
    			"type" : "object"
    		},
    		{
    			"name" : "product",
    			"type" : "object"
    		},

    		
    		
    		{
    			"name" : "drivers",
    			"type" : "list"
    		}
    		
    		
    	],
    	"screens" : [
    		
    		"customerinformation"	
    		
    		
    	]
    };
    
    var childjson={
    		"name" : "customerinformation",
    		"fieldsUsed" : ["customer","headerInfo"],
    		"firstLevel":"CUSTOMER INFO",
    		"secondLevel":"Customer Information",
    		"tempFields": [ 
    			

    		],	
    		"actions" : [
    		
    			
    		],
    		"screenElements" : [
    			{
    				"type" : "header",
    				"header" : "Customer Information"
    			},
    			{
    				"type" : "kendotext",
    				"textype":"number",
    				"id" : "sampleid",
    				"textboxname":"samplename",
    				"labelname":"Account",
    				"min":"0",
    				"max":"4",
    				"textStyleClass":"",
    				"title":"Account",
    				"value":"",
    				"textStyleClass":"",
    				"labelStyleClass":"",
    				"labelInlineClass":"margin-left:22px;",
    				"textInlineClass":"width:30%;"
    			},
    			{
    			"type": "radio",
    			"composite": "true",
    			"label": " ",
    			"value": "customer.wasPriorCarrier",
    			"id": "wasPriorCarrier",
    			"inputClass": "col-md-2 radioComposite",
    			"errorids":"[1005]",
    			"options": [{
    				"label": "Contains",
    				"value": "yesPriorCarrier"
    			},
    			{
    				"label": "Exact",
    				"value": "noPriorCarrier"
    			}],
    			"mandatoryExpression": "false",
    			"styleClass": "col-md-3"
    		},	
    			{
    				"type" : "kendotext",
    				"textype":"text",
    				"id" : "sampleid",
    				"textboxname":"samplename",
    				"labelname":"Account",
    				"min":"0",
    				"max":"4",
    				"textStyleClass":"",
    				"title":"Account",
    				"value":"",
    				"textStyleClass":"",
    				"labelStyleClass":"",
    				"labelInlineClass":"margin-left:22px;",
    				"textInlineClass":"width:60%;"
    			},
    			{
    				"type" : "kendodropdown",
    				"id" : "color",
    				"label":"sampledropdown",
    				"data":'[{ "text": "Black", "value": "1" },{ "text": "Orange", "value": "2" },{ "text": "Grey", "value": "3" }]'
    			},
    			  {
    				"type" : "kendocheckbox",
    				"id" : "sampleid",
    				"checkboxname":"samplename",
    				"labelname":"test",
    				"title":"",
    				"value":"",
    				"checkboxStyleClass":"col-md-2",
    				"labelStyleClass":"col-md-2"
    			},
    			 {
    				"type" : "kendocheckbox",
    				"id" : "second",
    				"checkboxname":"secondbox",
    				"labelname":"test",
    				"title":"",
    				"value":"",
    				"checkboxStyleClass":"col-md-2",
    				"labelStyleClass":"col-md-2"
    			},
    			{
    			"type": "composite",
    			"children": [{
    				"type" : "kendobutton",
    				"id" : "findnow",
    				"name":"Find Now",
    				"styleClass":"col-md-2"
    			},
    			{
    				"type" : "kendobutton",
    				"id" : "newsearch",
    				"name":"New Search",
    				"styleClass":"col-md-2"
    			}		
    			]},
    			
    				{		         
    							"type":"localInfoMsg",
    	                        "scopeinfovar":"true",
    	                        "infomsgcontent":"77 Matches found.50 are displayed.Please refine search",
    	                        "styleClass":"test",
    	                        "showvariable":"true",
    								"inlineclass":"background-color: #769dbc; font-weight: bold;"
    	             },		
    	{
    				"type" : "kendobutton",
    				"id" : "reteriveresult",
    				"name":"Reterive All Results"
    				},			 
    				
    			{
    				"type" : "kendotable",
    				"columns":'[{ "selectable": "true", "width": "50px" },{ "field":"ProductName", "title": "Product Name" },{ "field": "UnitPrice", "title":"Unit Price"},{ "field":"UnitsInStock", "title":"Units In Stock"},{ "field": "Discontinued"}]',
    				 "pageable": "true",
    	              "scrollable": "false",
    	             "sortable": "true",
    				 "serviceurl":"https://demos.telerik.com/kendo-ui/service/Products"
    			},
    			{
    			"type": "composite",
    			"children": [{
    				"type" : "kendobutton",
    				"id" : "getcopy",
    				"name":"Get Copy",
    				"styleClass":"col-md-2"
    			},
    			{
    				"type" : "kendobutton",
    				"id" : "checkout",
    				"name":"Cancel Checkout",
    				"styleClass":"col-md-2"
    			},
    			{
    				"type" : "kendobutton",
    				"id" : "checkouts",
    				"name":"checkouts",
    				"styleClass":"col-md-2"
    			},
    			{
    				"type" : "kendobutton",
    				"id" : "checkin",
    				"name":"Check In",
    				"styleClass":"col-md-2"
    			},
    			
    		{
    				"type" : "kendobutton",
    				"id" : "details",
    				"name":"Details",
    				"styleClass":"col-md-2"
    			}	
    				
    		]}
    			],
    			
    		"buttons" : [
    			
    		]
    	};*/
    
    angular.module('myApp', ['ng.jsoneditor']).controller('myCtrl', function ($scope) {
    	
    	 var parentjson=JSON.parse($("#parentjsoninput").html());
    	    var childjson=JSON.parse($("#childjsoninput").html());
        $scope.obj = {data: parentjson, options: {mode: 'tree'}};
        $scope.onLoad = function (instance) {
            instance.expandAll();
        };
        
        
        $scope.childjson = {data: childjson, options: {mode: 'tree'}};
        
        $scope.changeData = function () {
            $scope.obj.data = {foo: 'bar'};
        };
        $scope.changeOptions = function () {
            $scope.obj.options.mode = $scope.obj.options.mode == 'tree' ? 'code' : 'tree';
        };
        
        $scope.changeData1 = function () {
            $scope.childjson.data = {foo: 'bar'};
        };
        $scope.changeOptions1 = function () {
            $scope.childjson.options.mode = $scope.childjson.options.mode == 'tree' ? 'code' : 'tree';
        };

        //other
        $scope.pretty = function (obj) {
            return angular.toJson(obj, true);
        }
        
        $scope.parentJsonSubmit = function () {
        	
        	  $("#configpanel").show();
			   $("#childconfigpanel").hide();
			   $("#outputpanel").hide();
						$.ajax({
						    type: 'POST',
						    url: "parentjsongen",
						  data: {
							  config : $("#config").val(),
							  jsonvalue : JSON.stringify($scope.obj.data)
						        },
						    error: function(xhr) { // if error occured
						        alert("Error occured.please try again");
						    },
						    complete: function(data) {
						        alert("successfully Project Generated!")
						    }   
						});
        }
        
        $scope.retrieveJSON = function () {
						$.ajax({
						    type: 'POST',
						    url: "retrievejson",
						    data: {
								  config : $("#config").val(),
								  pagename : $("#pagename").val()
							        },
						    error: function(xhr) { // if error occured
						        alert("Error occured.please try again");
						    },
						    complete: function(data) {
						    	$scope.$apply(function() {
						    		$scope.childjson ={data: JSON.parse(data.responseText), options: {mode: 'tree'}};
						    	});
						    	 
						        alert("successfully Project Generated!");
						    }   
						});
      }
        
        
        
        $scope.childJsonGen = function () {
        	
        	var srcstring="http://localhost:8080/lsa/#/"+$("#pagename").val();
        	$("#linknav").attr("href",srcstring);
        	$("#iframeid").attr("src",srcstring);
        	
      	  $("#configpanel").show();
			   $("#childconfigpanel").hide();
			   $("#outputpanel").hide();
						$.ajax({
						    type: 'POST',
						    url: "childjsongen",
						  data: {
							  config : $("#config").val(),
							  lib : $("#ref").val(),
							  output : $("#output").val(),
							  jsonvalue : JSON.stringify($scope.childjson.data),
							  pagename : $("#pagename").val()
						        },
						    error: function(xhr) { // if error occured
						        alert("Error occured.please try again");
						    },
						    complete: function(data) {
						        alert("successfully Page Generated!")
						    }   
						});
      }
        
        
        
    });