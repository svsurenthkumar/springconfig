var  result=[];
var db = openDatabase ('Formsave', '1.0', 'test DB', 10*1024*1024);
$( document ).ready(function() {
		
	db.transaction(function (tx) {
	    tx.executeSql('SELECT * FROM content', [], function (tx, rs) {
	    	
	        for(var i=0; i<rs.rows.length; i++) {
		            var row = rs.rows.item(i)
		            result[i] = { contentname: row['contentname'],
		            	contentvalue: row['contentvalue']
		            }
		         } 	

	    }, null);
	 });
});


var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $filter,$timeout) {

//1st table
	
	$scope.selectfirst= function() {

		var formname=$(".firsttable table input[type=checkbox]:checked").parent().parent().parent().find("td")[1];
		var textblock=$(".firsttable table input[type=checkbox]:checked").parent().parent().parent().find("td")[3];
		$("#formnameid").val($(formname).text());
		$("#textblockid").val($(textblock).text());
		//console.log($(formname).text());
		//console.log($(textblockid).text());
	}
	/*$scope.searchfilter= function() {
		
	var transnum=$("#searchFilter").val();
	var searchFormings =JSON.parse(localStorage.getItem("formdetails"));
	$scope.searchForming = _.filter(items, function (item) {
		  return _.some(item.tags, function (tag) {
		    return _.startsWith(tag, transnum);
		  });
		});
	
	}*/
	$scope.selectSecond= function() {
		$scope.textblocklist=[]
		var searchFormings=[];
		var valuecheck=0;
		var checkvalue;
		var textblockname=$(".secondtable table input[type=checkbox]:checked").parent().parent().parent().find("td")[4];
		textblockname=$(textblockname).text();
		$scope.textblocknames=textblockname;
		
		
		var reterive=[];
		var db = openDatabase ('Formsave', '1.0', 'test DB', 10*1024*1024);
		
		     //console.log(pleaseWork);
		searchFormings =JSON.parse(result[0]['contentvalue']);
	          
		$scope.textblocklist=_.filter(searchFormings, function(o) { return o.textBlockName==textblockname });
		     // any further processing here

	
		
			/*var numbercheck=['0','1','2','3','4','5','6','7','8','9'];
			var atok=['A','B','C','D','E','F','G','H','I','J','K'];
			var ltoz=['L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
			
			var checkvalue1=_.find(numbercheck, function(o) { return o==textblockname.substring(5,6) });
			
			if(checkvalue1!=undefined)
				{
				searchFormings =JSON.parse(localStorage.getItem("textBlockNum"));
				$scope.textblocklist=_.filter(searchFormings, function(o) { return o.textBlockName==textblockname });
				}
			var checkvalue2=_.find(atok, function(o) { return o==textblockname.substring(5,6) });
			
			if(checkvalue1!=undefined)
			{
			searchFormings =JSON.parse(localStorage.getItem("textBlockATK"));
			$scope.textblocklist=_.filter(searchFormings, function(o) { return o.textBlockName==textblockname });
			}
			
			var checkvalue3 =_.find(ltoz, function(o) { return o==textblockname.substring(5,6) });
				
			if(checkvalue3!=undefined)
			{
			searchFormings =JSON.parse(localStorage.getItem("textBlockLTZNum"));
			$scope.textblocklist=_.filter(searchFormings, function(o) { return o.textBlockName==textblockname });
			}*/
			
//		alert($scope.textblocklist);
	}
	
	
	
	$scope.searchfirst= function() {
		var transnum=$("#transnum").val();
	var searchFormings =JSON.parse(localStorage.getItem("formdetails"));
	var setsearchFormings=_.filter(searchFormings, function(o) { return o.aunr==transnum });
	
	$scope.searchForming=_.uniqBy(setsearchFormings, 'formName');
	
	$scope.sort = {
		sortingOrder : 'id',
		reverse : false
	};
	$scope.gap = 10;
	$scope.filteredItems = [];
	$scope.groupedItems = [];
	$scope.itemsPerPage = 5;
	$scope.pagedItems = [];
	$scope.currentPage = 0;

	var searchMatch = function(haystack, needle) {
		if (!needle) {
			return true;
		}
		return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== 0;
	};

	// init the filtered items
	$scope.search = function() {
		$scope.filteredItems = $filter('filter')($scope.searchForming, function(row) {
			for (var attr in row) {
				if (searchMatch(row[attr], $scope.query))
					return true;
			}
			return false;
		});
		// take care of the sorting order
		if ($scope.sort.sortingOrder !== '') {
			$scope.filteredItems = $filter('orderBy')($scope.filteredItems, $scope.sort.sortingOrder, $scope.sort.reverse);
		}
		$scope.currentPage = 0;
		// now group by pages
		$scope.groupToPages();
	};


	$scope.groupToPages = function() {
		$scope.pagedItems = [];

		for (var i = 0; i < $scope.filteredItems.length; i++) {
			if (i % $scope.itemsPerPage === 0) {
				$scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [ $scope.filteredItems[i] ];
			} else {
				$scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
			}
		}
	};

	$scope.range = function(size, start, end) {
		var ret = [];
		//console.log(size, start, end);

		if (size < end) {
			end = size;
			if (size > 10) {
				start = size - $scope.gap;
			} else if (size <= 10) {
				start = Math.floor(size / $scope.gap);
			}

		}
		for (var i = start; i < end; i++) {
			ret.push(i);
		}
		//console.log(ret);
		return ret;
	};


	$scope.prevPage = function() {
		if ($scope.currentPage > 0) {
			$scope.currentPage--;
		}
	};

	$scope.nextPage = function() {
		if ($scope.currentPage < $scope.pagedItems.length - 1) {
			$scope.currentPage++;
		}
	};

	$scope.setPage = function() {
		$scope.currentPage = this.n;
	};

	$scope.firstPage = function() {
		$scope.currentPage = 0;
	};

	$scope.lastPage = function(size) {
		$scope.currentPage = $scope.pagedItems.length - 1;
	};
	// functions have been describe process the data for display
	$scope.search();


	}
	
	
	$scope.searchSecond= function() {
		var formnameid=$("#formnameid").val();
		var textblockid=$("#textblockid").val();
		localStorage.setItem("formname",formnameid);
		localStorage.setItem("texblockname",textblockid);

		var seconddetails =JSON.parse(localStorage.getItem("formdetails"));
		$scope.formListdetails=_.filter(seconddetails, function(o) { return( o.aunr==textblockid && o.formName==formnameid)});
		
		$scope.sorts = {
				sortingOrder : 'id',
				reverse : false
			};
			$scope.gap = 10;
			$scope.filteredItemss = [];
			$scope.groupedItemss = [];
			$scope.itemsPerPage1 = 5;
			$scope.pagedItemss = [];
			$scope.currentPages = 0;

			var searchMatch = function(haystack, needle) {
				if (!needle) {
					return true;
				}
				return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== 0;
			};

			// init the filtered items
			$scope.searchs = function() {
				$scope.filteredItemss = $filter('filter')($scope.formListdetails, function(row) {
					for (var attr in row) {
						if (searchMatch(row[attr], $scope.query))
							return true;
					}
					return false;
				});
				// take care of the sorting order
				if ($scope.sorts.sortingOrder !== '') {
					$scope.filteredItemss = $filter('orderBy')($scope.filteredItemss, $scope.sorts.sortingOrder, $scope.sorts.reverse);
				}
				$scope.currentPages = 0;
				// now group by pages
				$scope.groupToPages();
			};


			$scope.groupToPages = function() {
				$scope.pagedItemss = [];

				for (var i = 0; i < $scope.filteredItemss.length; i++) {
					if (i % $scope.itemsPerPage1 === 0) {
						$scope.pagedItemss[Math.floor(i / $scope.itemsPerPage1)] = [ $scope.filteredItemss[i] ];
					} else {
						$scope.pagedItemss[Math.floor(i / $scope.itemsPerPage1)].push($scope.filteredItemss[i]);
					}
				}
			};

			$scope.ranges = function(size, start, end) {
				var ret = [];
				//console.log(size, start, end);

				if (size < end) {
					end = size;
					if (size > 10) {
						start = size - $scope.gap;
					} else if (size <= 10) {
						start = Math.floor(size / $scope.gap);
					}

				}
				for (var i = start; i < end; i++) {
					ret.push(i);
				}
				//console.log(ret);
				return ret;
			};


			$scope.prevPages = function() {
				if ($scope.currentPages > 0) {
					$scope.currentPages--;
				}
			};

			$scope.nextPages = function() {
				if ($scope.currentPages < $scope.pagedItemss.length - 1) {
					$scope.currentPages++;
				}
			};

			$scope.setPages = function() {
				$scope.currentPages = this.n;
			};

			$scope.firstPages = function() {
				$scope.currentPages = 0;
			};

			$scope.lastPages = function(size) {
				$scope.currentPages = $scope.pagedItemss.length - 1;
			};
			// functions have been describe process the data for display
			//	$scope.search();
			$scope.searchs();



	}
});