var  result=[];
$( document ).ready(function() {
		
	db.transaction(function (tx) {
	    tx.executeSql('SELECT * FROM content', [], function (tx, rs) {
	    	
	        for(var i=0; i<rs.rows.length; i++) {
		            var row = rs.rows.item(i)
		            result[i] = { contentname: row['contentname'],
		            	contentvalue: row['contentvalue']
		            }
		         } 	

	    }, null);
	 });
	
$("#formname").val(localStorage.getItem("formname"));
$("#tid").val(localStorage.getItem("texblockname"));
		


$(".dropdown-menu li a").click(function(){
	  $(this).parents(".dropdown").find('.btn').html($(this).text() + ' <span class="caret"></span>');
	  $(this).parents(".dropdown").find('.btn').val($(this).data('value'));
	});

});

var db = openDatabase ('Formsave', '1.0', 'test DB', 10*1024*1024);

function pdfView()
{
	
	$("#displayxml").hide();
var pdf = new jsPDF('p', 'pt', 'letter');
pdf.canvas.height = 272 * 11;
pdf.canvas.width = 82 * 11;
var element = document.getElementById('viewhtml');
html2pdf(element, pdf, function(pdf){
 var iframe = document.createElement('iframe');
  iframe.setAttribute('style','position:absolute;right:0; top:0; bottom:0; height:100%; width:500px');
  document.body.appendChild(iframe);
  iframe.src = pdf.output('datauristring');
  
  //$("#pdfFormDisplay").html(pdf.output('datauristring'));
});
}

function updatepdf()
{
	
	var searchFormings=[]; 
	searchFormings =JSON.parse(result[0]['contentvalue']);
	
     $("#displayxml").show();
     $("#displayForm").hide();
     
		var formnameid=localStorage.getItem("formname");
		var textblockid=localStorage.getItem("texblockname");
		var seconddetails =JSON.parse(localStorage.getItem("formdetails"));
		var jsonresponse=_.filter(seconddetails, function(o) { return( o.aunr==textblockid && o.formName==formnameid)});
	
		var dynamicvalue=[];
		var textValue=[];
		var stringconcat="";
		
		dynamicvalue.push({
		"TransactionNumber":textblockid,
		"TextBlock":null
		});
		
		dynamicvalue.push({
		"FormName":formnameid,
		"TransactionNumber":textblockid
		});

		jsonresponse=_.sortBy(jsonresponse, 'sstbsnr');
		
		setTimeout(function(){ 
			$.each(jsonresponse,function(index,value)
			       {
			dynamicvalue.push({
			"TextBlockName":value.sstbinr,
			"FormName":formnameid
			})
			
			});
		});
		
		var combineblock='{"Transaction":[  { "TransactionNumber":'+"\""+textblockid+"\"";
		combineblock+=',"FormNumber":'+"\""+formnameid+"\"";
		combineblock+=',"FormName":[{  "TextBlock":[';
		dynamicvalue=_.uniqWith(dynamicvalue, _.isEqual);
		//jsonresponse=_.uniqWith(jsonresponse, _.isEqual);
		jsonresponse =_.sortBy(jsonresponse, function(o) { return Number(o.sstbsnr) });
	var datas="";
	var falg=0;
			$.each(jsonresponse,function(index,value){				
//				setTimeout(function(jsonresponse){
				var textblocklist=[];				
				var textblockname=value.sstbinr; 
				var reterive=[];				
					textblocklist=_.filter(searchFormings, function(o) { return o.textBlockName==textblockname });
					
					$.each(textblocklist,function(Tindex,tvalue) {
						stringconcat+=tvalue.contentInfo+"\r\n";
						if(falg != 0) datas +=","
						datas+='{"TextBlockName":'+"\""+textblockname+"\"";
						datas+=', "DCFComments": "'+String(tvalue.contentInfo).replace(/\"/g, "'") +'" }';
						falg++;
//						combineblock+='"TextBlockName":'+"\""+textblockname+"\"";
//						combineblock+=', "DCFComments":'+"\""+tvalue.contentInfo+"\"";
//						combineblock+=' },{';
					});
				   
				});
//				},1000,jsonresponse);
//			combineblock=combineblock.substring(0,combineblock.length-2);
			combineblock+=datas+"]} ]} ]}";

			//console.log(" Data :  "+combineblock);
			textValue.push(stringconcat);
			
			
//		var jsonpush=JSON.stringify(dynamicvalue);
		var x2js = new X2JS();
		var jsonObj = JSON.parse(combineblock);
		var xmlAsStr = x2js.json2xml_str(jsonObj);
		var ss=JSON.stringify(jsonObj);
		var b = ss.replace(/'/g, ' ');
		$("#jjson").jJsonViewer(b);
		$("#jsonviewform").show();
	xml_raw = xmlAsStr;

	xml_formatted = formatXml(xml_raw);

	xml_escaped = xml_formatted.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/ /g, '&nbsp;').replace(/\n/g,'<br />');

	var mydiv = document.createElement('div');

	mydiv.innerHTML = xml_escaped;
	$("#example1").append(' &lt; ?xml version="1.0" encoding="UTF-8"? &gt;');
	$("#example1").append(mydiv);
	//$("#example1").append(' &lt;/ xml &gt;');
	//document.body.appendChild(mydiv);
	//$("#example1").html(xmlAsStr);
	var combinestr=' <?xml version="1.0" encoding="UTF-8"?>;'+xmlAsStr;
	
	download(combinestr, $("#formname").val()+".xml", "text/xml");
	
	localStorage.setItem("textValue",textValue);
	download(textValue, $("#formname").val()+'.txt', 'text/plain');
	
	$("#viewbtn").show();
	$("#pdfbtn").show();
	
} 

	function textFileDownload()
	{
//	download(localStorage.getItem("textValue"), $("#formname").val()+'.txt', 'text/plain');
		
		$.ajax({
		    type: 'POST',
		    url: "htmlConverter",
		  data: {
		            htmlcontent : localStorage.getItem("textValue")
		        },
		   
		    error: function(xhr) { // if error occured
		        alert("Error occured.please try again");
		    },
		    complete: function(data) {
		    	
		    	$("#displayxml").hide();
		    	$("#displayForm").show();
		    	
		        //alert("successfully generated!")
		    	download(data.responseText, $("#formname").val()+".html", "text");
		        $("#viewhtml").html(data.responseText);
		    }   
		});
	}
function formatXml(xml) {
    var formatted = '';
    var reg = /(>)(<)(\/*)/g;
    xml = xml.replace(reg, '$1\r\n$2$3');
    var pad = 0;
    jQuery.each(xml.split('\r\n'), function(index, node) {
        var indent = 0;
        if (node.match( /.+<\/\w[^>]*>$/ )) {
            indent = 0;
        } else if (node.match( /^<\/\w/ )) {
            if (pad != 0) {
                pad -= 1;
            }
        } else if (node.match( /^<\w([^>]*[^\/])?>.*$/ )) {
            indent = 1;
        } else {
            indent = 0;
        }

        var padding = '';
        for (var i = 0; i < pad; i++) {
            padding += '  ';
        }

        formatted += padding + node + '\r\n';
        pad += indent;
    });

    return formatted;
}