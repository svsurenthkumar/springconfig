
var app = angular.module('myApp', []);
app.controller('myCtrl', function($scope, $filter,$timeout) {
	
	
	
	
	$scope.downloadCall = function() {
	{
		$("#panelshow").show();
			var ss=JSON.parse($("#texttohtml").html());
			$.each(ss, function(k, v) {
			    //display the key and value pair
			   // alert(k);
			download(v, k+".html", "text");
				});
			
			setTimeout(function(){ alert("Successfully Downloaded!!!");
			$scope.$apply(function () {
				$scope.filelist=JSON.parse($("#fileslist").html());
	        });
			
			}, 3000);
			
			
			
				
	};
	}
	 });