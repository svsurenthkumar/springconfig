var  results=[];
var db = openDatabase ('Formsave', '1.0', 'test DB', 10*1024*1024);
$( document ).ready(function() {

	db.transaction(function (tx) {
	    tx.executeSql('SELECT * FROM content', [], function (tx, rs) {
	    	
	        for(var i=0; i<rs.rows.length; i++) {
		            var row = rs.rows.item(i)
		            results[i] = { contentname: row['contentname'],
		            	contentvalue: row['contentvalue']
		            }
		         } 

	    }, null);
	 });
	

/*	var jsonresponse=$.trim($("#jsonresponse").html());
	jsonresponse=JSON.parse(jsonresponse);
	var formnum=$.trim($("#formnamdid").html());*/
	
		var formnameid=localStorage.getItem("formname");
		var textblockid=localStorage.getItem("texblockname");
		
//	var formnameid=$("#formnameid").val();
//	var textblockid=$("#textblockid").val();
	var seconddetails =JSON.parse(localStorage.getItem("formdetails"));
	var jsonresponse=_.filter(seconddetails, function(o) { return( o.aunr==textblockid && o.formName==formnameid)});
	
	var dynamicvalue=[];

// 	var formnum="12:29";
	dynamicvalue.push({
	"name":textblockid,
	"parent":null
	})
	dynamicvalue.push({
	"name":formnameid,
	"parent":textblockid
	})

	/*dynamicvalue.push({
	"name":"Rule",
	"parent":formnum
	})
	dynamicvalue.push({
	"name":"Content",
	"parent":formnum
	})*/
	
	jsonresponse=_.sortBy(jsonresponse, 'sstbsnr');
	
	setTimeout(function(){ 
		$.each(jsonresponse,function(index,value)
		       {
		dynamicvalue.push({
		"name":value.sstbinr,
		"parent":formnameid
		})
		
		});
		
	/*dynamicvalue.push(
			{
				"name":"value1",
				"parent":"CETPX00001",
				"bustermid":""
			});*/
/*function callchildelement(sstbinr)
{
	dynamicvalue.push(
			{
				"name":"value1",
				"parent":sstbinr,
				"bustermid":""
			});
	
}*/
	dynamicvalue=_.uniqWith(dynamicvalue, _.isEqual);
	//jsonresponse=_.uniqWith(jsonresponse, _.isEqual);
		$.each(jsonresponse,function(index,value)
		       {
			var textblocklist=[];
			var searchFormings=[];
			/*dynamicvalue.push({	
				"name":"value1",
				"parent":value.sstbinr,
				"bustermid":""	
				});
				*/
		      
			var textblockname=value.sstbinr;
			
			
			searchFormings =JSON.parse(results[0]['contentvalue']);
	          
			textblocklist=_.filter(searchFormings, function(o) { return o.textBlockName==textblockname });
			$.each(textblocklist,function(index,value)
				       {
				dynamicvalue.push({
				"name":value.contentInfo,
				"parent":textblockname	
				})
				
				});
			

		
		
		
		       });
		
		
		
	var jsonpush=JSON.stringify(dynamicvalue);
	localStorage.setItem("singleform",jsonpush);
	var data=JSON.parse(jsonpush);

	var margin = {
			top : 20,
			right : 120,
			bottom : 20,
			left : 120
		}, width = 960 - margin.right - margin.left, height = 800 - margin.top
				- margin.bottom;

		var i = 0, duration = 750, root;

		var tree = d3.tree().size([ height, width ]);

		var svg = d3.select("body").append("svg").attr("width",
				width + margin.right + margin.left).attr("height",
				height + margin.top + margin.bottom).append("g").attr(
				"transform",
				"translate(" + margin.left + "," + margin.top + ")");

		var stratify = d3.stratify().id(function(d) {
			return d.name;//This position
		}).parentId(function(d) {
			return d.parent; //What position this position reports to
		});

		var root = stratify(data);

		root.each(function(d) {

			d.name = d.id; //transferring name to a name variable
			d.id = i; //Assigning numerical Ids
			i++;

		});

		root.x0 = height / 2;
		root.y0 = 0;
 
		function collapse(d) {
			if (d.children) {
				d._children = d.children;
				d._children.forEach(collapse);
				d.children = null;
			}
		}

root.children.forEach(collapse);
		update(root);

		d3.select(self.frameElement).style("height", "800px");

		function update(source) {

			// Compute the new tree layout.
			var nodes = tree(root).descendants(), links = nodes.slice(1);

			// Normalize for fixed-depth.
			nodes.forEach(function(d) {
				d.y = d.depth * 180;
			});

			// Update the nodes…
			var node = svg.selectAll("g.node").data(nodes, function(d) {
				return d.id || (d.id = ++i);
			});

			// Enter any new nodes at the parent's previous position.
			var nodeEnter = node.enter().append("g").attr("class", "node")
					.attr(
							"transform",
							function(d) {
								return "translate(" + source.y0 + ","
										+ source.x0 + ")";
							}).on("click", click);

			nodeEnter.append("circle").attr("r", 1e-6).style("fill",
					function(d) {
						return d._children ? "lightsteelblue" : "#fff";
					});
			

			nodeEnter.append("a").attr("xlink:href",linkcall).attr("class", linkclassapply).attr("target","_blank").append("text").attr("x", function(d) {
				return d.children || d._children ? -10 : 10;
			}).attr("dy", ".35em").attr("text-anchor", function(d) {
				return d.children || d._children ? "end" : "start";
			}).text(function(d) {
				return d.name;
			}).style("fill-opacity", 1e-6);
			
			
			

									
					function linkclassapply(d) {

										if (d.data.name == "Data") {
											returnobj = "";
										} else if (d.data.name == "Rule") {
											returnobj = "";
										} else if (d.data.name == formnameid) {
											returnobj = "";
										}
										else if(d.data.name=="Content")
										{
											returnobj = "";
										}else {
											returnobj = "linkunderline";
										}
										return returnobj;

									}
			
			
/*
 * var glboalset=false; $.each(dynamicvalue,function(index,value) { // ||
 * value.name!=="Rule" ||value.name!=="Content" if(value.name!="Data" ) {
 * glboalset=true } if(value.name!="Rule") { glboalset=true }
 * 
 * if(value.name!="Content") { glboalset=true } });
 */
			/*	nodeEnter
		      .append("a")
		         .attr("xlink:href",linkcall)
		         .append("rect")
		          .attr("class", "clickable")
		          .attr("y", -6)
		          .attr("x", function (d) { return d.children || d._children ? -60 : 10; })
		          .attr("width", 50) //2*4.5)
		          .attr("height", 12)
		          .style("fill-opacity", .3)        // set to 1e-6 to hide          
		          ;
			*/
			function linkcall(d)
			{
				var url=window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port: '')+"/CTR_Web/ImpactviewData?id=";
		var returnobj="";
		var formname=d.data.name;
		
				if(d.data.name=="Data")
			{
					returnobj= "#";
			}
		else if(d.data.name=="Rule")
		{
			returnobj= "#";
		}
		else if(d.data.name=="Content")
		{
			returnobj= "#";
		}
		else if(d.data.name==formnameid)                                                                  
			{
			returnobj= "#";
			
			}
		else
			{
			returnobj=url+d.data.bustermid;
			}
				return returnobj;
		
			}
			
			//function (d) { return url + d.data.bustermid; }
			// Transition nodes to their new position.
			var nodeUpdate = node.merge(nodeEnter).transition().duration(
					duration).attr("transform", function(d) {
				return "translate(" + d.y + "," + d.x + ")";
			});

			nodeUpdate.select("circle").attr("r", 4.5).style("fill",
					function(d) {
						return d._children ? "lightsteelblue" : "#fff";
					});

			nodeUpdate.select("text").style("fill-opacity", 1);

			// Transition exiting nodes to the parent's new position.
			var nodeExit = node.exit().transition().duration(duration).attr(
					"transform", function(d) {
						return "translate(" + source.y + "," + source.x + ")";
					}).remove();

			nodeExit.select("circle").attr("r", 1e-6);

			nodeExit.select("text").style("fill-opacity", 1e-6);

			// Update the links…
			var link = svg.selectAll("path.link").data(links);

			// Transition links to their new position.
			link.transition().duration(duration).attr("d", connector);

			// Enter any new links at the parent's previous position.
			var linkEnter = link.enter().insert("path", "g").attr("class",
					"link").attr("d", function(d) {
				var o = {
					x : source.x0,
					y : source.y0,
					parent : {
						x : source.x0,
						y : source.y0
					}
				};
				return connector(o);
			});

			// Transition links to their new position.
			link.merge(linkEnter).transition().duration(duration).attr("d",
					connector);

			// Transition exiting nodes to the parent's new position.
			link.exit().transition().duration(duration).attr("d", function(d) {
				var o = {
					x : source.x,
					y : source.y,
					parent : {
						x : source.x,
						y : source.y
					}
				};
				return connector(o);
			}).remove();

			// Stash the old positions for transition.
			nodes.forEach(function(d) {
				d.x0 = d.x;
				d.y0 = d.y;
			});
		}

		// Toggle children on click.
		function click(d) {
			if (d.children) {
				d._children = d.children;
				d.children = null;
			} else {
				d.children = d._children;
				d._children = null;
			}
			update(d);
		}

		function connector(d) {
			return "M" + d.y + "," + d.x + "C" + (d.y + d.parent.y) / 2 + ","
					+ d.x + " " + (d.y + d.parent.y) / 2 + "," + d.parent.x
					+ " " + d.parent.y + "," + d.parent.x;
		}
	}, 500);
	





		
});
