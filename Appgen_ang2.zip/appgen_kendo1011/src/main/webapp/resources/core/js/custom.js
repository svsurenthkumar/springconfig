$(document).ready(function() {
	// enable fileuploader plugin
	$('input[name="files"]').fileuploader();
	
	
	
	function validate(file) {
		var ext = file.split(".");
		ext = ext[ext.length-1].toLowerCase();      
		var arrayExtensions = ["xlsx","xlsbs","xls"];

		if (arrayExtensions.lastIndexOf(ext) == -1) {
			alert("Wrong extension type.");
			document.getElementById("upl").reset();
		}
	}
	
	function openNav() {
		document.getElementById("mySidenav").style.width = "250px";
	}

	function closeNav() {
		document.getElementById("mySidenav").style.width = "0";
	}
});